# shit-yiimp-adapter — mine Shitcoin with vanilla yiimp

A small JSON-RPC adapter shim that sits between a **vanilla (unpatched)
yiimp stratum** and the **Shitcoin v5.0.9 `syscoind`**, so yiimp can
merge-mine Shitcoin (SHIT) with **no yiimp code changes**.

```
yiimp stratum  --JSON-RPC-->  shit-yiimp-adapter  --JSON-RPC-->  syscoind v5.0.9
                              (this shim, :19332)                 (:8370)
```

Python 3, standard library only. One file. No pip installs, nothing to
compile — read it end to end before you run it; it is written to be
audited in one sitting.

## Why this exists — the three gaps it closes

Vanilla yiimp and the v5.0.9 daemon almost speak the same AuxPoW
protocol, but three mismatches silently stop a yiimp pool from ever
producing a SHIT block (full evidence: `../../07.md`, `../../01.md`,
`../../VERDICT.md` §A4):

| # | Gap | What the shim does |
|---|-----|--------------------|
| 1 | Yiimp reads field **`target`** as its submit trigger; the daemon returns only **`_target`**. Yiimp's trigger compares against empty/zero data, so submissions never fire — silently, on both sides. | Adds `target` = `_target` **verbatim** (no reversal) to every aux-template response. Why verbatim: yiimp's submit extractor (`get_hash_difficulty`) reads bytes 22..29 in internal order, which is exactly the order `_target` is already in — Dogecoin Core `src/rpc/auxpow.cpp:138` emits the same bytes as `_target` (Namecoin API) or `target` (otherwise). Reversing would move the mantissa out of that window and recreate the silent no-submit bug (see `BYTE-ORDER-VERDICT.md`). `_target` is left untouched; a daemon-supplied `target` is never overwritten. |
| 2 | Yiimp calls **parameterless `getauxblock`** — a *wallet* RPC that fails with **-19** ("Wallet file not specified") on any daemon with zero or ≥ 2 wallets, and yiimp cannot express `-rpcwallet`. | Translates `getauxblock()` → `createauxblock <payout_address>` and `getauxblock(hash, auxpow)` → `submitauxblock(hash, auxpow)`. Both are wallet-free and return/submit the identical shapes. |
| 3 | The daemon **clears its aux-template cache on every tip change** (~30 s); stale submits fail with **-8** "block hash unknown". | The shim keeps **no template cache** of its own (per-call translation). It tracks the tip by polling `getblockcount` (default every 5 s) and via an optional `-blocknotify` poke, and **logs every -8 submit with the template's age**. Since 2026-10-26 (Investigation A, below) submissions are additionally **spooled to disk before submission, retried with refresh a bounded number of times, and alarmed on final failure** — never dropped silently. |

Everything else — every non-aux method — is forwarded **byte-for-byte**:
the raw request goes to the daemon as-is, the raw response (including
daemon errors) comes back as-is. One narrow exception, applied
uniformly: any response object carrying `_target` without `target`
gets `target` added — in practice only aux templates match, and
`getblocktemplate` (native `target`, no `_target`) never does.

The tip-poke endpoint answers on both `/notify` and `/blocknotify`
(GET or POST), so either name works in a `-blocknotify` line.

**Batch requests** are translated element-by-element (each element is
handled exactly like a single request). That is a deliberate design
decision, documented here as required: yiimp does not normally batch,
but per-element handling is strictly more compatible than rejecting
batches, and a malformed element surfaces that element's own error
(a local `-32602`/`-32600` for shim-rejected shapes, the daemon's
error for daemon-rejected ones).

> **Prerequisite this shim cannot fix:** the daemon itself must be able
> to issue templates — v5.0.9 binaries, sysgeth beside `syscoind` under
> daemon management, with `--syscoin.statebootstrap.disable` in the
> `gethcommandline` (see `../../VERDICT.md` §B). If `createauxblock`
> fails with `nevm-data-not-found` on the daemon directly, fix the
> daemon stack first; the shim will faithfully pass that error through
> and log it at startup.

## NEW — Investigation-A submission protection (2026-10-26)

Block 110,489 was found twice by a pool and lost silently: the
submission died (most probably a stale template, `-8`, after a tip
change) and **no component retried, queued, spooled or alarmed**.
This adapter now does all of the missing pieces
(`submission-failure-110489-2026-10-26/REPORT.md` §4, items 1–2):

- **Disk spool (before submission).** Every found solution
  `(hash, auxpow)` is written to `spool_dir` (one JSON file per hash,
  atomic write + fsync) **before** the first submission attempt. The
  entry is removed **only** when the daemon confirms acceptance (see
  the acceptance rule below). The adapter replays every spooled
  entry **on startup and periodically thereafter** — every
  `spool_replay_interval_seconds` (default **300 s**) — logging
  `spool_replay_start` / `spool_replay_done`. A found block now
  survives an adapter restart, a daemon restart and a reboot, and a
  transient-failure entry no longer waits for a restart to be
  retried. **Spool directory requirement:** `spool_dir` must be
  mode **0700** and owned by the user the adapter service runs as —
  the spool entries and the alarm marker are the only durable
  evidence of a found block, and anyone who can write that directory
  can forge or delete them. Create it before first start:
  `install -d -m 0700 -o <service-user> /var/lib/shit-yiimp-adapter/spool`.
- **Acceptance means `result:true` — exactly.** (Fix round
  2026-10-26, attacker item B5.) The daemon's `submitAuxBlock`
  returns `ProcessNewBlock`'s bool as its JSON-RPC result, so a
  submission is a success **only when the daemon returns
  `result:true` and, on replay resolution, the block is verified
  on-chain** (next bullet). A reply with `error:null` but
  `result:false`, `result:null` or any other payload is a
  **failure**: the spool entry is kept, the alarm is raised, and the
  caller gets a failure reply. The adapter never reports success
  the daemon did not confirm.
- **On-chain replay resolution.** (Item B6.) Even `result:true`
  proves only that the daemon *stored* the block. Before replaying
  a spooled entry — and whenever a resubmit draws a duplicate-class
  error — the adapter checks `getblock <hash>`. A block already on
  the daemon **resolves** its entry: spool removed, alarm cleared,
  `replay_found_on_chain` logged. A block that landed despite a
  lost ack therefore never re-alarms forever.
- **Retry-with-refresh.** On any submission failure (`-8` or another
  daemon rejection, or a transport error) the adapter fetches a
  fresh template via `createauxblock`, then re-submits, up to
  `submit_retry_attempts` total attempts (default **3**, delay
  `submit_retry_delay_seconds`, default 1 s). See the honest
  semantics box below — retry is not magic. **Retry abort**
  (item B7): if a refresh returns a *different* template hash and
  the tip has advanced to/past the failed entry's height, the
  template is provably dead and retrying **stops immediately**
  (`submit_retry_aborted_template_dead`) — spool kept, alarm
  raised, daemon error returned — instead of burning the remaining
  attempts on a solution that can never land.
- **Alarm.** After the final failed attempt: an
  `ALARM_SUBMISSION_FAILED` ERROR log line, an on-disk marker file
  (`alarm_file`, default `<spool_dir>/ALARM_SUBMISSION_FAILED`), and
  the spool entry is **kept**. Point any file monitor at the marker.
  The marker **lists all pending failed hashes** (field `pending`;
  the top-level `hash` names the most recent one), is written under
  the spool lock so concurrent raise/clear cannot corrupt or drop
  an alarm, and an entry is removed from it only when that hash is
  later accepted or verified on-chain.

> **Retry semantics (honest).** A found AuxPoW is cryptographically
> bound to **its** template — its hash, coinbase and prevhash. It
> **cannot** be moved onto a fresh template, and this adapter never
> tries: every retry submits the **same** `(hash, auxpow)` pair. The
> refresh between attempts only proves whether the daemon is alive
> and whether the original template still exists (logged as
> `original_template_still_live`). Retry therefore recovers
> **transient** failures only: daemon briefly busy / unreachable /
> mid-restart, an ambiguous timeout, a `-8` raised while the daemon
> was rebuilding its cache. If the tip has genuinely moved and the
> daemon discarded the template, **no retry can resurrect the
> solution** — in that case the spool + alarm are what save you from
> losing it *silently*: the entry stays on disk for the operator,
> and the alarm stays raised. Every replay (startup and periodic)
> first checks each entry against the chain with `getblock`, so an
> entry whose block actually landed resolves itself; clean up a
> provably stale spool entry by hand (delete its JSON file in
> `spool_dir`) once the tip is past its height; nothing else deletes
> unconfirmed entries.

New config keys (see `adapter.conf.example`): `submit_retry_attempts`
(1 = legacy no-retry behaviour), `submit_retry_delay_seconds`,
`submit_retry_refresh`, `spool_dir`, `alarm_file`, and (fix round
2026-10-26) `spool_replay_interval_seconds` (default 300; 0 =
startup replay only). No pre-existing key was renamed.

## Install

You need Python 3 (any reasonably current 3.x) and a running v5.0.9
`syscoind`. Nothing else.

```sh
cp shit-yiimp-adapter.py adapter.conf.example test_adapter.py \
   syscoin.conf.snippet README.md /opt/shit-yiimp-adapter/   # or anywhere
cd /opt/shit-yiimp-adapter
python3 test_adapter.py        # unit tests, mock daemon, no live node needed
```

## Configure

```sh
cp adapter.conf.example adapter.conf
```

Edit `adapter.conf`:

- `daemon_host` / `daemon_port` / `daemon_user` / `daemon_password` —
  your syscoind RPC endpoint (`rpcuser`/`rpcpassword` from
  `syscoin.conf`), **or** set `daemon_cookie_path` instead.
- `payout_address` — **your pool's SHIT payout address.** This is the
  address `createauxblock` builds templates for, i.e. where mined SHIT
  pays out. The shim refuses to start without it.
- `listen_host` / `listen_port` — where the shim listens (default
  `127.0.0.1:19332`). Keep it on localhost. If you set an optional
  `adapter_token`, RPC and `/notify` callers must present it
  (`X-Adapter-Token` header, or HTTP Basic with the token). A
  non-loopback `listen_host` with no token makes the shim **refuse
  to start**, unless you set `i_understand_public_bind = true`.
- `payout_address` is also shape-checked at startup: a malformed
  address (not just a missing one) refuses to start with exit 2.
- `tip_poll_seconds`, `log_path`, `notify_file` — see the comments in
  the example file.

Then, in yiimp, change only the SHIT coin's RPC connection: point its
host/port at the shim's listen address instead of syscoind's. Do not
change yiimp code, its database schema, or any other coin.

Optionally add the `-blocknotify` line from `syscoin.conf.snippet` to
`syscoin.conf` and restart syscoind, so tip changes reach the shim
immediately instead of on the next poll. Note (item B12): the adapter
poke only records the tip change in the adapter — it does **not**
refresh yiimp's own work. yiimp ALSO needs its own blocknotify /
work-refresh wiring; the snippet shows the combined line that pokes
both, and its curl is `--max-time`-bounded with failures logged to a
file instead of swallowed.

## Run

```sh
python3 shit-yiimp-adapter.py --config adapter.conf
```

Run it under systemd/supervisor/your usual service manager for
production; it is a plain long-running foreground process that logs to
stdout. On startup it self-checks and logs, as JSON lines:

- `self_check_daemon_reachable` with the current tip,
- `self_check_createauxblock_ok` with the template's `chainid` —
  **expect `29` on mainnet** — or an ERROR record saying exactly what
  the daemon returned instead.

Every translation, tip change, daemon error passthrough, and -8 stale
submit (`stale_template_submit_-8`, with `template_age_seconds` and
`current_tip`) is logged the same way, to stdout and to `log_path` if
configured. A `GET /health` endpoint on the listen port reports the
shim's last known tip.

## Acceptance test

With the shim running, ask for aux work **through the shim**, the way
yiimp does:

```sh
curl -s http://127.0.0.1:19332/ -H 'Content-Type: application/json' \
  -d '{"jsonrpc":"1.0","id":1,"method":"getauxblock","params":[]}'
```

The result must contain **both**:

- `"target": "…"` — the field yiimp reads (added by the shim), and
- `"chainid": 29`

…alongside the untouched `"_target"`. If you see both, all three gaps
are closed and yiimp will drive SHIT merge-mining against your daemon:
templates flow without a wallet, the submit trigger has a real target
to compare against, and stale submissions will show up in the shim's
log with their template age instead of vanishing.

Unit tests (no live daemon needed):

```sh
python3 -m unittest test_adapter -v
```

They cover the verbatim `target` against the real captured templates from
`../../07.md` / `../../01.md`, both `getauxblock` translations, id
preservation, non-aux passthrough, and daemon-error passthrough.
The pre-2026-10-26 "-8 no-retry" assertion is superseded by
Investigation A: the legacy fixture now pins `submit_retry_attempts=1`
(where the mock still counts exactly one submit call) and the new
`InvestigationATests` cover `-8`-then-recover (2 submits, 1 refresh),
persistent `-8` (exactly 3 submits, spool retained, alarm marker
written, daemon error returned un-faked), and restart replay
(recovery and still-failing), plus per-element batch translation.
The fix-round `FixRoundTests` add: `result:false`/`null`/other
payloads take the failure path with spool + alarm intact (B5);
replay resolves a block already on-chain with zero resubmissions,
and a live duplicate-class error is resolved against the chain
(B6); `-8` + moved tip aborts after exactly 1 submit + 1 refresh
while an unmoved tip still gets the full bounded retry (B7); the
expanded deny-list blocks the dangerous methods before the daemon
while pool methods still forward (B11); periodic replay resolves a
spooled entry without a restart (B15); `/health` is `degraded`
until a `createauxblock` succeeds with `chainid` 29, with a startup
chain-ID mismatch at ERROR (B16); and the alarm marker lists all
pending hashes and rebuilds after corruption (Angle 3).

## Design decisions worth knowing

- **Stateless translation (templates).** The shim keeps no template
  cache and never answers an RPC from bookkeeping state (tip number;
  hash → first-seen time, used solely to compute a stale template's
  age). The one deliberate piece of durable state added in 2026-10-26
  is the **submission spool**: found solutions awaiting daemon
  confirmation, on disk, replayed on startup.
- **Bounded, loud submit retries (changed 2026-10-26).** The original
  design never retried a submit — and block 110,489 showed where that
  ends: a transient/stale failure was lost silently and permanently.
  The shim now retries the same `(hash, auxpow)` a bounded,
  configurable number of times with a fresh-template refresh between
  attempts, logs every attempt, spools before the first attempt, and
  alarms on final failure. It **never** submits an AuxPoW against a
  different template and **never** reports success the daemon did not
  confirm — acceptance requires `result:true` exactly (item B5),
  replay resolution additionally verifies the block on-chain via
  `getblock` (item B6), and after the last attempt yiimp gets the
  daemon's own error, unchanged.
- **Odd `getauxblock` forms are rejected locally — never forwarded.**
  Anything other than `[]` or `[<string hash>, <string auxpow>]`
  (dict/named params, 1 param, 3+ params, non-string submit params)
  gets a local JSON-RPC `-32602` and the daemon is never contacted.
  This is Invariant I-1 from the design: the shim never sends the
  method `getauxblock` upstream in any form, so the daemon's wallet
  error `-19` can never reach yiimp through the shim. (This replaces
  the earlier documented pass-through of odd forms — the invariant
  wins over that decision.)
- **Self-check failures don't stop the shim.** They are logged as
  ERROR at startup; the shim still serves and passes daemon errors
  through, so the failure stays diagnosable from one place.
- **Cookie auth is re-read per call**, so a daemon restart (which
  rotates the cookie) needs no shim restart.
- **Daemon HTTP status is preserved on every path.** Success is
  200; a daemon JSON-RPC error is HTTP 500 (including on translated
  calls and batches — a batch is 500 if any element errored), never
  HTTP 200-with-error.
- **Dangerous daemon methods are blocked locally (the deny-list).**
  The shim forwards with the daemon's credentials, so the following
  are blocked locally with `-32601` and never reach the daemon
  (expanded in fix round 2026-10-26, attacker item B11 — the
  earlier list let several of these through):
  - *Shutdown / node control:* `stop`, `restart`,
    `setnetworkactive`, `addnode`, `disconnectnode`, `setban`,
    `clearbanned`, `savemempool`.
  - *Wallet spend, every shape:* `send`, `sendall`,
    `sendtoaddress`, `sendmany`, `sendfrom`, `setaccount`, `move`,
    `bumpfee`, and every method starting with `wallet`.
  - *Wallet create / load / export / unlock:* `createwallet`,
    `loadwallet`, `unloadwallet`, `restorewallet`, `migratewallet`,
    `dumpprivkey`, `dumpwallet`, `backupwallet`, `importprivkey`,
    `encryptwallet`, `walletpassphrase`, `keypoolrefill`,
    `rescanblockchain`, `abortrescan`, and every method starting
    with `import`.
  - *Chain reorganisation / state:* `invalidateblock`,
    `reconsiderblock`, `preciousblock`, `pruneblockchain`,
    `submitheader`.
  - *Daemon-side block generation:* `generate`, `generateblock`,
    `generatetoaddress`, `generatetodescriptor`.
  - *Signing with daemon-held keys:* `signrawtransactionwithkey`,
    `signrawtransactionwithwallet`, `signmessagewithprivkey`.
  - *Test/scheduler hooks:* `setmocktime`, `mockscheduler`,
    `setpowtarget`.

  Legitimate pool traffic is unaffected: `getauxblock`,
  `createauxblock`, `submitauxblock`, `getblock`, `getblockhash`,
  `getblockcount`, `getblockheader`, `getblocktemplate`,
  `getchaintips`, `getmempoolinfo`, `getmininginfo`,
  `getnetworkinfo`, `getpeerinfo`, `getrawmempool`,
  `estimatesmartfee`, `validateaddress` and the other read-only
  chain/network methods all still forward. The escape hatch
  `allow_dangerous_methods = true` disables the deny-list entirely
  and is dangerous: it makes the shim a general-purpose proxy that
  forwards with the daemon's credentials.
- **RPC is served only on `rpc_path` (default `/`).** Any other
  POST path gets a 404 JSON error and is never forwarded. Request
  bodies are capped by `max_request_bytes` (default 1 MB), handler
  sockets time out (`request_timeout_seconds`, default 60), and a
  malformed `Content-Length` gets a clean JSON-RPC error instead of
  a dropped connection.
- **`/notify` is cheap.** It matches by exact path only, records the
  poke (with rate-limited logging) and returns immediately — it
  never calls the daemon synchronously; the tip poll notices the
  new tip. `/health` reports `ok` **only** when the daemon is
  reachable AND the last `createauxblock` succeeded AND its
  `chainid` is 29 (item B16): a node that syncs but cannot build
  blocks, or builds them for the wrong chain, is `degraded` — and a
  startup chain-ID mismatch is logged at ERROR
  (`self_check_chainid_mismatch`), not as a warning beside an `ok`.
  `/health` never discloses the payout address or daemon URL.
