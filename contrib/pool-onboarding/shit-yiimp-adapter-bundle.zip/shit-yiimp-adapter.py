#!/usr/bin/env python3
"""
shit-yiimp-adapter.py -- JSON-RPC adapter shim for vanilla yiimp + Shitcoin

Lets a VANILLA (unpatched) yiimp stratum mine Shitcoin (SHIT) against the
v5.0.9 syscoind, with no yiimp code changes.  Point yiimp's SHIT coin RPC
settings at this shim instead of at syscoind; the shim forwards almost
everything to syscoind untouched and fixes exactly three interface gaps:

  Gap 1 -- `target` vs `_target`
      Yiimp reads the field `target` to decide whether a parent share
      qualifies for a SHIT submission.  syscoind returns the target only
      as `_target`, in reversed byte order.  For every aux-template
      response (translated `getauxblock`, and a directly-called
      `createauxblock`) the shim adds:

          target = _target verbatim (no reversal -- yiimp's submit
          extractor reads bytes 22..29 in internal order; see
          BYTE-ORDER-VERDICT.md)

      but ONLY when `_target` is exactly 64 hex characters; a short,
      empty or non-string `_target` adds nothing and is logged at ERROR
      as TEMPLATE_TARGET_MALFORMED (never fabricate a submit trigger).
      `_target` itself is left untouched, and if the daemon ever starts
      returning `target` itself, the daemon's value wins (never
      overwritten).

  Gap 2 -- `getauxblock` is a wallet RPC; yiimp cannot address a wallet
      Yiimp calls parameterless `getauxblock`, which fails with RPC
      error -19 on any daemon with zero or >= 2 wallets loaded, and
      yiimp's RPC URL has no way to express `-rpcwallet`.  syscoind
      provides wallet-free equivalents with identical shapes, so the
      shim translates:

          getauxblock()               ->  createauxblock <payout_address>
          getauxblock(hash, auxpow)   ->  submitauxblock(hash, auxpow)

      INVARIANT I-1: the shim NEVER sends the method `getauxblock`
      upstream, in any form, for any reason.  Any `getauxblock` whose
      params are not exactly [] or [<string hash>, <string auxpow>]
      is rejected LOCALLY with JSON-RPC -32602 and the daemon is never
      contacted, so the daemon's wallet error -19 can never reach a
      caller through this shim.

  Gap 3 -- the daemon's aux-template cache is tip-scoped (~30 s)
      syscoind clears its cached aux blocks on every tip change, so a
      submission for a template from a previous tip fails with RPC
      error -8 "block hash unknown".  The shim keeps NO template cache
      of its own (every call is translated and forwarded fresh), tracks
      the tip by polling `getblockcount` (and, optionally, via a
      -blocknotify poke -- see syscoin.conf.snippet), and logs every -8
      submission together with the age of the template it referred to,
      so the race is visible in the log instead of silent.

  Investigation-A upgrades (2026-10-26, block 110,489 post-mortem --
  a found block was lost silently because nothing retried, spooled
  or alarmed; see submission-failure-110489-2026-10-26/REPORT.md):

  * DISK SPOOL: every found solution (hash + auxpow) is written to
    `spool_dir` BEFORE the first submission attempt, fsync'd, and
    removed ONLY on daemon-confirmed acceptance.  Spooled entries
    are replayed on startup (`replay_spooled_submissions`, called
    from main()) AND periodically thereafter (every
    `spool_replay_interval_seconds`, default 300 s).  A spool entry
    survives an adapter restart, a daemon restart and a machine
    reboot.
  * STRICT ACCEPTANCE (fix round 2026-10-26, attacker item B5):
    the daemon's submitAuxBlock returns ProcessNewBlock's bool as
    its JSON-RPC result (ShitcoinBtc src/rpc/auxpow_miner.cpp), so
    a submission counts as accepted ONLY when the daemon reply has
    no error AND `result` is exactly True.  `result:false`,
    `result:null` or any other payload with error:null is a
    FAILURE: the spool entry is kept, the alarm is raised, and the
    caller gets a failure reply -- never a confirmed acceptance.
    Even `result:true` proves only that the daemon stored the
    block, so replay resolution additionally verifies the block
    on-chain via `getblock` (item B6, below).
  * ON-CHAIN REPLAY RESOLUTION (item B6): before replaying a
    spooled entry -- and when a resubmit draws a duplicate-class
    error -- the adapter checks `getblock <hash>`; a block already
    on the daemon resolves the entry (spool confirmed/removed,
    alarm cleared, `replay_found_on_chain` logged) instead of
    re-alarming forever for a block that already landed.
  * ACTIVE-CHAIN-ONLY RESOLUTION (follow-up R2, 2026-10-26):
    B6's getblock existence check also matched blocks sitting
    only on a losing fork (confirmations -1), so a fork block
    could be certified as landed, its spool evidence deleted and
    a success reply synthesised.  Resolution now requires BOTH
    `getblockhash(height) == hash` AND `confirmations >= 0`
    (the stratum proxy's standard); anything else fails closed --
    the entry stays spooled and alarmed.
  * SPOOL VALIDATION + DEAD-LETTER (follow-up R3, 2026-10-26):
    (hash, auxpow) pairs are validated BEFORE spooling (hash =
    exactly 64 hex; auxpow hex-decodable within
    MAX_AUXPOW_CHARS); invalid submissions are rejected and never
    spooled.  Entries already on disk are re-validated on every
    pending()/replay pass and quarantined to <name>.bad instead
    of replayed.  An entry whose recorded attempts exceed
    MAX_REPLAY_ATTEMPTS (10) is dead-lettered to <name>.dead
    alongside the spool (the proxy's naming/storage) and never
    replayed again.
  * RETRY ABORT (item B7): after a refresh (`createauxblock`), if
    the fresh template hash differs from the submitted hash AND
    the tip has advanced to/past the submitted entry's height,
    the template is provably dead: retrying stops immediately
    (spool kept, alarm raised, daemon error returned) instead of
    burning the remaining attempts on a solution that can never
    land.
  * RETRY-WITH-REFRESH: on a submission failure (-8 or any other
    daemon rejection, or a transport error) the shim re-fetches a
    fresh template via `createauxblock` and re-submits, up to
    `submit_retry_attempts` total attempts (default 3).
    HONEST SEMANTICS -- read this before trusting the retry: a found
    AuxPoW is cryptographically bound to ITS template (its hash, its
    coinbase, its prevhash).  It can NEVER be transplanted onto the
    fresh template: the shim never submits (fresh_hash, old_auxpow).
    The refresh exists to (a) prove whether the daemon is alive,
    (b) log whether the original template still exists (fresh hash
    == submitted hash) or is gone, and (c) pace the retry.  The
    retry re-submits the SAME (hash, auxpow) pair, so it can only
    recover TRANSIENT failures: a daemon that was briefly busy,
    unreachable or mid-restart, an ambiguous timeout, a -8 raised
    while the daemon was re-indexing its cache.  If the tip has
    genuinely moved and the daemon has discarded the template, NO
    retry can resurrect that solution -- the retry then exists so
    the failure is attempted, logged and alarmed, never silent.
    Success is NEVER faked: if every attempt fails, the caller gets
    the daemon's last error, unchanged.
  * ALARM: after the final failed attempt the shim logs
    ALARM_SUBMISSION_FAILED at ERROR, writes an alarm marker file
    (`alarm_file`, default <spool_dir>/ALARM_SUBMISSION_FAILED) and
    KEEPS the spool entry.  A found block can no longer vanish
    without a persistent, on-disk alarm an operator (or a file
    monitor) can see.  Fix round 2026-10-26 (attacker Angle 3):
    the marker is written under the spool lock and lists ALL
    pending failed hashes (field `pending`, one object per hash;
    the top-level `hash`/`attempts` fields keep naming the most
    recent failure for backward compatibility).  Clearing one
    hash keeps the others; the marker file is removed only when
    no pending failure remains, and a corrupt marker is logged
    (alarm_marker_unreadable) and rebuilt, never silently
    ignored.

Transport fidelity (DESIGN.md SS1): the upstream HTTP status is
preserved on EVERY response path -- success 200, daemon JSON-RPC
error 500 -- because yiimp and generic JSON-RPC clients key off the
HTTP status, not just the body.

Hardening (post-QA):
  * RPC is served only on the configured POST path (default "/");
    any other POST path gets a 404 JSON error and is never forwarded.
  * A deny-list of spend / wallet / shutdown daemon methods is
    blocked locally (-32601, daemon never contacted).  The escape
    hatch `allow_dangerous_methods=true` disables it and is
    DANGEROUS: it turns the shim back into a general-purpose
    credentialed daemon proxy for anyone who can reach the port.
  * An optional `adapter_token` can be required on RPC and /notify
    (header X-Adapter-Token, or HTTP Basic with the token).  A
    non-loopback listen_host with no token refuses to start unless
    `i_understand_public_bind=true` is set.
  * /notify and /blocknotify match by exact path only, record the
    poke and return immediately (no synchronous daemon call; the
    tip-poll thread observes freshness), and poke logging is
    rate-limited.
  * Request bodies are capped (`max_request_bytes`, default 1 MB)
    and handler sockets carry a timeout (`request_timeout_seconds`).

Everything else -- all non-aux, non-denied methods -- is forwarded
byte-for-byte: the raw request body goes to the daemon as-is and the
raw response body comes back as-is, including daemon errors.

Batch requests: translated element-by-element (each element is treated
exactly like a single request).  This is a documented design decision;
see README.md.  A batch is one HTTP response, so its status is the
upstream batch status: 500 if any element errored, else 200 (the
daemon's own batch behaviour).

Python 3, standard library only (http.server + urllib).  No pip installs.

Usage:
    python3 shit-yiimp-adapter.py --config adapter.conf
    python3 shit-yiimp-adapter.py --help        # all options / overrides
"""

import argparse
import base64
import configparser
import hmac
import ipaddress
import json
import os
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# --------------------------------------------------------------------------
# Defaults (every value can be set in the config file or on the CLI)
# --------------------------------------------------------------------------

DEFAULTS = {
    # Daemon (syscoind) JSON-RPC endpoint.
    "daemon_host": "127.0.0.1",
    "daemon_port": "8370",              # syscoind mainnet RPC port
    "daemon_user": "",                  # rpcuser from syscoin.conf
    "daemon_password": "",              # rpcpassword from syscoin.conf
    "daemon_cookie_path": "",           # e.g. ~/.syscoin/.cookie (alt auth)
    "daemon_timeout_seconds": "30",
    # SHIT payout address used for createauxblock (Gap 2). Required, and
    # its shape is validated at startup (exit 2 if malformed).
    "payout_address": "",
    # Shim listen address -- point yiimp's SHIT coin RPC at this.
    "listen_host": "127.0.0.1",
    "listen_port": "19332",
    # The only POST path RPC is served on.
    "rpc_path": "/",
    # Optional shared token required on RPC + notify when set:
    # header X-Adapter-Token: <token>, or HTTP Basic with the token.
    "adapter_token": "",
    # DANGEROUS escape hatch: "true" disables the method deny-list.
    "allow_dangerous_methods": "false",
    # Acknowledge a non-loopback bind with no adapter_token.
    "i_understand_public_bind": "false",
    # Front-door limits.
    "max_request_bytes": "1048576",     # 1 MB
    "request_timeout_seconds": "60",
    # Gap 3 tip tracking.
    "tip_poll_seconds": "5",
    # Investigation-A submission protection (see module docstring).
    # Total submission attempts including the first (1 = legacy
    # no-retry behaviour).  Clamped to 1..10 at runtime.
    "submit_retry_attempts": "3",
    # Seconds to wait between submission attempts (the fresh-template
    # refresh happens in this window).  Clamped to 0..60.
    "submit_retry_delay_seconds": "1",
    # Re-fetch a fresh template via createauxblock between attempts.
    "submit_retry_refresh": "true",
    # Directory holding one JSON file per unconfirmed found block.
    # Empty string DISABLES the spool (not recommended; startup logs
    # a loud warning).  Default: a `spool` directory next to wherever
    # the adapter is started from -- set an absolute path in
    # production (see adapter.conf.example).
    "spool_dir": "spool",
    # Alarm marker file written on final submission failure.
    # Empty = <spool_dir>/ALARM_SUBMISSION_FAILED (or
    # ./ALARM_SUBMISSION_FAILED when the spool is disabled).
    "alarm_file": "",
    # Fix round 2026-10-26 (item B15): seconds between periodic
    # spool replays, in addition to the startup replay.  Default
    # 300.  0 disables the periodic replay (startup replay still
    # runs).  Clamped to 0..86400 at runtime.
    "spool_replay_interval_seconds": "300",
    # Optional signal file: when its mtime changes, a poke is recorded.
    # See syscoin.conf.snippet for the `touch` form of -blocknotify.
    "notify_file": "",
    # Logging: JSON-lines to stdout, and to this file too if set.
    "log_path": "",
}

EXPECTED_CHAIN_ID = 29  # mainnet AuxPoW chain ID since block 88,000

# ---------------------------------------------------------------------------
# Follow-up fix round 2026-10-26 (chain-50 findings R2 / R3)
#
# R2: a spooled entry may be resolved as "on the chain" ONLY when the
# block is on the ACTIVE chain: getblockhash(height) must equal the
# entry's hash AND the getblock result for that hash must carry
# confirmations >= 0.  A block that exists only on a losing fork
# (confirmations == -1), or a different hash at that height, NEVER
# resolves an entry: no spool deletion, no alarm clear, no
# synthesised success reply.  This mirrors the stratum proxy's
# _confirm_on_chain discipline (getblockhash equality).
#
# R3: caller-supplied (hash, auxpow) pairs are validated BEFORE
# anything is written to the spool; entries already on disk are
# re-validated on every pending()/replay pass and quarantined
# (<name>.bad) instead of replayed when invalid; and an entry whose
# recorded attempts exceed MAX_REPLAY_ATTEMPTS is dead-lettered
# (<name>.dead, alongside the spool, mirroring the proxy's
# dead_letter naming/storage) and never replayed again.
# ---------------------------------------------------------------------------

# Maximum recorded submission attempts for one spool entry across
# ALL passes (live submit + every replay).  The proxy's
# DEAD_LETTER_AFTER_PASSES (= 3) counts *replay passes* of provably
# buried entries only, so it is not an equivalent attempts cap; per
# the R3 work order the adapter cap is set explicitly here.
MAX_REPLAY_ATTEMPTS = 10

# Spool-entry sanity caps, mirroring the proxy's _validate_entry
# limits (shitcoin-stratum-proxy.py: MAX_BLOCKHEX_CHARS =
# 8,000,000; MAX_SPOOL_HEIGHT = 100,000,000).  The proxy caps its
# blockhex payload at 8,000,000 hex characters; the adapter applies
# the same character cap to the auxpow payload -- the auxpow is the
# adapter's equivalent caller-supplied payload, so the same limit
# keeps the two spools' sanity envelopes identical.  (Live requests
# are additionally bounded by max_request_bytes, default 1 MB, so
# this cap binds mainly for entries placed on disk directly.)
MAX_AUXPOW_CHARS = 8000000
MAX_SPOOL_HEIGHT = 100000000

_HEX_DIGITS = frozenset("0123456789abcdefABCDEF")


def validate_submission(block_hash, auxpow):
    """Validate a caller-supplied (hash, auxpow) pair (R3).

    Returns an error string, or None when the pair is sane:
      * hash   -- a string of exactly 64 hex characters;
      * auxpow -- a non-empty string, at most MAX_AUXPOW_CHARS
                  characters, hex-decodable to at least one byte.
    Applied BEFORE spooling (live path and spool.spool) and again
    to entries already on disk (SubmissionSpool._validate_entry).
    """
    if not isinstance(block_hash, str):
        return "hash is not a string"
    if len(block_hash) != 64 or any(c not in _HEX_DIGITS
                                    for c in block_hash):
        return "hash is not exactly 64 hex characters"
    if not isinstance(auxpow, str) or not auxpow:
        return "auxpow is not a non-empty string"
    if len(auxpow) > MAX_AUXPOW_CHARS:
        return "auxpow exceeds size cap"
    if len(auxpow) % 2:
        return "auxpow has odd length"
    try:
        raw = bytes.fromhex(auxpow)
    except Exception:
        return "auxpow is not hex-decodable"
    if not raw:
        return "auxpow decodes to zero bytes"
    return None

# Daemon methods that must never be reachable through the shim: they
# spend funds, export or unlock wallet material, move or create
# wallets, reorganise / invalidate the chain, manipulate the peer
# set or bans, prune the chainstate, generate blocks, sign spend
# material, or stop the daemon -- and the shim forwards with the
# DAEMON's credentials, so any caller who can reach the listen port
# could otherwise invoke them.  Any method starting with "wallet"
# or "import" is denied too.  Blocked locally with -32601; the
# daemon is never contacted.  See allow_dangerous_methods.
#
# Fix round 2026-10-26 (attacker item B11, HIGH): the original list
# only covered wallet-prefixed and a few classic spend methods, so
# setnetworkactive, send/sendall, createwallet/loadwallet/
# unloadwallet, invalidateblock/reconsiderblock, addnode/setban
# and pruneblockchain were all forwarded with the daemon's
# credentials.  The list below adds those plus every same-class
# method in the daemon's RPC table (wallet-spend, wallet-load,
# chain-reorg, node-control, signing and generation classes).
# Legitimate pool methods are NOT here: getblock, getblockhash,
# getblockcount, getblockheader, getblocktemplate, getchaintips,
# getmempoolinfo, getmininginfo, getnetworkinfo, getpeerinfo,
# getrawmempool, estimatesmartfee, validateaddress, createauxblock,
# submitauxblock and getauxblock all still forward normally.
DENIED_METHODS = frozenset({
    # shutdown / node control
    "stop", "restart", "setnetworkactive", "addnode",
    "disconnectnode", "setban", "clearbanned", "savemempool",
    # wallet spend (every shape)
    "send", "sendall", "sendtoaddress", "sendmany", "sendfrom",
    "setaccount", "move", "bumpfee",
    # wallet create / load / unload / export / unlock / keys
    "createwallet", "loadwallet", "unloadwallet", "restorewallet",
    "migratewallet", "dumpprivkey", "dumpwallet", "backupwallet",
    "importprivkey", "encryptwallet", "walletpassphrase",
    "keypoolrefill", "rescanblockchain", "abortrescan",
    # chain reorganisation / state manipulation
    "invalidateblock", "reconsiderblock", "preciousblock",
    "pruneblockchain", "submitheader",
    # block generation to an arbitrary address (daemon-side mining)
    "generate", "generateblock", "generatetoaddress",
    "generatetodescriptor",
    # signing spend material with daemon-held keys
    "signrawtransactionwithkey", "signrawtransactionwithwallet",
    "signmessagewithprivkey",
    # test/scheduler hooks that distort chain time or mining state
    "setmocktime", "mockscheduler", "setpowtarget",
})

# Prefixes denied as a class: every wallet* method (walletlock,
# walletprocesspsbt, walletcreatefundedpsbt, ...) and every import*
# method (importaddress, importpubkey, importmulti,
# importdescriptors, importwallet, ...) loads wallet material or
# spends -- none of it is pool traffic.
DENIED_METHOD_PREFIXES = ("wallet", "import")

_BECH32_DATA_CHARS = frozenset("qpzry9x8gf2tvdw0s3jn54khce6mua7l")
_BASE58_CHARS = frozenset(
    "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz")
_HEX_CHARS = frozenset("0123456789abcdefABCDEF")


def config_truthy(value):
    """Interpret a config string/bool as a boolean."""
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("1", "true", "yes", "on")


def is_denied_method(method, allow_dangerous=False):
    """True for spend/wallet/shutdown methods the shim must not forward."""
    if allow_dangerous or not isinstance(method, str):
        return False
    name = method.strip().lower()
    return name in DENIED_METHODS \
        or name.startswith(DENIED_METHOD_PREFIXES)


def is_loopback_host(host):
    """True for loopback bind hosts (127.0.0.0/8, ::1, localhost)."""
    name = str(host or "").strip().lower()
    if name == "localhost" or name.endswith(".localhost") or name == "::1":
        return True
    try:
        return ipaddress.ip_address(name).is_loopback
    except ValueError:
        return False


def is_valid_payout_address(address):
    """Shape check for a SHIT payout address (DESIGN S3, local part).

    Accepts bech32 SHIT forms (shit1... / shit3...), the regtest form
    (bcrt1...) so regtest harnesses keep working, and legacy base58
    shapes.  This is a plausibility gate against typos and garbage;
    the daemon remains the authority (it rejects a bad address with
    -5 on createauxblock).
    """
    if not isinstance(address, str) or not address \
            or address != address.strip():
        return False
    for prefix in ("shit1", "shit3", "bcrt1"):
        if address.startswith(prefix):
            rest = address[len(prefix):]
            return 38 <= len(address) <= 64 \
                and len(rest) >= 32 \
                and all(c in _BECH32_DATA_CHARS for c in rest)
    return 26 <= len(address) <= 35 \
        and all(c in _BASE58_CHARS for c in address)


def getauxblock_shape_error(request):
    """None if `request` is a translatable getauxblock, else a message.

    Only [] (template) and [<string>, <string>] (submit) are valid.
    Everything else -- dict/named params, 1 param, 3+ params,
    non-string submit params -- must be rejected locally so the
    literal method `getauxblock` never goes upstream (Invariant I-1).
    """
    params = request.get("params", [])
    if isinstance(params, list) and len(params) == 0:
        return None
    if isinstance(params, list) and len(params) == 2 \
            and all(isinstance(p, str) for p in params):
        return None
    return "invalid params: getauxblock takes [] or [hash, auxpow]"


def is_valid_target_hex(value):
    """True only for a full-size `_target`: a string of 64 hex chars."""
    return isinstance(value, str) and len(value) == 64 \
        and all(c in _HEX_CHARS for c in value)


def startup_refusal(config):
    """Return (exit_code, event, detail) if startup must refuse, else None."""
    payout = config.get("payout_address", "")
    if not payout:
        return (2, "config_missing_payout_address",
                "set payout_address in adapter.conf -- it is the SHIT "
                "address createauxblock pays out to, i.e. your pool's "
                "SHIT payout address")
    if not is_valid_payout_address(payout):
        return (2, "config_invalid_payout_address",
                "payout_address is set but INVALID (not missing): it "
                "is not a SHIT bech32 (shit1.../shit3...), regtest "
                "bcrt1..., or base58 address shape -- fix the address "
                "in adapter.conf")
    listen_host = config.get("listen_host", "127.0.0.1")
    if not is_loopback_host(listen_host) \
            and not config.get("adapter_token", "") \
            and not config_truthy(config.get("i_understand_public_bind",
                                             "false")):
        return (2, "config_unsafe_listen_host",
                "listen_host %s is not loopback and no adapter_token "
                "is configured -- refusing to start. Set adapter_token, "
                "bind loopback, or set i_understand_public_bind=true "
                "if you really mean to expose an unauthenticated shim "
                "that forwards with the daemon's credentials."
                % listen_host)
    return None


# --------------------------------------------------------------------------
# Small pure helpers (unit-tested in test_adapter.py)
# --------------------------------------------------------------------------

def add_target_field(result):
    # Settled per BYTE-ORDER-VERDICT.md: `target` := `_target` verbatim --
    # Dogecoin Core src/rpc/auxpow.cpp:138 emits the same bytes as "_target"
    # (Namecoin API) or "target" (otherwise), the order yiimp's extractor needs.
    """Return a copy of an aux-template result dict with `target` added.

    - Only acts when `result` is a dict containing a `_target` that is
      exactly 64 hex chars and no `target` yet.
    - Never modifies `_target`; never overwrites an existing `target`.
    - On a malformed `_target` (wrong type, wrong length, non-hex),
      returns the result unchanged rather than inventing a value --
      in particular a short or empty `_target` must NOT fabricate a
      short or empty `target` (that empty-target is Gap 1's symptom).
      Callers log TEMPLATE_TARGET_MALFORMED for that case.
    """
    if not isinstance(result, dict):
        return result
    if "target" in result or "_target" not in result:
        return result
    if not is_valid_target_hex(result["_target"]):
        return result
    new_result = dict(result)
    new_result["target"] = result["_target"]
    return new_result


def translate_request(request, payout_address):
    """Translate one JSON-RPC request object (Gap 2), or return it as-is.

    Returns (new_request, translation_description_or_None).
    Only the two valid shapes are translated; shape validation itself
    lives in getauxblock_shape_error / AdapterCore.handle_one, which
    rejects every other getauxblock form before this is consulted for
    forwarding.
    """
    if not isinstance(request, dict):
        return request, None
    if request.get("method") != "getauxblock":
        return request, None
    params = request.get("params", [])
    if not isinstance(params, list):
        return request, None

    new_request = dict(request)
    if len(params) == 0:
        # Template request -> wallet-free createauxblock <payout_address>
        new_request["method"] = "createauxblock"
        new_request["params"] = [payout_address]
        return new_request, "getauxblock() -> createauxblock <payout_address>"
    if len(params) == 2 and all(isinstance(p, str) for p in params):
        # Submission -> wallet-free submitauxblock(hash, auxpow)
        new_request["method"] = "submitauxblock"
        new_request["params"] = list(params)
        return new_request, "getauxblock(hash, auxpow) -> submitauxblock(hash, auxpow)"
    return request, None


def is_aux_template_call(method, params):
    """True for calls whose successful result is an aux template."""
    if method == "createauxblock":
        return True
    if method == "getauxblock" and isinstance(params, list) and len(params) == 0:
        return True
    return False


def is_aux_submit_call(method, params):
    """True for calls that submit an AuxPoW to the daemon."""
    if method == "submitauxblock":
        return True
    if method == "getauxblock" and isinstance(params, list) and len(params) == 2:
        return True
    return False


def parse_retry_attempts(value):
    """Total submit attempts, clamped to 1..10 (default 3)."""
    try:
        attempts = int(value)
    except (TypeError, ValueError):
        return 3
    return max(1, min(10, attempts))


def parse_retry_delay(value):
    """Seconds between submit attempts, clamped to 0..60 (default 1)."""
    try:
        delay = float(value)
    except (TypeError, ValueError):
        return 1.0
    return max(0.0, min(60.0, delay))


def parse_replay_interval(value):
    """Seconds between periodic spool replays, clamped to 0..86400
    (default 300; 0 disables the periodic replay -- item B15)."""
    try:
        interval = float(value)
    except (TypeError, ValueError):
        return 300.0
    return max(0.0, min(86400.0, interval))


def is_duplicate_class_error(code, message):
    """True for daemon submit errors that mean 'I already have this
    block' (item B6): the resolution is an on-chain check, not more
    blind resubmits."""
    if code in (-27,):
        return True
    text = str(message or "").lower()
    return "duplicate" in text or "already in chain" in text \
        or "already exists" in text or "already have" in text


class SubmissionSpool:
    """On-disk spool of found-but-unconfirmed solutions.

    One JSON file per submitted hash in `directory`:
    {hash, auxpow, first_seen, last_attempt, attempts, last_error}.
    Writes are atomic (tmp file + os.replace + fsync) so a crash
    mid-write can never corrupt an existing entry.  An entry is
    removed ONLY by confirm() -- which the adapter calls only after
    the daemon accepted the submission.  Nothing else deletes one:
    not a -8, not a restart, not a replay failure.

    R3 discipline (follow-up fix round 2026-10-26, mirroring the
    stratum proxy's BlockSpool): spool() validates the (hash,
    auxpow) pair BEFORE writing and refuses invalid pairs;
    pending() re-validates every entry on disk -- an entry that
    fails validation is quarantined to <name>.bad (kept as
    evidence, logged at ERROR once, never returned or replayed);
    and dead_letter() renames an entry to <name>.dead when its
    recorded attempts exceed MAX_REPLAY_ATTEMPTS.
    """

    def __init__(self, directory, logger):
        self.directory = directory or ""
        self._logger = logger
        self._lock = threading.Lock()
        if self.directory:
            os.makedirs(self.directory, exist_ok=True)

    @property
    def enabled(self):
        return bool(self.directory)

    def _path_for(self, block_hash):
        safe = "".join(c for c in str(block_hash)
                       if c.isalnum() or c in ("-", "_"))
        if not safe or safe != str(block_hash):
            import hashlib
            safe = "h-" + hashlib.sha256(
                str(block_hash).encode()).hexdigest()
        return os.path.join(self.directory, safe + ".json")

    @staticmethod
    def _validate_entry(entry):
        """Return an error string, or None when the entry is sane
        (R3; mirrors the proxy's BlockSpool._validate_entry).

        Checks the stored pair with validate_submission(), plus
        the entry's own bookkeeping shapes: height, when present
        and not None, must be an int in [0, MAX_SPOOL_HEIGHT];
        attempts, when present, must be a non-negative int.
        """
        if not isinstance(entry, dict):
            return "entry is not a JSON object"
        err = validate_submission(entry.get("hash"),
                                  entry.get("auxpow"))
        if err:
            return err
        height = entry.get("height")
        if height is not None:
            if isinstance(height, bool) or not isinstance(height, int):
                return "height is not an int"
            if height < 0 or height > MAX_SPOOL_HEIGHT:
                return "height %r out of sane range" % (height,)
        attempts = entry.get("attempts")
        if attempts is not None:
            if isinstance(attempts, bool) \
                    or not isinstance(attempts, int):
                return "attempts is not an int"
            if attempts < 0:
                return "attempts is negative"
        return None

    def _quarantine(self, path, reason):
        """Move an invalid on-disk entry aside to <name>.bad (R3;
        mirrors the proxy's BlockSpool._quarantine): the file is
        KEPT as evidence, an ERROR is logged exactly once (the
        rename removes it from the *.json set pending() scans, so
        it is never logged or replayed again), and later entries
        are unaffected."""
        bad = path + ".bad"
        with self._lock:
            try:
                os.replace(path, bad)
            except OSError as exc:
                self._logger.error(
                    "spool_quarantine_failed", path=path,
                    reason=reason, error=str(exc))
                return None
        self._logger.error(
            "spool_entry_quarantined", path=path, renamed_to=bad,
            reason=reason,
            detail="invalid spool entry quarantined; it will not "
                   "be replayed")
        return bad

    def dead_letter(self, entry):
        """Rename a spool entry to <name>.dead (R3; mirrors the
        proxy's BlockSpool.dead_letter naming/storage): the file
        is KEPT alongside the spool as evidence, an ERROR is
        logged exactly once for the dead-lettering, and replay
        never submits or returns it again (pending() scans only
        *.json).  `entry` is a pending() dict (its "_path" is
        used when present; otherwise the path is derived from
        its hash).  Returns the dead-letter path, or None."""
        path = entry.get("_path") if isinstance(entry, dict) else None
        if not path:
            try:
                path = self._path_for(entry["hash"])
            except Exception:
                return None
        dead = path + ".dead"
        with self._lock:
            try:
                os.replace(path, dead)
            except FileNotFoundError:
                return None
            except OSError as exc:
                self._logger.error(
                    "spool_dead_letter_failed", path=path,
                    error=str(exc))
                return None
        self._logger.error(
            "spool_entry_dead_lettered",
            submitted_hash=entry.get("hash"),
            attempts=entry.get("attempts"), path=path,
            renamed_to=dead,
            detail="spool entry exceeded MAX_REPLAY_ATTEMPTS=%d "
                   "recorded attempts without daemon-confirmed "
                   "acceptance; dead-lettered -- kept on disk as "
                   "evidence, never replayed again"
                   % MAX_REPLAY_ATTEMPTS)
        return dead

    def spool(self, block_hash, auxpow, height=None):
        """Record a found solution BEFORE submission.  Idempotent:
        re-spooling a known hash keeps its original first_seen.
        `height` (the template's block height, when known) is kept
        so the item-B7 retry abort and the replay path can tell a
        provably-buried entry from a merely unlucky one.

        R3: the pair is validated BEFORE anything is written; an
        invalid pair is logged at ERROR and NEVER spooled."""
        if not self.enabled:
            return None
        err = validate_submission(block_hash, auxpow)
        if err is None and height is not None:
            candidate = {"hash": block_hash, "auxpow": auxpow,
                         "height": height}
            err = self._validate_entry(candidate)
        if err is not None:
            self._logger.error(
                "spool_validation_failed", submitted_hash=block_hash,
                reason=err,
                detail="invalid (hash, auxpow) pair refused; "
                       "nothing was written to the spool")
            return None
        path = self._path_for(block_hash)
        with self._lock:
            first_seen = time.time()
            attempts, last_error = 0, None
            try:
                with open(path, encoding="utf-8") as fh:
                    old = json.load(fh)
                first_seen = old.get("first_seen", first_seen)
                attempts = old.get("attempts", 0)
                last_error = old.get("last_error")
                if height is None:
                    height = old.get("height")
            except (OSError, ValueError):
                pass
            entry = {"hash": block_hash, "auxpow": auxpow,
                     "first_seen": first_seen, "attempts": attempts,
                     "last_error": last_error,
                     "last_attempt": None, "height": height}
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(entry, fh)
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp, path)
        self._logger.info("submission_spooled", submitted_hash=block_hash,
                          spool_path=path)
        return path

    def note_attempt(self, block_hash, error_text):
        if not self.enabled:
            return
        path = self._path_for(block_hash)
        with self._lock:
            try:
                with open(path, encoding="utf-8") as fh:
                    entry = json.load(fh)
            except (OSError, ValueError):
                return
            entry["attempts"] = int(entry.get("attempts", 0)) + 1
            entry["last_attempt"] = time.time()
            entry["last_error"] = error_text
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(entry, fh)
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp, path)

    def confirm(self, block_hash):
        """Remove the entry: called ONLY on daemon-confirmed acceptance."""
        if not self.enabled:
            return
        path = self._path_for(block_hash)
        with self._lock:
            try:
                os.unlink(path)
                removed = True
            except FileNotFoundError:
                removed = False
            except OSError as exc:
                self._logger.error("spool_remove_failed",
                                   submitted_hash=block_hash, error=str(exc))
                return
        if removed:
            self._logger.info("submission_spool_confirmed_removed",
                              submitted_hash=block_hash, spool_path=path)

    def pending(self):
        """All VALID spooled entries, oldest first.

        R3: every entry on disk is re-validated with
        _validate_entry() (the same rules the live path applies
        before spooling).  An entry that fails validation -- and a
        file that cannot even be parsed as JSON -- is quarantined
        to <name>.bad via _quarantine() and is NOT returned, so it
        is never replayed and never blocks later entries (this
        supersedes the pre-R3 behaviour of logging a parseable but
        malformed entry and leaving it in the replay set's
        directory scan forever).  Returned entries carry their
        on-disk path under the internal "_path" key (mirroring
        the proxy), which dead_letter() uses and which is never
        written back to disk."""
        if not self.enabled:
            return []
        entries = []
        try:
            names = sorted(os.listdir(self.directory))
        except OSError as exc:
            self._logger.error("spool_list_failed", error=str(exc))
            return []
        for name in names:
            if not name.endswith(".json"):
                continue
            path = os.path.join(self.directory, name)
            try:
                with open(path, encoding="utf-8") as fh:
                    entry = json.load(fh)
            except (OSError, ValueError) as exc:
                self._logger.error("spool_entry_unreadable", path=path,
                                   error=str(exc))
                self._quarantine(path, "unreadable entry: %r" % (exc,))
                continue
            err = self._validate_entry(entry)
            if err:
                self._logger.error("spool_entry_malformed", path=path,
                                   reason=err)
                self._quarantine(path, err)
                continue
            entry["_path"] = path
            entries.append(entry)
        entries.sort(key=lambda e: e.get("first_seen") or 0)
        return entries


# --------------------------------------------------------------------------
# Structured logging: one JSON object per line, to stdout (+ file)
# --------------------------------------------------------------------------

class StructuredLogger:
    def __init__(self, log_path=""):
        self._lock = threading.Lock()
        self._file = None
        if log_path:
            directory = os.path.dirname(os.path.abspath(log_path))
            os.makedirs(directory, exist_ok=True)
            self._file = open(log_path, "a", encoding="utf-8", buffering=1)

    def log(self, level, event, **fields):
        record = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                  "level": level, "event": event}
        record.update(fields)
        line = json.dumps(record, default=str)
        with self._lock:
            print(line, flush=True)
            if self._file:
                self._file.write(line + "\n")

    def info(self, event, **fields):
        self.log("INFO", event, **fields)

    def warning(self, event, **fields):
        self.log("WARN", event, **fields)

    def error(self, event, **fields):
        self.log("ERROR", event, **fields)


# --------------------------------------------------------------------------
# Daemon RPC client (urllib, stdlib only)
# --------------------------------------------------------------------------

class DaemonClient:
    """Thin JSON-RPC-over-HTTP client for syscoind.

    `call_raw` forwards an exact request body (used for byte-for-byte
    passthrough); `call` builds a request from method/params/id.
    Both return (http_status, raw_response_bytes).
    """

    def __init__(self, config, logger):
        self._config = config
        self._logger = logger
        self.url = "http://%s:%s/" % (config["daemon_host"],
                                      config["daemon_port"])
        self.timeout = float(config["daemon_timeout_seconds"])

    def _auth_header(self):
        # Cookie auth wins when a cookie path is configured: it is the
        # form a same-box operator most likely already has, and the file
        # is re-read per call so a daemon restart (new cookie) is picked
        # up without restarting the shim.
        cookie_path = self._config.get("daemon_cookie_path", "")
        if cookie_path:
            with open(os.path.expanduser(cookie_path), encoding="utf-8") as fh:
                credential = fh.read().strip()
        else:
            credential = "%s:%s" % (self._config.get("daemon_user", ""),
                                    self._config.get("daemon_password", ""))
        token = base64.b64encode(credential.encode("utf-8")).decode("ascii")
        return "Basic " + token

    def call_raw(self, body_bytes):
        req = urllib.request.Request(self.url, data=body_bytes, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("Authorization", self._auth_header())
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return resp.status, resp.read()
        except urllib.error.HTTPError as exc:
            # A JSON-RPC error from bitcoind-style daemons normally comes
            # back as HTTP 500 with a JSON body -- that body IS the reply.
            return exc.code, exc.read()

    def call(self, method, params, request_id=None):
        body = json.dumps({"jsonrpc": "1.0", "id": request_id,
                           "method": method, "params": params}).encode()
        status, raw = self.call_raw(body)
        parsed = json.loads(raw.decode("utf-8")) if raw else {}
        return status, parsed


# --------------------------------------------------------------------------
# Tip tracker (Gap 3 observability)
# --------------------------------------------------------------------------

class TipTracker:
    """Watches the daemon tip and remembers when each template was seen.

    This is NOT a template cache: it never answers an RPC.  It only
    keeps enough bookkeeping (hash -> first-seen time / height / tip) to
    log the *age* of a template when a submission fails with -8, which
    is how an operator tells the tip race apart from a real fault.

    Two triggers: a polling thread (`tip_poll_seconds`), and an
    on-demand `poke()` from the /blocknotify HTTP endpoint or the
    notify-file watcher (see syscoin.conf.snippet).  A poke only
    RECORDS that a tip change was signalled -- it never calls the
    daemon synchronously; the poll thread observes the new tip on its
    next pass, so /notify cannot be used as a daemon-RPC amplifier.
    """

    POKE_LOG_INTERVAL_SECONDS = 5.0  # rate-limit identical poke logs

    def __init__(self, daemon, logger, poll_seconds):
        self._daemon = daemon
        self._logger = logger
        self._poll_seconds = poll_seconds
        self._stop = threading.Event()
        self.tip = None
        # Truth for /health: None = never confirmed, True/False = the
        # outcome of the most recent upstream interaction.
        self.daemon_reachable = None
        self.last_poke_at = None
        self.last_poke_hash = None
        self.poke_count = 0
        self._poke_lock = threading.Lock()
        self._last_poke_logged_at = 0.0
        self._pokes_suppressed = 0
        self._seen = {}  # hash -> {"first_seen": float, "height": ..., "tip": ...}
        self._seen_lock = threading.Lock()

    # -- polling ------------------------------------------------------
    def poll_once(self, reason="poll"):
        try:
            _, reply = self._daemon.call("getblockcount", [])
            self.daemon_reachable = True
            new_tip = reply.get("result") if isinstance(reply, dict) else None
            if isinstance(new_tip, int) and new_tip != self.tip:
                old_tip, self.tip = self.tip, new_tip
                self._logger.info("tip_changed", reason=reason,
                                  old_tip=old_tip, new_tip=new_tip)
        except Exception as exc:  # daemon down / bad reply: log, keep going
            self.daemon_reachable = False
            self._logger.warning("tip_poll_failed", reason=reason, error=str(exc))

    def poke(self, reason="blocknotify", block_hash=None):
        """Record a -blocknotify poke and return immediately.

        No daemon call happens here (that is the point: a poke flood
        must not amplify into daemon RPC load or pin handler threads
        for a daemon timeout).  Freshness is observed by the poll
        thread.  Logging is rate-limited so a poke loop cannot flood
        the log either.
        """
        now = time.time()
        with self._poke_lock:
            self.last_poke_at = now
            self.last_poke_hash = block_hash
            self.poke_count += 1
            if now - self._last_poke_logged_at \
                    >= self.POKE_LOG_INTERVAL_SECONDS:
                suppressed = self._pokes_suppressed
                self._pokes_suppressed = 0
                self._last_poke_logged_at = now
                should_log = True
            else:
                suppressed = 0
                self._pokes_suppressed += 1
                should_log = False
        if should_log:
            self._logger.info("tip_poke", reason=reason,
                              block_hash=block_hash,
                              suppressed_since_last_log=suppressed)

    def _loop(self):
        while not self._stop.wait(self._poll_seconds):
            self.poll_once()

    def _notify_file_loop(self, path):
        last_mtime = None
        while not self._stop.wait(1.0):
            try:
                mtime = os.stat(os.path.expanduser(path)).st_mtime
            except OSError:
                continue
            if last_mtime is not None and mtime != last_mtime:
                self.poke(reason="notify_file")
            last_mtime = mtime

    def start(self):
        threading.Thread(target=self._loop, daemon=True,
                         name="tip-poller").start()
        notify_file = self._daemon_config_notify_file()
        if notify_file:
            threading.Thread(target=self._notify_file_loop,
                             args=(notify_file,), daemon=True,
                             name="notify-file-watcher").start()

    def _daemon_config_notify_file(self):
        return self._daemon._config.get("notify_file", "")  # same process

    def stop(self):
        self._stop.set()

    # -- template bookkeeping (logging only) ---------------------------
    def note_template(self, result):
        if isinstance(result, dict) and result.get("hash"):
            with self._seen_lock:
                # Prune aggressively; this dict exists only for age logs.
                if len(self._seen) > 1000:
                    cutoff = time.time() - 3600
                    self._seen = {h: v for h, v in self._seen.items()
                                  if v["first_seen"] > cutoff}
                self._seen.setdefault(
                    result["hash"],
                    {"first_seen": time.time(),
                     "height": result.get("height"), "tip": self.tip})

    def template_age_seconds(self, block_hash):
        with self._seen_lock:
            entry = self._seen.get(block_hash)
        if entry is None:
            return None
        return time.time() - entry["first_seen"]

    def template_height(self, block_hash):
        """Block height of the template `block_hash`, if this shim
        issued or saw it (used by the item-B7 retry abort)."""
        with self._seen_lock:
            entry = self._seen.get(block_hash)
        if entry is None:
            return None
        height = entry.get("height")
        return height if isinstance(height, int) else None


# --------------------------------------------------------------------------
# Request handling
# --------------------------------------------------------------------------

def _error_reply(code, message, request_id):
    return {"result": None,
            "error": {"code": code, "message": message},
            "id": request_id}


class AdapterCore:
    """Transport-independent request processing (easy to unit-test)."""

    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.daemon = DaemonClient(config, logger)
        self.tip_tracker = TipTracker(
            self.daemon, logger, float(config["tip_poll_seconds"]))
        self.allow_dangerous = config_truthy(
            config.get("allow_dangerous_methods", "false"))
        self.adapter_token = config.get("adapter_token", "") or ""
        rpc_path = config.get("rpc_path", "/") or "/"
        self.rpc_path = rpc_path if rpc_path.startswith("/") else "/" + rpc_path
        try:
            self.max_request_bytes = int(config.get("max_request_bytes",
                                                    "1048576"))
        except (TypeError, ValueError):
            self.max_request_bytes = 1048576
        # Investigation-A submission protection.
        self.submit_retry_attempts = parse_retry_attempts(
            config.get("submit_retry_attempts", "3"))
        self.submit_retry_delay_seconds = parse_retry_delay(
            config.get("submit_retry_delay_seconds", "1"))
        self.submit_retry_refresh = config_truthy(
            config.get("submit_retry_refresh", "true"))
        self.spool = SubmissionSpool(config.get("spool_dir", ""), logger)
        alarm_file = config.get("alarm_file", "") or ""
        if not alarm_file:
            base = config.get("spool_dir", "") or "."
            alarm_file = os.path.join(base, "ALARM_SUBMISSION_FAILED")
        self.alarm_file = alarm_file
        # Angle-3 hardening: the alarm marker is written UNDER THE
        # SPOOL LOCK (the very same lock object), so a raise and a
        # clear can never interleave and lose or corrupt an alarm.
        self._alarm_lock = self.spool._lock
        # Item B15: periodic spool replay (in addition to startup).
        self.spool_replay_interval_seconds = parse_replay_interval(
            config.get("spool_replay_interval_seconds", "300"))
        self._replay_stop = threading.Event()
        self._replay_thread = None
        self._replay_in_progress = threading.Lock()
        # Item B16: template capability state for /health.  None =
        # never observed; /health is "ok" only when the last
        # createauxblock succeeded AND returned chainid == 29.
        self.template_capable = None
        self.template_chainid = None
        self.chainid_mismatch = False
        if not self.spool.enabled:
            logger.error(
                "spool_disabled_warning",
                detail="spool_dir is empty: found blocks are NOT "
                       "spooled to disk and cannot survive a restart. "
                       "Set spool_dir in adapter.conf.")

    # -- Item B16: template capability state ----------------------------
    def _record_template_result(self, result, source):
        """Record a successful aux-template reply for /health.

        Capability requires chainid == EXPECTED_CHAIN_ID: a daemon
        issuing templates for the WRONG chain is a degraded node,
        and the mismatch is logged at ERROR (never a WARN beside
        an "ok")."""
        chainid = result.get("chainid") if isinstance(result, dict) \
            else None
        previous_chainid = self.template_chainid
        self.template_chainid = chainid
        if chainid == EXPECTED_CHAIN_ID:
            if self.chainid_mismatch or self.template_capable is False:
                self.logger.info("template_capability_restored",
                                 source=source, chainid=chainid)
            self.chainid_mismatch = False
            self.template_capable = True
        else:
            changed = not self.chainid_mismatch \
                or previous_chainid != chainid
            self.chainid_mismatch = True
            self.template_capable = False
            if changed or source == "self_check":
                self.logger.error(
                    "template_chainid_mismatch", source=source,
                    chainid=chainid, expected=EXPECTED_CHAIN_ID,
                    detail="daemon issues aux templates with the "
                           "wrong chainid; /health reports degraded "
                           "until createauxblock returns chainid %d"
                           % EXPECTED_CHAIN_ID)

    def _record_template_failure(self, source):
        """Record that the latest createauxblock did not produce a
        usable template (daemon error or malformed reply)."""
        self.template_capable = False

    def health_status(self):
        """Truthful /health payload (item B16): "ok" ONLY when the
        daemon is reachable AND the last createauxblock succeeded
        AND its chainid == 29.  A node that syncs but cannot build
        blocks -- or builds them for the wrong chain -- is
        "degraded".  Discloses no payout address and no daemon URL."""
        reachable = self.tip_tracker.daemon_reachable
        ok = reachable is True and self.template_capable is True \
            and self.template_chainid == EXPECTED_CHAIN_ID \
            and not self.chainid_mismatch
        return {
            "status": "ok" if ok else "degraded",
            "daemon_reachable": bool(reachable),
            "tip": self.tip_tracker.tip,
            "template_capable": bool(self.template_capable),
            "last_template_chainid": self.template_chainid,
            "chainid_expected": EXPECTED_CHAIN_ID,
            "chainid_mismatch": bool(self.chainid_mismatch),
            "spool_pending": len(self.spool.pending()),
        }

    # -- Investigation-A: alarm -----------------------------------------
    def alarm_path(self):
        return self.alarm_file

    def _read_alarm_pending(self):
        """Pending-failure list from the marker, or [].

        Caller must hold the alarm lock.  A marker that exists but
        cannot be parsed is logged (never silently ignored -- the
        old behaviour could drop every alarm behind one corrupt
        file) and treated as empty so the caller rebuilds it."""
        try:
            with open(self.alarm_file, encoding="utf-8") as fh:
                payload = json.load(fh)
        except FileNotFoundError:
            return []
        except (OSError, ValueError) as exc:
            self.logger.error("alarm_marker_unreadable",
                              alarm_file=self.alarm_file,
                              error=str(exc),
                              detail="corrupt alarm marker will be "
                                     "rebuilt; pending alarms are "
                                     "re-derived from the spool")
            return []
        if isinstance(payload, dict):
            pending = payload.get("pending")
            if isinstance(pending, list):
                return [p for p in pending
                        if isinstance(p, dict) and p.get("hash")]
            # Legacy single-hash marker shape.
            if payload.get("hash"):
                return [{"hash": payload["hash"],
                         "attempts": payload.get("attempts"),
                         "last_error": payload.get("last_error"),
                         "ts": payload.get("ts")}]
        return []

    def _write_alarm_marker(self, pending):
        """Atomically write the marker from a pending list.

        Caller must hold the alarm lock.  An empty list removes the
        marker.  Top-level hash/attempts mirror the LAST pending
        entry (backward compatibility with single-hash readers)."""
        if not pending:
            try:
                os.unlink(self.alarm_file)
            except FileNotFoundError:
                pass
            except OSError as exc:
                self.logger.error("alarm_file_write_failed",
                                  error=str(exc))
            return
        last = pending[-1]
        payload = {"event": "ALARM_SUBMISSION_FAILED",
                   "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                   "hash": last.get("hash"),
                   "attempts": last.get("attempts"),
                   "last_error": last.get("last_error"),
                   "pending": pending,
                   "pending_count": len(pending)}
        directory = os.path.dirname(os.path.abspath(self.alarm_file))
        os.makedirs(directory, exist_ok=True)
        tmp = "%s.tmp.%d.%d" % (self.alarm_file, os.getpid(),
                                threading.get_ident())
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(payload, fh)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, self.alarm_file)

    def raise_submission_alarm(self, block_hash, auxpow, attempts,
                                 last_error):
        """Loud, persistent alarm for a finally-failed submission.

        Three surfaces, none silent: an ERROR log line with the
        dedicated event ALARM_SUBMISSION_FAILED, the spool entry
        (kept), and an on-disk marker file a monitor can watch.
        The marker lists ALL pending failed hashes and is written
        under the spool lock, so a restart re-raise upserts its own
        hash and can neither corrupt the marker nor drop another
        hash's pending alarm (attacker Angle 3).
        """
        self.logger.error(
            "ALARM_SUBMISSION_FAILED", submitted_hash=block_hash,
            attempts=attempts, last_error=str(last_error),
            spool_enabled=self.spool.enabled,
            alarm_file=self.alarm_file,
            detail="FOUND BLOCK NOT ACCEPTED BY DAEMON after %d "
                   "attempt(s); solution is spooled on disk and "
                   "will be replayed periodically and on adapter "
                   "startup; if the tip has moved past this "
                   "template the solution is stale and cannot be "
                   "recovered by retry -- see the adapter README, "
                   "'Retry semantics (honest)'."
                   % attempts)
        try:
            with self._alarm_lock:
                pending = [p for p in self._read_alarm_pending()
                           if p.get("hash") != block_hash]
                pending.append({
                    "hash": block_hash, "attempts": attempts,
                    "last_error": str(last_error),
                    "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z")})
                self._write_alarm_marker(pending)
        except OSError as exc:
            self.logger.error("alarm_file_write_failed",
                              submitted_hash=block_hash, error=str(exc))

    def clear_alarm_if_for(self, block_hash):
        """Drop ONE hash from the marker when it is now accepted
        (or verified on-chain).  Other pending hashes stay listed;
        the marker file is removed only when none remain."""
        with self._alarm_lock:
            pending = self._read_alarm_pending()
            kept = [p for p in pending if p.get("hash") != block_hash]
            if len(kept) == len(pending):
                return
            try:
                self._write_alarm_marker(kept)
            except OSError as exc:
                self.logger.error("alarm_file_write_failed",
                                  submitted_hash=block_hash,
                                  error=str(exc))
                return
        self.logger.info("alarm_cleared_on_acceptance",
                         submitted_hash=block_hash,
                         pending_remaining=len(kept))

    # -- Item B6: on-chain resolution (hardened by R2) -------------------
    def _block_on_chain(self, block_hash, height=None):
        """(True, block_dict) ONLY if the block is on the ACTIVE
        chain, else (False, None).

        R2 (follow-up fix round 2026-10-26, mirroring the proxy's
        _confirm_on_chain): `getblock <hash>` returning a dict is
        NOT enough -- the daemon also returns blocks that sit only
        on a losing fork, with confirmations == -1.  Resolution
        requires BOTH:
          * the getblock result for this hash carries
            confirmations >= 0 (an int; missing / non-int /
            negative -- notably -1 for a losing-fork block --
            fails closed), AND
          * getblockhash(height) == block_hash, where height is
            the caller-supplied entry height when given, else the
            height reported in the getblock result, else the
            template bookkeeping height.
        Any check that cannot be made (daemon error, unknown
        height, non-string chain hash) fails closed: (False, None)
        -- the entry stays spooled and alarmed, exactly as the
        proxy treats an unavailable confirmation."""
        try:
            _, reply = self.daemon.call("getblock", [block_hash])
        except Exception as exc:
            self.logger.warning("chain_check_failed",
                                submitted_hash=block_hash,
                                error=str(exc))
            return False, None
        result = reply.get("result") if isinstance(reply, dict) else None
        if not isinstance(result, dict):
            return False, None
        confirmations = result.get("confirmations")
        if isinstance(confirmations, bool) \
                or not isinstance(confirmations, int) \
                or confirmations < 0:
            self.logger.warning(
                "chain_check_not_on_active_chain",
                submitted_hash=block_hash, confirmations=confirmations,
                detail="getblock found the block but it is not on "
                       "the active chain (confirmations < 0, e.g. "
                       "-1 for a losing-fork block); NOT resolving "
                       "the spool entry")
            return False, None
        if not isinstance(height, int) or isinstance(height, bool):
            height = result.get("height")
        if not isinstance(height, int) or isinstance(height, bool):
            height = self.tip_tracker.template_height(block_hash)
        if height is None:
            self.logger.warning(
                "chain_check_failed", submitted_hash=block_hash,
                error="block height unknown; cannot verify "
                      "getblockhash(height) -- failing closed")
            return False, None
        try:
            _, hash_reply = self.daemon.call("getblockhash", [height])
        except Exception as exc:
            self.logger.warning("chain_check_failed",
                                submitted_hash=block_hash,
                                height=height, error=str(exc))
            return False, None
        chain_hash = hash_reply.get("result") \
            if isinstance(hash_reply, dict) else None
        if not isinstance(chain_hash, str) \
                or chain_hash.lower() != str(block_hash).lower():
            self.logger.warning(
                "chain_check_hash_mismatch",
                submitted_hash=block_hash, height=height,
                chain_hash=chain_hash,
                detail="getblockhash(height) does not equal the "
                       "entry hash; the active chain holds a "
                       "different block at this height -- NOT "
                       "resolving the spool entry")
            return False, None
        return True, result

    def _resolve_entry_found_on_chain(self, block_hash, source):
        """Confirm a spooled entry whose block IS verified on the
        ACTIVE chain by _block_on_chain (R2: getblockhash equality
        AND confirmations >= 0): remove the spool entry, clear its
        alarm, log it.  Never called on a fork-only sighting."""
        self.spool.confirm(block_hash)
        self.clear_alarm_if_for(block_hash)
        self.logger.info("replay_found_on_chain",
                         submitted_hash=block_hash, source=source,
                         detail="spooled block verified on the "
                                "daemon via getblock; entry "
                                "resolved without resubmission")

    # -- Investigation-A: submission with spool + retry-with-refresh ----
    def _refresh_template_for_retry(self, submitted_hash, attempt):
        """Fetch a fresh template between attempts and log whether
        the submitted template still exists.  The fresh template is
        NEVER used for submission -- a found AuxPoW is bound to its
        own template (see module docstring).

        Returns {"hash":..., "height":...} for a successful refresh,
        else None (refresh disabled or failed)."""
        if not self.submit_retry_refresh:
            return None
        try:
            _, reply = self.daemon.call(
                "createauxblock", [self.config["payout_address"]])
            result = reply.get("result") if isinstance(reply, dict) else None
            if isinstance(result, dict):
                fresh_hash = result.get("hash")
                self._record_template_result(result, "retry_refresh")
                self.logger.info(
                    "submit_retry_refresh", submitted_hash=submitted_hash,
                    next_attempt=attempt, fresh_hash=fresh_hash,
                    fresh_height=result.get("height"),
                    original_template_still_live=(
                        fresh_hash == submitted_hash),
                    current_tip=self.tip_tracker.tip)
                self.tip_tracker.note_template(result)
                return {"hash": fresh_hash,
                        "height": result.get("height")}
            self._record_template_failure("retry_refresh")
            self.logger.warning(
                "submit_retry_refresh_failed",
                submitted_hash=submitted_hash, next_attempt=attempt,
                daemon_reply=str(reply)[:200])
        except Exception as exc:
            self.logger.warning("submit_retry_refresh_failed",
                                submitted_hash=submitted_hash,
                                next_attempt=attempt, error=str(exc))
        return None

    def _template_dead_after_refresh(self, submitted_hash, entry_height,
                                     refresh_info):
        """Item B7 abort test, applied after a refresh.

        Returns (dead, tip) -- dead is True when the fresh template
        hash differs from the submitted hash AND the tip has
        advanced to/past the entry's height (the height the entry
        was mined for is already occupied, so the solution can
        never land).  When the entry's height is unknown (a direct
        submitauxblock the shim never issued a template for), a
        differing fresh template on a daemon whose tip is known is
        treated as the same proof: the daemon's current template
        is no longer the submitted one."""
        if not refresh_info:
            return False, self.tip_tracker.tip
        fresh_hash = refresh_info.get("hash")
        if not fresh_hash or fresh_hash == submitted_hash:
            return False, self.tip_tracker.tip
        tip = self.tip_tracker.tip
        if tip is None:
            try:
                _, reply = self.daemon.call("getblockcount", [])
                result = reply.get("result") \
                    if isinstance(reply, dict) else None
                if isinstance(result, int):
                    tip = result
                    self.tip_tracker.tip = result
            except Exception:
                tip = None
        if tip is None:
            fresh_height = refresh_info.get("height")
            if isinstance(fresh_height, int):
                # The daemon's current template sits at tip + 1.
                tip = fresh_height - 1
        if tip is None:
            return False, None
        if entry_height is not None:
            return tip >= entry_height, tip
        return True, tip

    def _refresh_and_check_abort(self, submitted_hash, entry_height,
                                 attempt):
        """Refresh between attempts; True means STOP retrying now
        (item B7): log the abort at ERROR and let the caller take
        the normal final-failure path (spool kept, alarm raised,
        daemon error returned)."""
        refresh_info = self._refresh_template_for_retry(
            submitted_hash, attempt + 1)
        dead, tip = self._template_dead_after_refresh(
            submitted_hash, entry_height, refresh_info)
        if dead:
            self.logger.error(
                "submit_retry_aborted_template_dead",
                submitted_hash=submitted_hash, attempt=attempt,
                fresh_hash=(refresh_info or {}).get("hash"),
                entry_height=entry_height, current_tip=tip,
                detail="refresh returned a DIFFERENT template and "
                       "the tip has advanced to/past this entry's "
                       "height: the submitted template is provably "
                       "dead and no retry can land this solution; "
                       "stopping after %d attempt(s) -- spool kept, "
                       "alarm raised" % attempt)
            return True
        if self.submit_retry_delay_seconds:
            time.sleep(self.submit_retry_delay_seconds)
        return False

    def _submit_with_retry(self, request_id, submitted_hash, auxpow,
                           upstream_body):
        """Spool, then submit (hash, auxpow) with bounded retries.

        Returns (http_status, reply_dict, raw_body_or_None) exactly
        like handle_one.  Acceptance requires the daemon reply to
        carry no error AND result is True exactly (item B5); only
        then is the spool entry removed and any alarm for this hash
        cleared.  On final failure the spool entry is KEPT, the
        alarm is raised, and the daemon's last error is returned
        unchanged (never faked).  Retrying stops early when a
        refresh proves the template dead (item B7), and a
        duplicate-class error is resolved against the chain
        (item B6).
        """
        # 0. R3 pre-spool validation: an invalid (hash, auxpow)
        #    pair is rejected here and NEVER spooled, never sent
        #    to the daemon.  (SubmissionSpool.spool re-validates
        #    as defence in depth.)
        validation_error = validate_submission(submitted_hash, auxpow)
        if validation_error is not None:
            self.logger.error(
                "submission_validation_failed",
                submitted_hash=submitted_hash, reason=validation_error,
                detail="invalid (hash, auxpow) pair rejected before "
                       "spooling; nothing written, daemon not "
                       "contacted")
            return 500, _error_reply(
                -32602, "adapter: invalid submitauxblock params: %s"
                        % validation_error, request_id), None
        # 1. Spool BEFORE the first attempt -- a crash or restart
        #    from here on cannot lose the solution silently.  The
        #    entry records the template height when known (item B7):
        #    from this run's template bookkeeping, or from the
        #    existing spool entry on a replay after a restart.
        entry_height = self.tip_tracker.template_height(submitted_hash)
        if entry_height is None and self.spool.enabled:
            for existing in self.spool.pending():
                if existing.get("hash") == submitted_hash \
                        and isinstance(existing.get("height"), int):
                    entry_height = existing["height"]
                    break
        try:
            self.spool.spool(submitted_hash, auxpow,
                             height=entry_height)
        except Exception as exc:
            # A spool failure must not block the submission itself,
            # but it is never quiet.
            self.logger.error("spool_write_failed",
                              submitted_hash=submitted_hash,
                              error=str(exc))
        attempts = self.submit_retry_attempts
        attempts_made = 0
        last_status, last_reply, last_raw = 500, None, None
        last_error_text = None
        for attempt in range(1, attempts + 1):
            attempts_made = attempt
            try:
                status, raw = self.daemon.call_raw(upstream_body)
                reply = json.loads(raw.decode("utf-8")) if raw else {}
            except Exception as exc:
                self.tip_tracker.daemon_reachable = False
                last_error_text = "daemon unreachable: %s" % exc
                self.logger.error(
                    "submit_attempt_failed", submitted_hash=submitted_hash,
                    attempt=attempt, attempts=attempts,
                    error=str(exc),
                    detail="transport error -- outcome unknown to the "
                           "daemon may or may not have processed it; "
                           "retrying the same (hash, auxpow) is safe: "
                           "the daemon deduplicates by block hash")
                last_status = 500
                last_reply = _error_reply(
                    -1, "adapter: daemon unreachable during submit "
                        "(spooled; will be replayed periodically "
                        "and on startup)",
                    request_id)
                last_raw = None
                self.spool.note_attempt(submitted_hash, last_error_text)
                if attempt < attempts and not \
                        self._refresh_and_check_abort(
                            submitted_hash, entry_height, attempt):
                    continue
                break
            self.tip_tracker.daemon_reachable = True
            if not isinstance(reply, dict):
                last_error_text = "malformed daemon response"
                last_status, last_raw = 500, None
                last_reply = _error_reply(
                    -1, "adapter: malformed daemon response", request_id)
                self.spool.note_attempt(submitted_hash, last_error_text)
                if attempt < attempts and not \
                        self._refresh_and_check_abort(
                            submitted_hash, entry_height, attempt):
                    continue
                break
            if reply.get("id") != request_id:
                raw = None
            reply["id"] = request_id
            error = reply.get("error")
            if not error and reply.get("result") is True:
                # Daemon-confirmed acceptance (item B5): the ONLY
                # outcome that removes the spool entry.  Acceptance
                # requires result is True EXACTLY -- the daemon's
                # submitAuxBlock returns ProcessNewBlock's bool as
                # the JSON-RPC result, so result:false / result:null
                # / anything else with error:null is a rejection
                # whose spool evidence must NOT be destroyed.
                self.spool.confirm(submitted_hash)
                self.clear_alarm_if_for(submitted_hash)
                if attempt > 1:
                    self.logger.info(
                        "submit_accepted_after_retry",
                        submitted_hash=submitted_hash, attempt=attempt)
                return status, reply, raw
            if not error:
                # error:null but result is not True (item B5).
                result_value = reply.get("result")
                last_error_text = (
                    "daemon returned result %r with no error for "
                    "submitauxblock; only result:true is acceptance"
                    % (result_value,))
                self.logger.error(
                    "submit_result_not_true",
                    submitted_hash=submitted_hash, attempt=attempt,
                    attempts=attempts, result=result_value,
                    detail="treating as daemon rejection: spool "
                           "entry kept, retry/alarm path applies")
                last_status = 500
                last_raw = None
                last_reply = _error_reply(
                    -1, "adapter: daemon did not confirm acceptance "
                        "of the submitted block (result was %r, "
                        "not true); spooled and alarmed"
                        % (result_value,), request_id)
                self.spool.note_attempt(submitted_hash, last_error_text)
                if attempt < attempts and not \
                        self._refresh_and_check_abort(
                            submitted_hash, entry_height, attempt):
                    continue
                break
            # Daemon rejected this attempt.
            code = error.get("code") if isinstance(error, dict) else None
            message = error.get("message") if isinstance(error, dict) \
                else str(error)
            last_error_text = "%s: %s" % (code, message)
            last_status, last_reply, last_raw = status, reply, raw
            fields = {"method": "submitauxblock",
                      "request_id": request_id,
                      "daemon_http_status": status,
                      "error_code": code, "error_message": message,
                      "submitted_hash": submitted_hash,
                      "attempt": attempt, "attempts": attempts}
            if code == -8:
                fields["template_age_seconds"] = (
                    self.tip_tracker.template_age_seconds(submitted_hash))
                fields["current_tip"] = self.tip_tracker.tip
                self.logger.error("stale_template_submit_-8", **fields)
            else:
                self.logger.error("daemon_error_passthrough", **fields)
            self.spool.note_attempt(submitted_hash, last_error_text)
            if is_duplicate_class_error(code, message):
                # Item B6: a duplicate-class resubmit error is
                # resolved against the chain, not by more retries.
                found, _block = self._block_on_chain(
                    submitted_hash, height=entry_height)
                if found:
                    self._resolve_entry_found_on_chain(
                        submitted_hash, "duplicate_resubmit")
                    return 200, {"result": True, "error": None,
                                 "id": request_id}, None
            if attempt < attempts:
                self.logger.warning(
                    "submit_retrying", submitted_hash=submitted_hash,
                    attempt=attempt, attempts=attempts,
                    last_error=last_error_text)
                if not self._refresh_and_check_abort(
                        submitted_hash, entry_height, attempt):
                    continue
            break
        # Final failure: spool entry stays, alarm fires, caller gets
        # the daemon's own last error -- unchanged, never a fake True.
        self.raise_submission_alarm(submitted_hash, auxpow,
                                    attempts_made, last_error_text)
        return last_status, last_reply, last_raw

    def _entry_provably_buried(self, entry):
        """RT-2 (red team, 2026-10-27): True ONLY when the entry's
        block is PROVABLY dead -- the tip has reached/passed the
        entry's height AND the active chain holds a DIFFERENT hash
        at that height (the proxy's dead-letter rule).  Every check
        that cannot be made (unknown height, daemon unreachable,
        getblockhash error) returns False: an unproven block is
        never abandoned.  In particular, when the tip is STUCK
        below the entry's height -- the stall shape, where this
        block is exactly what the chain is waiting for -- the
        entry is by definition not buried."""
        height = entry.get("height")
        if not isinstance(height, int) or isinstance(height, bool):
            height = self.tip_tracker.template_height(entry.get("hash"))
        if not isinstance(height, int) or isinstance(height, bool):
            return False
        try:
            _, tip_reply = self.daemon.call("getblockcount", [])
        except Exception:
            return False
        tip = tip_reply.get("result") if isinstance(tip_reply, dict) else None
        if not isinstance(tip, int) or isinstance(tip, bool) or tip < height:
            return False
        try:
            _, hash_reply = self.daemon.call("getblockhash", [height])
        except Exception:
            return False
        chain_hash = hash_reply.get("result") \
            if isinstance(hash_reply, dict) else None
        return isinstance(chain_hash, str) and \
            chain_hash.lower() != str(entry.get("hash")).lower()

    def _dead_letter_if_over_attempts_cap(self, entry):
        """R3 attempts cap, gated by RT-2: True when `entry` has
        recorded attempts exceeding MAX_REPLAY_ATTEMPTS **and** the
        entry is provably buried (_entry_provably_buried) -- in
        which case it is dead-lettered (renamed to <name>.dead
        alongside the spool) and never replayed again.

        RT-2 (2026-10-27): the R3 cap alone dead-lettered a
        still-landable block ~15 minutes after the find (3 attempts
        per pass x 300 s replay interval burns 10 attempts in 3
        passes) even when the tip was still stuck waiting for
        exactly that block.  An over-cap entry that is NOT provably
        buried stays in the spool and keeps being replayed; the
        cap now only retires entries the chain has provably moved
        past.  The alarm marker is never cleared by this path."""
        attempts = entry.get("attempts")
        if not isinstance(attempts, int) or isinstance(attempts, bool):
            attempts = 0
        if attempts <= MAX_REPLAY_ATTEMPTS:
            return False
        if not self._entry_provably_buried(entry):
            self.logger.warning(
                "spool_entry_over_cap_not_buried",
                submitted_hash=entry.get("hash"), attempts=attempts,
                cap=MAX_REPLAY_ATTEMPTS,
                detail="entry is over the replay attempts cap but "
                       "is NOT provably buried (tip has not taken "
                       "its height with a different hash); keeping "
                       "it spooled and replaying -- RT-2 rule")
            return False
        self.logger.error(
            "spool_entry_attempts_cap_exceeded",
            submitted_hash=entry.get("hash"), attempts=attempts,
            cap=MAX_REPLAY_ATTEMPTS,
            detail="entry exceeded the replay attempts cap and is "
                   "provably buried; dead-lettering it -- it will "
                   "not be replayed again")
        self.spool.dead_letter(entry)
        return True

    def _entry_attempts_on_disk(self, block_hash):
        """Current recorded attempts for a hash, read fresh from
        its spool file (0 when absent/unreadable)."""
        if not self.spool.enabled:
            return 0
        path = self.spool._path_for(block_hash)
        try:
            with open(path, encoding="utf-8") as fh:
                entry = json.load(fh)
            attempts = entry.get("attempts")
            if isinstance(attempts, int) \
                    and not isinstance(attempts, bool):
                return attempts
        except (OSError, ValueError):
            pass
        return 0

    def replay_spooled_submissions(self):
        """Replay every spooled solution.

        Called on startup AND periodically (item B15).  Each entry
        is FIRST checked against the chain (item B6, hardened by
        R2): a block verified on the ACTIVE chain (getblockhash
        equality AND confirmations >= 0) resolves the entry
        without any resubmission; a fork-only block (confirmations
        -1) or a different hash at its height does NOT resolve it.
        Remaining entries go through the same spool + retry path;
        an entry the daemon now accepts (result:true) is removed,
        one it still rejects stays spooled and re-alarms.

        R3, gated by RT-2 (2026-10-27): pending() has already
        quarantined invalid entries (they are not in this list at
        all).  An entry whose recorded attempts exceed
        MAX_REPLAY_ATTEMPTS **and that is provably buried** (tip
        >= its height and a different hash on-chain there) --
        checked before its replay and again after a replay that
        pushed it over the cap -- is dead-lettered to <name>.dead
        and never replayed again.  An over-cap entry that is not
        provably buried stays and keeps being replayed.
        Returns (attempted, resolved), where
        attempted counts only entries actually replayed/checked
        (dead-lettered entries are excluded).
        """
        pending = self.spool.pending()
        live = []
        for entry in pending:
            if self._dead_letter_if_over_attempts_cap(entry):
                continue
            live.append(entry)
        pending = live
        if pending:
            self.logger.info("spool_replay_start", count=len(pending))
        resolved = 0
        for entry in pending:
            entry_height = entry.get("height")
            if not isinstance(entry_height, int) \
                    or isinstance(entry_height, bool):
                entry_height = None
            found, _block = self._block_on_chain(
                entry["hash"], height=entry_height)
            if found:
                self._resolve_entry_found_on_chain(
                    entry["hash"], "replay_precheck")
                resolved += 1
                continue
            status, reply, _raw = self._submit_with_retry(
                "spool-replay", entry["hash"], entry["auxpow"],
                json.dumps({"jsonrpc": "1.0", "id": "spool-replay",
                            "method": "submitauxblock",
                            "params": [entry["hash"],
                                       entry["auxpow"]]}).encode())
            if isinstance(reply, dict) and not reply.get("error") \
                    and reply.get("result") is True:
                resolved += 1
                continue
            # R3: a replay that pushed this entry over the cap
            # dead-letters it in this same pass.
            attempts_now = self._entry_attempts_on_disk(entry["hash"])
            if attempts_now > MAX_REPLAY_ATTEMPTS:
                current = dict(entry)
                current["attempts"] = attempts_now
                self._dead_letter_if_over_attempts_cap(current)
        if pending:
            self.logger.info("spool_replay_done", attempted=len(pending),
                             accepted=resolved,
                             still_spooled=len(pending) - resolved)
        return len(pending), resolved

    # -- Item B15: periodic spool replay ---------------------------------
    def _periodic_replay_loop(self):
        interval = self.spool_replay_interval_seconds
        while not self._replay_stop.wait(interval):
            if not self._replay_in_progress.acquire(blocking=False):
                self.logger.warning(
                    "spool_periodic_replay_skipped",
                    detail="previous replay still in progress")
                continue
            try:
                self.replay_spooled_submissions()
            except Exception as exc:  # a replay pass must never die
                self.logger.error("spool_periodic_replay_failed",
                                  error=str(exc))
            finally:
                self._replay_in_progress.release()

    def start_periodic_replay(self):
        """Start the periodic replay thread (item B15).  Returns
        the thread, or None when disabled (interval 0 or spool
        disabled -- the startup replay in main() still ran)."""
        if self.spool_replay_interval_seconds <= 0 \
                or not self.spool.enabled:
            self.logger.info(
                "spool_periodic_replay_disabled",
                interval_seconds=self.spool_replay_interval_seconds,
                spool_enabled=self.spool.enabled,
                detail="spool replay runs at startup only")
            return None
        self._replay_stop.clear()
        self._replay_thread = threading.Thread(
            target=self._periodic_replay_loop, daemon=True,
            name="spool-replayer")
        self._replay_thread.start()
        self.logger.info(
            "spool_periodic_replay_started",
            interval_seconds=self.spool_replay_interval_seconds)
        return self._replay_thread

    def stop_periodic_replay(self):
        self._replay_stop.set()

    # -- one JSON-RPC request object -----------------------------------
    def handle_one(self, request):
        """Process a single request.

        Returns (http_status, response_dict, raw_body_or_None).  The
        raw body is the daemon's exact response bytes, present when
        the reply needed no shim modification (no target injection,
        id already correct) so error bodies reach the caller
        byte-identical; it is None when the reply was (or must be)
        re-serialised from the dict.

        The upstream HTTP status is returned alongside the body on
        every path: status passthrough matters because yiimp and
        generic JSON-RPC clients key off the HTTP status (500 for a
        daemon error), not only the JSON body.
        """
        method = request.get("method") if isinstance(request, dict) else None
        params = request.get("params", []) if isinstance(request, dict) else []
        # Missing id -> null (never an invented 0), per DESIGN SS1.
        request_id = request.get("id") if isinstance(request, dict) else None

        # D1 / Invariant I-1: odd-form getauxblock is rejected locally.
        # The literal method `getauxblock` must never go upstream, so
        # the daemon's wallet error -19 has no path to the caller.
        if method == "getauxblock":
            shape_error = getauxblock_shape_error(request)
            if shape_error is not None:
                self.logger.warning(
                    "client_bad_request", method=method,
                    request_id=request_id, detail=shape_error)
                return 500, _error_reply(-32602, shape_error,
                                         request_id), None

        # D2: deny-list, enforced before anything is forwarded.
        # (Params are deliberately NOT logged: for methods like
        # importprivkey the params themselves are secrets.)
        if is_denied_method(method, self.allow_dangerous):
            self.logger.error("denied_method_blocked", method=method,
                              request_id=request_id)
            return 500, _error_reply(
                -32601, "method not available through adapter: %s" % method,
                request_id), None

        translated, description = translate_request(
            request, self.config["payout_address"])
        effective_method = translated.get("method")
        effective_params = translated.get("params", [])
        if description:
            self.logger.info("translation", translation=description,
                             request_id=request_id)

        is_submit = is_aux_submit_call(method, params)

        # The upstream request carries the caller's id verbatim, so an
        # unmodified daemon reply is already in caller shape and its
        # raw bytes can be returned byte-identical.
        upstream_body = json.dumps(
            {"jsonrpc": "1.0", "id": request_id,
             "method": effective_method,
             "params": effective_params}).encode()
        if is_submit and isinstance(effective_params, list) \
                and len(effective_params) == 2 \
                and all(isinstance(v, str) for v in effective_params):
            # R3: validate BEFORE spooling/submission.  An invalid
            # pair gets an error reply and is never spooled and
            # never reaches the daemon.
            validation_error = validate_submission(
                effective_params[0], effective_params[1])
            if validation_error is not None:
                self.logger.error(
                    "submission_validation_failed",
                    submitted_hash=effective_params[0],
                    reason=validation_error,
                    detail="invalid (hash, auxpow) pair rejected "
                           "before spooling; nothing written, "
                           "daemon not contacted")
                return 500, _error_reply(
                    -32602, "adapter: invalid submitauxblock params: %s"
                            % validation_error, request_id), None
            # Investigation-A path: spool-before-submit, bounded
            # retry-with-refresh, alarm on final failure.  Applies to
            # translated getauxblock submits AND direct submitauxblock.
            return self._submit_with_retry(
                request_id, effective_params[0], effective_params[1],
                upstream_body)
        try:
            status, raw = self.daemon.call_raw(upstream_body)
            reply = json.loads(raw.decode("utf-8")) if raw else {}
        except Exception as exc:
            # Shim-generated error (D4): echo the caller's id, keep the
            # raw exception (errno strings, cookie file paths, parser
            # positions) in the server-side log ONLY.
            self.tip_tracker.daemon_reachable = False
            if isinstance(exc, (ValueError, UnicodeDecodeError)):
                self.logger.error("daemon_malformed_response",
                                  method=effective_method,
                                  request_id=request_id, error=str(exc))
                message = "adapter: malformed daemon response"
            else:
                self.logger.error("daemon_unreachable",
                                  method=effective_method,
                                  request_id=request_id, error=str(exc))
                message = "adapter: daemon unreachable"
                if is_submit:
                    message += " during submit " \
                               "(outcome unknown -- not retried)"
            return 500, _error_reply(-1, message, request_id), None
        self.tip_tracker.daemon_reachable = True
        if not isinstance(reply, dict):
            self.logger.error("daemon_malformed_response",
                              method=effective_method,
                              request_id=request_id,
                              error="daemon reply was not a JSON object")
            return 500, _error_reply(
                -1, "adapter: malformed daemon response",
                request_id), None
        # Preserve the caller's id exactly, whatever the daemon echoed;
        # a request without an id gets null back.  If the daemon echoed
        # a different id, the reply counts as modified (no raw body).
        if reply.get("id") != request_id:
            raw = None
        reply["id"] = request_id

        error = reply.get("error")
        if error:
            fields = {"method": effective_method,
                      "request_id": request_id,
                      "daemon_http_status": status,
                      "error_code": error.get("code") if isinstance(error, dict) else None,
                      "error_message": error.get("message") if isinstance(error, dict) else str(error)}
            if is_submit and isinstance(error, dict) and error.get("code") == -8:
                # Only reachable for malformed-shape submits that the
                # spool+retry path cannot take (non-string params);
                # well-formed submits are handled by
                # _submit_with_retry above, which logs the same event
                # per attempt.  Log the template's age here too.
                submitted_hash = params[0] if isinstance(params, list) and params else None
                fields["submitted_hash"] = submitted_hash
                fields["template_age_seconds"] = (
                    self.tip_tracker.template_age_seconds(submitted_hash)
                    if submitted_hash else None)
                fields["current_tip"] = self.tip_tracker.tip
                self.logger.error("stale_template_submit_-8", **fields)
            else:
                self.logger.error("daemon_error_passthrough", **fields)
            # Daemon errors pass through unchanged -- byte-identical
            # whenever the daemon echoed the caller's id (raw is set).
            return status, reply, raw

        result = reply.get("result")

        # Gap 1: add `target` to aux-template results.
        if is_aux_template_call(effective_method, effective_params) \
                and isinstance(result, dict):
            if "_target" in result and "target" not in result \
                    and not is_valid_target_hex(result["_target"]):
                self.logger.error(
                    "TEMPLATE_TARGET_MALFORMED",
                    request_id=request_id,
                    _target_prefix=str(result["_target"])[:16])
            new_result = add_target_field(result)
            if new_result is not result and "target" in new_result:
                self.logger.info(
                    "target_added", request_id=request_id,
                    height=result.get("height"),
                    chainid=result.get("chainid"))
                reply = dict(reply)
                reply["result"] = new_result
                result = new_result
                raw = None  # modified: must be re-serialised
            self._record_template_result(result, "rpc_template")
            self.tip_tracker.note_template(result)

        return status, reply, raw

    # -- a whole HTTP request body (single or batch) --------------------
    def handle_body(self, body_bytes):
        """Returns (http_status, response_body_bytes).

        Non-aux, non-batch requests are forwarded byte-for-byte.
        Aux requests and batches are parsed, handled per element, and
        re-serialised (their semantics are preserved; their bytes are
        the shim's own JSON encoding).
        """
        try:
            parsed = json.loads(body_bytes.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            # Malformed JSON is answered locally: -32700, id null (no
            # id is parseable from garbage).  Never forwarded upstream.
            self.logger.warning("client_bad_request",
                                detail="unparseable JSON body")
            return 500, json.dumps(
                _error_reply(-32700, "parse error", None)).encode()

        if isinstance(parsed, list):
            # Batch: translate per element (documented decision).
            self.logger.info("batch_request", elements=len(parsed))
            replies = []
            statuses = []
            for item in parsed:
                if isinstance(item, dict):
                    status, reply, _raw = self.handle_one(item)
                else:
                    # Non-object elements are answered locally; they
                    # are never forwarded upstream as their own calls.
                    status = 500
                    reply = _error_reply(
                        -32600, "invalid request: batch elements must "
                                "be JSON-RPC request objects", None)
                statuses.append(status)
                replies.append(reply)
            # A batch is a single HTTP response carrying a single
            # status: the upstream batch status -- 500 if any element
            # errored, else 200 (the daemon's own batch behaviour).
            batch_status = next((s for s in statuses if s != 200), 200)
            return batch_status, json.dumps(replies).encode()

        if isinstance(parsed, dict):
            _, description = translate_request(
                parsed, self.config["payout_address"])
            method = parsed.get("method")
            params = parsed.get("params", [])
            # Anything the shim must adjudicate itself goes through
            # handle_one: every getauxblock form (valid or odd --
            # Invariant I-1), denied methods, direct submitauxblock
            # (so its -8s get the stale-submit log, D12), and aux
            # template calls (target rewriting).
            needs_shim = description is not None \
                or method == "getauxblock" \
                or method == "submitauxblock" \
                or is_denied_method(method, self.allow_dangerous) \
                or is_aux_template_call(method, params)
            if not needs_shim:
                # Byte-for-byte passthrough for everything else, with
                # one narrow exception (the DESIGN.md SS4 rule): if the
                # response happens to carry `_target` without `target`,
                # `target` is added -- in practice only aux templates
                # match, and GBT (native `target`, no `_target`) never
                # does.
                try:
                    status, raw = self.daemon.call_raw(body_bytes)
                except Exception as exc:
                    self.tip_tracker.daemon_reachable = False
                    self.logger.error("daemon_unreachable", method=method,
                                      request_id=parsed.get("id"),
                                      error=str(exc))
                    return 500, json.dumps(_error_reply(
                        -1, "adapter: daemon unreachable",
                        parsed.get("id"))).encode()
                self.tip_tracker.daemon_reachable = True
                return status, self._maybe_add_target(raw)
            status, reply, raw = self.handle_one(parsed)
            if raw is not None:
                return status, raw
            return status, json.dumps(reply).encode()

        # Top-level scalar / null / bool: not a JSON-RPC request.
        return 500, json.dumps(_error_reply(
            -32600, "invalid request", None)).encode()

    def _maybe_add_target(self, raw):
        """Apply the narrow target rule to a raw daemon response body."""
        try:
            reply = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return raw
        if isinstance(reply, dict) and isinstance(reply.get("result"), dict):
            result = reply["result"]
            if "_target" in result and "target" not in result \
                    and not is_valid_target_hex(result["_target"]):
                self.logger.error(
                    "TEMPLATE_TARGET_MALFORMED",
                    _target_prefix=str(result["_target"])[:16])
            new_result = add_target_field(result)
            if new_result is not result:
                reply = dict(reply)
                reply["result"] = new_result
                self.logger.info("target_added",
                                 height=new_result.get("height"),
                                 chainid=new_result.get("chainid"))
                return json.dumps(reply).encode()
        return raw

    # -- startup self-check ----------------------------------------------
    def self_check(self):
        """Log whether the daemon is reachable and issuing templates.

        Failures are logged as ERROR but do not stop the shim: an
        operator (or the acceptance test) can read exactly what is
        wrong from the log, and the shim starts serving -- and passing
        through the daemon's own errors -- regardless.  (/health
        reports the outcome truthfully as degraded until the daemon
        answers; see D9 in QA-REPORT.md.)
        """
        try:
            _, reply = self.daemon.call("getblockcount", [])
            self.tip_tracker.daemon_reachable = True
            self.logger.info("self_check_daemon_reachable",
                             tip=reply.get("result"))
            self.tip_tracker.tip = reply.get("result")
        except Exception as exc:
            self.tip_tracker.daemon_reachable = False
            self.logger.error("self_check_daemon_unreachable", error=str(exc))
            return
        try:
            _, reply = self.daemon.call(
                "createauxblock", [self.config["payout_address"]])
            result = reply.get("result") if isinstance(reply, dict) else None
            if isinstance(result, dict):
                chainid = result.get("chainid")
                self._record_template_result(result, "self_check")
                if chainid == EXPECTED_CHAIN_ID:
                    self.logger.info(
                        "self_check_createauxblock_ok", chainid=chainid,
                        height=result.get("height"),
                        chainid_expected=EXPECTED_CHAIN_ID,
                        chainid_ok=True)
                else:
                    # Item B16: a chain-ID mismatch at startup is an
                    # ERROR-level degraded state -- never a WARN
                    # beside an "ok" /health.
                    self.logger.error(
                        "self_check_chainid_mismatch", chainid=chainid,
                        expected=EXPECTED_CHAIN_ID,
                        height=result.get("height"),
                        detail="daemon issues aux templates for "
                               "the WRONG chain; adapter is "
                               "DEGRADED (see /health) until "
                               "createauxblock returns chainid %d"
                               % EXPECTED_CHAIN_ID)
                self.tip_tracker.note_template(result)
            else:
                self._record_template_failure("self_check")
                self.logger.error("self_check_createauxblock_failed",
                                  daemon_reply=reply)
        except Exception as exc:
            self._record_template_failure("self_check")
            self.logger.error("self_check_createauxblock_failed",
                              error=str(exc))


def make_handler(core):
    """Build the HTTP handler class bound to one AdapterCore."""
    try:
        socket_timeout = float(core.config.get("request_timeout_seconds",
                                               "60"))
    except (TypeError, ValueError):
        socket_timeout = 60.0
    max_bytes = core.max_request_bytes
    rpc_path = core.rpc_path

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        server_version = "shit-yiimp-adapter"
        sys_version = ""

        def setup(self):
            super().setup()
            # Parked partial requests (slow-loris) die on this
            # timeout instead of holding a handler thread forever.
            try:
                self.connection.settimeout(socket_timeout)
            except OSError:
                pass

        def log_message(self, *args):  # silence default stderr access log
            pass

        # -- plumbing ---------------------------------------------------
        def _send(self, status, body, content_type="application/json"):
            try:
                self.send_response(status)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError, TimeoutError):
                # A client that went away mid-response is not a shim
                # fault; never let it traceback the handler thread.
                core.logger.log("DEBUG", "client_disconnected")

        def _send_json_error(self, status, code, message, request_id=None):
            body = json.dumps(
                _error_reply(code, message, request_id)).encode()
            self._send(status, body)

        def _authorized(self):
            """True when no adapter_token is set, or the caller has it."""
            token = core.adapter_token
            if not token:
                return True
            header = self.headers.get("X-Adapter-Token") or ""
            if hmac.compare_digest(header, token):
                return True
            auth = self.headers.get("Authorization") or ""
            if auth.startswith("Basic "):
                try:
                    credential = base64.b64decode(
                        auth[6:]).decode("utf-8", "replace")
                except Exception:
                    return False
                # Accept the token as the password part, the username
                # part, or the whole credential.
                user, _, password = credential.partition(":")
                return hmac.compare_digest(credential, token) \
                    or hmac.compare_digest(password, token) \
                    or hmac.compare_digest(user, token)
            return False

        def _path_only(self):
            return urllib.parse.urlparse(self.path).path

        # -- endpoints ----------------------------------------------------
        def _handle_notify(self):
            if not self._authorized():
                self._send_json_error(403, -32600,
                                      "adapter token required")
                return
            query = urllib.parse.parse_qs(
                urllib.parse.urlparse(self.path).query)
            block_hash = (query.get("hash") or [None])[0]
            # Record-only poke: returns immediately, makes NO daemon
            # call (see TipTracker.poke).
            core.tip_tracker.poke(reason="http_blocknotify",
                                  block_hash=block_hash)
            self._send(200, b"ok\n", "text/plain")

        def _handle_health(self):
            if not self._authorized():
                # Without the token, /health discloses nothing: no
                # payout address, no daemon URL, no tip.
                self._send_json_error(403, -32600,
                                      "adapter token required")
                return
            # Item B16: status reflects template capability, not
            # mere reachability -- see AdapterCore.health_status.
            body = json.dumps(core.health_status()).encode()
            self._send(200, body)

        def do_GET(self):
            path = self._path_only()
            if path in ("/notify", "/blocknotify"):
                self._handle_notify()
            elif path == "/health":
                self._handle_health()
            else:
                self._send_json_error(404, -32600, "not found")

        def do_POST(self):
            path = self._path_only()
            if path in ("/notify", "/blocknotify"):
                self._handle_notify()
                return
            if path != rpc_path:
                # RPC lives on the configured path only; anything
                # else is a 404 JSON error and is never forwarded.
                self._send_json_error(404, -32600,
                                      "not found: RPC is served only "
                                      "on %s" % rpc_path)
                return
            if not self._authorized():
                self._send_json_error(403, -32600,
                                      "adapter token required")
                return
            # Content-Length is validated INSIDE the guard: a
            # non-numeric or negative value gets a clean JSON-RPC
            # error, never an unhandled exception that drops the
            # connection with zero bytes.
            raw_length = self.headers.get("Content-Length")
            try:
                length = int(raw_length) if raw_length is not None else 0
                if length < 0:
                    raise ValueError("negative Content-Length")
            except (TypeError, ValueError):
                self.close_connection = True
                self._send_json_error(400, -32600,
                                      "invalid Content-Length")
                return
            if length > max_bytes:
                self.close_connection = True
                self._send_json_error(413, -32600,
                                      "request too large: max %d bytes"
                                      % max_bytes)
                return
            try:
                body = self.rfile.read(length) if length else b""
            except (TimeoutError, ConnectionResetError, BrokenPipeError):
                core.logger.log("DEBUG", "client_read_failed")
                return
            try:
                status, reply = core.handle_body(body)
            except Exception as exc:  # never hang yiimp on a shim bug
                # Log the detail server-side; the caller gets a
                # generic message and, when parseable, its own id.
                core.logger.error("shim_internal_error", error=str(exc))
                request_id = None
                try:
                    parsed = json.loads(body.decode("utf-8"))
                    if isinstance(parsed, dict):
                        request_id = parsed.get("id")
                except (ValueError, UnicodeDecodeError):
                    pass
                self._send_json_error(500, -32603,
                                      "adapter internal error", request_id)
                return
            self._send(status, reply)

    return Handler


# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------

def load_config(argv=None):
    parser = argparse.ArgumentParser(
        description="Yiimp <-> Shitcoin v5.0.9 syscoind JSON-RPC adapter.")
    parser.add_argument("--config", default="",
                        help="path to adapter.conf (see adapter.conf.example)")
    for key in DEFAULTS:
        parser.add_argument("--" + key.replace("_", "-"), default=None,
                            help="override config value: %s" % key)
    args = parser.parse_args(argv)

    config = dict(DEFAULTS)
    if args.config:
        ini = configparser.ConfigParser()
        ini.optionxform = str  # keys are case-sensitive in our file
        if not ini.read(args.config):
            parser.error("cannot read config file: %s" % args.config)
        if ini.has_section("adapter"):
            for key in DEFAULTS:
                if ini.has_option("adapter", key):
                    config[key] = ini.get("adapter", key).strip()
    for key in DEFAULTS:
        value = getattr(args, key)
        if value is not None:
            config[key] = value
    # Environment wins last for secrets convenience: SHIT_ADAPTER_<KEY>
    for key in DEFAULTS:
        env_value = os.environ.get("SHIT_ADAPTER_" + key.upper())
        if env_value:
            config[key] = env_value
    return config


def main(argv=None):
    config = load_config(argv)
    logger = StructuredLogger(config.get("log_path", ""))

    refusal = startup_refusal(config)
    if refusal is not None:
        code, event, detail = refusal
        logger.error(event, detail=detail)
        return code
    if not is_loopback_host(config.get("listen_host", "127.0.0.1")) \
            and not config.get("adapter_token", ""):
        # Only reachable with i_understand_public_bind=true.
        logger.warning(
            "listen_public_bind_acknowledged",
            listen_host=config.get("listen_host"),
            detail="non-loopback bind without adapter_token, "
                   "acknowledged via i_understand_public_bind=true")

    core = AdapterCore(config, logger)
    logger.info("adapter_starting",
                listen="%s:%s" % (config["listen_host"], config["listen_port"]),
                daemon=core.daemon.url,
                payout_address=config["payout_address"],
                tip_poll_seconds=config["tip_poll_seconds"],
                submit_retry_attempts=core.submit_retry_attempts,
                spool_dir=config.get("spool_dir", ""),
                spool_replay_interval_seconds=(
                    core.spool_replay_interval_seconds),
                alarm_file=core.alarm_file)
    core.self_check()
    # Investigation-A: a found block spooled by a previous run (crash,
    # restart, daemon outage) gets its submission replayed NOW, before
    # new work is served.  Entries the daemon still rejects stay
    # spooled and re-alarm -- they are never dropped here.  Fix round
    # 2026-10-26 (item B15): replay ALSO runs periodically from here
    # on (spool_replay_interval_seconds, default 300 s), so a
    # transient-failure entry no longer waits for an adapter restart.
    try:
        core.replay_spooled_submissions()
    except Exception as exc:  # replay must never stop the shim starting
        logger.error("spool_replay_failed", error=str(exc))
    core.tip_tracker.start()
    core.start_periodic_replay()

    server = ThreadingHTTPServer(
        (config["listen_host"], int(config["listen_port"])),
        make_handler(core))
    server.daemon_threads = True
    logger.info("adapter_listening",
                listen="%s:%s" % (config["listen_host"], config["listen_port"]))
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("adapter_stopping", reason="keyboard_interrupt")
    finally:
        core.stop_periodic_replay()
        core.tip_tracker.stop()
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
