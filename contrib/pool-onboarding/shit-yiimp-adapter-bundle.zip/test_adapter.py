#!/usr/bin/env python3
"""
Unit tests for shit-yiimp-adapter.py -- standard library unittest only.

A mock syscoind (an in-process http.server) stands in for the real
daemon, so NO live daemon is needed:

    python3 -m unittest test_adapter -v
    # or simply:
    python3 test_adapter.py

EXTENDED SUITE for the Investigation-A adapter (2026-10-26).  This file
is the original test_adapter.py with minimal, marked adaptations plus a
new InvestigationATests class:

  * EndToEndTests' fixture pins submit_retry_attempts=1 (the legacy
    no-retry configuration, still supported) so the original call-count
    assertions run verbatim; retry behaviour itself is covered with
    attempts=3 in InvestigationATests.  The pristine original suite
    was ALSO run unmodified against the pristine original adapter
    (46 tests, OK -- see ../tests/results.txt).
  * Two logger assertions changed: with the alarm upgrade, a finally
    failed submit logs stale_template_submit_-8 AND THEN
    ALARM_SUBMISSION_FAILED, so "logger.last is the -8 event" became
    "the -8 event is in the recorded events, and the alarm fired".
  * MockDaemon gained submit_failures_remaining (fail N submits with
    -8, then succeed) to drive the transient-recovery tests.
  * FIX ROUND 2026-10-26: MockDaemon gained submit_result_override
    (result:false/null/other with error:null -- item B5), getblock
    backed by chain_blocks (B6), template hash/chainid overrides and
    a createauxblock error mode (B7/B16), and a FixRoundTests class
    covering B5, B6, B7, B11, B15, B16 and the Angle-3 alarm marker
    hardening (multi-hash marker, spool-lock writes, corrupt-marker
    rebuild).

Covered:
  * verbatim `target` (= `_target` exactly, per BYTE-ORDER-VERDICT.md),
    using the real template samples from ../../07.md and ../../01.md,
    plus a faithful replica of yiimp's get_hash_difficulty extractor;
  * `target` is added, `_target` is left untouched, an existing
    `target` is never overwritten, malformed `_target` invents nothing;
  * Gap 2 translation: parameterless getauxblock -> createauxblock,
    getauxblock(hash, auxpow) -> submitauxblock, ids preserved;
  * non-aux methods pass through unchanged (method, params, id);
  * daemon errors pass through unchanged, including the -8 stale
    submit (which is never retried: the mock counts exactly one call);
  * batch requests are translated per element.
"""

import importlib.util
import json
import os
import socket
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))

# The adapter file has hyphens in its name, so load it by path.
_spec = importlib.util.spec_from_file_location(
    "shit_yiimp_adapter", os.path.join(HERE, "shit-yiimp-adapter.py"))
adapter = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(adapter)

# --- Real template samples captured live from node1 (see ../../07.md) ---
# Per BYTE-ORDER-VERDICT.md §6(iii): the emitted `target` IS `_target`
# verbatim, so SAMPLE_TARGET == SAMPLE_UNDERSCORE_TARGET (and likewise
# for sample 2). The old display-order values are NOT the emitted field.
SAMPLE_UNDERSCORE_TARGET = \
    "000000000000000000000000000000000000000000006abe3500000000000000"
SAMPLE_TARGET = SAMPLE_UNDERSCORE_TARGET
SAMPLE_BITS = "1935be6a"
SAMPLE_MANTISSA = 0x35be6a
# Second real sample (../../01.md): bits 193801a9.
SAMPLE2_UNDERSCORE_TARGET = \
    "00000000000000000000000000000000000000000000a9013800000000000000"
SAMPLE2_TARGET = SAMPLE2_UNDERSCORE_TARGET
SAMPLE2_BITS = "193801a9"
SAMPLE2_MANTISSA = 0x3801a9


def yiimp_binlify(hex_string):
    """Faithful replica of yiimp util.cpp binlify(): plain hex decode."""
    return bytes.fromhex(hex_string)


def yiimp_get_hash_difficulty(input_bytes):
    """Faithful replica of yiimp util.cpp get_hash_difficulty():
    bytes 22..29 assembled little-endian (p[22] is least significant)."""
    p = input_bytes
    return ((p[29] << 56) | (p[28] << 48) | (p[27] << 40) |
            (p[26] << 32) | (p[25] << 24) | (p[24] << 16) |
            (p[23] << 8) | (p[22] << 0))


def decode_compact_mantissa(bits_hex):
    """Mantissa of yiimp decode_compact(bits): bits & 0x007fffff."""
    return int(bits_hex, 16) & 0x007fffff

PAYOUT = "shit1qe5fjgduvwqrwthugqar45tclnngkqlfuddxfu8"  # sample only
TEMPLATE_HASH = "de09dc3752803ee86886a86b721ad900d5b5a86cda9f1e4c6544" \
                "22263eb1b71e"


def make_template():
    return {
        "hash": TEMPLATE_HASH,
        "chainid": 29,
        "previousblockhash": "6ab564496e4bb8ff93cd64402cc9e2f4fae140db"
                             "93ca37e54ca894fe70514ae1",
        "coinbasevalue": 17826466861,
        "coinbasescript": "6a277379733e4bc613d0126d913ab22fd000ee7561ac6"
                          "8cf22f522a4238ec79f307aefee44ac980100",
        "bits": "1935be6a",
        "height": 104632,
        "_target": SAMPLE_UNDERSCORE_TARGET,
    }


_UNSET = object()  # sentinel: submitauxblock returns the default True


class MockDaemon:
    """Minimal syscoind stand-in recording every call it receives."""

    def __init__(self):
        self.calls = []          # list of (method, params)
        self.submit_mode = "ok"  # or "stale" to answer -8
        self.submit_failures_remaining = 0  # fail N submits with -8, then ok
        self.template_target_override = None  # replace template _target
        # Fix-round extensions (all default to pre-fix-round behaviour):
        self.submit_result_override = _UNSET  # e.g. False / None (item B5)
        self.submit_error_override = None     # {"code":..,"message":..} (B6)
        self.template_hash_override = None    # fresh template hash (B7)
        self.template_chainid_override = None  # e.g. 57 (item B16)
        self.createauxblock_mode = "ok"       # or "error" (item B16)
        self.getblockcount_value = 104632
        self.chain_blocks = {}   # hash -> block dict served by getblock (B6)
        # FOLLOW-UP 2026-10-26 (R2): height -> hash served by
        # getblockhash.  An explicit entry wins; otherwise the hash
        # is derived from chain_blocks (a block dict whose "height"
        # matches).  The pre-R2 mock had NO getblockhash at all (it
        # answered -32601 "Method not found"), which no real daemon
        # does -- that gap is what the two B6 chain-resolution tests
        # tripped over once resolution required getblockhash
        # equality (see ITEM2-REPORT.md, test-conflict section).
        # No existing test assertion is changed by this addition.
        self.chain_hash_by_height = {}

        outer = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_POST(self):
                length = int(self.headers.get("Content-Length") or 0)
                body = self.rfile.read(length)
                request = json.loads(body.decode())
                items = request if isinstance(request, list) else [request]
                replies = []
                for item in items:
                    method, params = item.get("method"), item.get("params", [])
                    outer.calls.append((method, params))
                    replies.append(outer.dispatch(item["id"], method, params))
                payload = replies if isinstance(request, list) else replies[0]
                raw = json.dumps(payload).encode()
                # bitcoind-style: RPC errors ride on HTTP 500.
                status = 500 if any(r.get("error") for r in replies) else 200
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.port = self.server.server_address[1]
        threading.Thread(target=self.server.serve_forever,
                         daemon=True).start()

    def _register_on_chain(self, params):
        # Freeze v2.3 (contract C2): a daemon that answers
        # result:true for a submission has CONNECTED the block, so
        # the mock puts it on its active chain (unless a test
        # already registered that hash explicitly -- a pre-set
        # entry, e.g. a fork-only block, always wins). The
        # adapter's C2 visibility gate (getblock confirmations >= 0
        # AND getblockhash(height) == hash) can then pass exactly
        # as it would against a real daemon.
        if not params:
            return
        block_hash = params[0]
        if block_hash in self.chain_blocks:
            return
        self.chain_blocks[block_hash] = {
            "hash": block_hash, "height": 104632, "confirmations": 1}
        self.chain_hash_by_height[104632] = block_hash

    def dispatch(self, request_id, method, params):
        ok = {"jsonrpc": "1.0", "id": request_id, "error": None}
        if method == "getauxblock":
            # The REAL daemon's wallet error.  If the shim ever sends
            # getauxblock upstream (Invariant I-1 break, defect D1),
            # this -19 is what would leak to the caller.
            return {"jsonrpc": "1.0", "id": request_id, "result": None,
                    "error": {"code": -19,
                              "message": "Wallet file not specified (stub -19)"}}
        if method == "createauxblock":
            assert params == [PAYOUT], params
            if self.createauxblock_mode == "error":
                return {"jsonrpc": "1.0", "id": request_id, "result": None,
                        "error": {"code": -1,
                                  "message": "nevm-data-not-found"}}
            template = make_template()
            if self.template_target_override is not None:
                template["_target"] = self.template_target_override
            if self.template_hash_override is not None:
                template["hash"] = self.template_hash_override
            if self.template_chainid_override is not None:
                template["chainid"] = self.template_chainid_override
            return dict(ok, result=template)
        if method == "submitauxblock":
            if self.submit_failures_remaining > 0:
                self.submit_failures_remaining -= 1
                return {"jsonrpc": "1.0", "id": request_id, "result": None,
                        "error": {"code": -8, "message": "block hash unknown"}}
            if self.submit_mode == "stale":
                return {"jsonrpc": "1.0", "id": request_id, "result": None,
                        "error": {"code": -8, "message": "block hash unknown"}}
            if self.submit_error_override is not None:
                return {"jsonrpc": "1.0", "id": request_id, "result": None,
                        "error": dict(self.submit_error_override)}
            if self.submit_result_override is not _UNSET:
                # Item B5 shape: a result payload with error:null that
                # is NOT True (the real daemon returns ProcessNewBlock's
                # bool, so False here is a genuine daemon rejection).
                if self.submit_result_override is True:
                    self._register_on_chain(params)
                return dict(ok, result=self.submit_result_override)
            self._register_on_chain(params)
            return dict(ok, result=True)
        if method == "getblock":
            block = self.chain_blocks.get(params[0]) if params else None
            if block is not None:
                return dict(ok, result=block)
            return {"jsonrpc": "1.0", "id": request_id, "result": None,
                    "error": {"code": -5, "message": "Block not found"}}
        if method == "getblockhash":
            # FOLLOW-UP 2026-10-26 (R2): see chain_hash_by_height.
            height = params[0] if params else None
            if height in self.chain_hash_by_height:
                return dict(ok, result=self.chain_hash_by_height[height])
            for block_hash, block in self.chain_blocks.items():
                if isinstance(block, dict) \
                        and block.get("height") == height:
                    return dict(ok, result=block_hash)
            return {"jsonrpc": "1.0", "id": request_id, "result": None,
                    "error": {"code": -8,
                              "message": "Block height out of range"}}
        if method == "getblockcount":
            return dict(ok, result=self.getblockcount_value)
        if method == "getblocktemplate":
            return dict(ok, result={"height": 104632, "coinbaseaux": {}})
        return {"jsonrpc": "1.0", "id": request_id, "result": None,
                "error": {"code": -32601, "message": "Method not found"}}

    def stop(self):
        self.server.shutdown()
        self.server.server_close()


class QuietLogger(adapter.StructuredLogger):
    def log(self, level, event, **fields):  # keep test output clean
        self.last = (level, event, fields)
        if not hasattr(self, "events"):
            self.events = []
        self.events.append((level, event, fields))

    def event_names(self):
        return [event for _level, event, _fields in getattr(self, "events", [])]


class VerbatimTargetTests(unittest.TestCase):
    # Per BYTE-ORDER-VERDICT.md §6(iii): emitted target == _target
    # verbatim, and yiimp's extractor on it == decode_compact(bits)
    # mantissa, for both live vectors.
    def test_sample_from_07_md_verbatim(self):
        result = adapter.add_target_field(make_template())
        self.assertEqual(result["target"], SAMPLE_UNDERSCORE_TARGET)
        self.assertEqual(result["target"], SAMPLE_TARGET)

    def test_sample_from_01_md_verbatim(self):
        template = dict(make_template(),
                        _target=SAMPLE2_UNDERSCORE_TARGET,
                        bits=SAMPLE2_BITS)
        result = adapter.add_target_field(template)
        self.assertEqual(result["target"], SAMPLE2_UNDERSCORE_TARGET)
        self.assertEqual(result["target"], SAMPLE2_TARGET)

    def test_extractor_matches_mantissa_07_md(self):
        result = adapter.add_target_field(make_template())
        extracted = yiimp_get_hash_difficulty(
            yiimp_binlify(result["target"]))
        self.assertEqual(extracted, SAMPLE_MANTISSA)
        self.assertEqual(extracted, 0x35be6a)
        self.assertEqual(extracted, decode_compact_mantissa(SAMPLE_BITS))

    def test_extractor_matches_mantissa_01_md(self):
        template = dict(make_template(),
                        _target=SAMPLE2_UNDERSCORE_TARGET,
                        bits=SAMPLE2_BITS)
        result = adapter.add_target_field(template)
        extracted = yiimp_get_hash_difficulty(
            yiimp_binlify(result["target"]))
        self.assertEqual(extracted, SAMPLE2_MANTISSA)
        self.assertEqual(extracted, 0x3801a9)
        self.assertEqual(extracted, decode_compact_mantissa(SAMPLE2_BITS))

    def test_add_target_field(self):
        result = adapter.add_target_field(make_template())
        self.assertEqual(result["target"], SAMPLE_UNDERSCORE_TARGET)
        self.assertEqual(result["_target"], SAMPLE_UNDERSCORE_TARGET)

    def test_add_target_never_overwrites_existing_target(self):
        template = dict(make_template(), target="keepme")
        self.assertEqual(adapter.add_target_field(template)["target"],
                         "keepme")

    def test_add_target_malformed_invents_nothing(self):
        template = dict(make_template(), _target="not-hex")
        self.assertNotIn("target", adapter.add_target_field(template))


class TranslationTests(unittest.TestCase):
    def test_parameterless_getauxblock(self):
        new, desc = adapter.translate_request(
            {"method": "getauxblock", "params": [], "id": 7}, PAYOUT)
        self.assertEqual(new["method"], "createauxblock")
        self.assertEqual(new["params"], [PAYOUT])
        self.assertEqual(new["id"], 7)
        self.assertIsNotNone(desc)

    def test_submit_getauxblock(self):
        new, _ = adapter.translate_request(
            {"method": "getauxblock", "params": ["ab" * 32, "deadbeef"],
             "id": 8}, PAYOUT)
        self.assertEqual(new["method"], "submitauxblock")
        self.assertEqual(new["params"], ["ab" * 32, "deadbeef"])

    def test_other_forms_untouched(self):
        for params in ([1], [1, 2, 3], {"named": True}):
            req = {"method": "getauxblock", "params": params, "id": 1}
            new, desc = adapter.translate_request(req, PAYOUT)
            self.assertIs(new, req)
            self.assertIsNone(desc)

    def test_non_aux_untouched(self):
        req = {"method": "getblocktemplate", "params": [{"rules": ["segwit"]}]}
        new, desc = adapter.translate_request(req, PAYOUT)
        self.assertIs(new, req)
        self.assertIsNone(desc)


class EndToEndTests(unittest.TestCase):
    """Shim in front of the mock daemon, driven over real HTTP."""

    @classmethod
    def setUpClass(cls):
        cls.daemon = MockDaemon()
        config = dict(adapter.DEFAULTS)
        cls.spool_dir = tempfile.mkdtemp(prefix="adapter-test-spool-")
        config.update({
            "daemon_host": "127.0.0.1", "daemon_port": str(cls.daemon.port),
            "daemon_user": "user", "daemon_password": "pass",
            "payout_address": PAYOUT, "tip_poll_seconds": "3600",
            # Legacy configuration: exactly the original no-retry
            # behaviour, so the original assertions below run verbatim.
            # Retry/spool/alarm are covered in InvestigationATests.
            "submit_retry_attempts": "1",
            "submit_retry_delay_seconds": "0",
            "alarm_delay_seconds": "0",  # v2.3 C7: alarm-mechanics tests use the immediate path; the ~90s window has its own tests
            "spool_dir": cls.spool_dir,
            "alarm_file": os.path.join(cls.spool_dir, "ALARM_TEST"),
        })
        cls.logger = QuietLogger()
        cls.core = adapter.AdapterCore(config, cls.logger)
        cls.server = ThreadingHTTPServer(
            ("127.0.0.1", 0), adapter.make_handler(cls.core))
        cls.url = "http://127.0.0.1:%d/" % cls.server.server_address[1]
        threading.Thread(target=cls.server.serve_forever,
                         daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.daemon.stop()

    def rpc(self, payload):
        return self.rpc_status(payload)[1]

    def rpc_status(self, payload, path="/", headers=None):
        """Like rpc(), but also returns the HTTP status (defect D3:
        the shipped suite never asserted a status, which is how the
        200-on-error bug shipped)."""
        body = payload if isinstance(payload, bytes) \
            else json.dumps(payload).encode()
        url = self.url.rstrip("/") + path
        req = urllib.request.Request(url, data=body, method="POST")
        req.add_header("Content-Type", "application/json")
        for key, value in (headers or {}).items():
            req.add_header(key, value)
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return resp.status, json.loads(resp.read().decode())
        except urllib.error.HTTPError as exc:
            raw = exc.read().decode()
            try:
                return exc.code, json.loads(raw)
            except ValueError:
                return exc.code, raw

    def get_status(self, path, headers=None):
        req = urllib.request.Request(self.url.rstrip("/") + path,
                                     method="GET")
        for key, value in (headers or {}).items():
            req.add_header(key, value)
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                raw = resp.read().decode()
                try:
                    return resp.status, json.loads(raw)
                except ValueError:
                    return resp.status, raw
        except urllib.error.HTTPError as exc:
            raw = exc.read().decode()
            try:
                return exc.code, json.loads(raw)
            except ValueError:
                return exc.code, raw

    def raw_post(self, request_bytes):
        """Send raw bytes over a socket; return the raw response."""
        host, port = self.url.split("//", 1)[1].rstrip("/").split(":")
        with socket.create_connection((host, int(port)), timeout=10) as sock:
            sock.sendall(request_bytes)
            chunks = []
            while True:
                try:
                    chunk = sock.recv(65536)
                except socket.timeout:
                    break
                if not chunk:
                    break
                chunks.append(chunk)
                joined = b"".join(chunks)
                if b"\r\n\r\n" in joined:
                    head, _, rest = joined.partition(b"\r\n\r\n")
                    length = None
                    for line in head.split(b"\r\n"):
                        if line.lower().startswith(b"content-length:"):
                            length = int(line.split(b":", 1)[1])
                    if length is not None and len(rest) >= length:
                        break
        return b"".join(chunks)

    def test_getauxblock_returns_target_and_chainid_29(self):
        """THE acceptance shape: both `target` and "chainid": 29."""
        self.daemon.calls.clear()
        reply = self.rpc({"jsonrpc": "1.0", "id": "yiimp-1",
                          "method": "getauxblock", "params": []})
        result = reply["result"]
        self.assertEqual(reply["id"], "yiimp-1")       # id preserved
        self.assertEqual(result["chainid"], 29)
        self.assertEqual(result["target"], SAMPLE_TARGET)
        self.assertEqual(result["_target"], SAMPLE_UNDERSCORE_TARGET)
        # ...and the daemon really was asked via createauxblock.
        self.assertEqual(self.daemon.calls,
                         [("createauxblock", [PAYOUT])])

    def test_getauxblock_submit_translates(self):
        self.daemon.calls.clear()
        reply = self.rpc({"jsonrpc": "1.0", "id": 42, "method": "getauxblock",
                          "params": [TEMPLATE_HASH, "aabbcc"]})
        self.assertEqual(reply["result"], True)
        # v2.3 contract C2: after the submit, the adapter verifies
        # the block on the daemon's active chain (getblock +
        # getblockhash) before crediting the bare result:true --
        # those two read calls are part of the expected sequence.
        self.assertEqual(self.daemon.calls,
                         [("submitauxblock", [TEMPLATE_HASH, "aabbcc"]),
                          ("getblock", [TEMPLATE_HASH]),
                          ("getblockhash", [104632])])

    def test_stale_submit_error_passthrough_and_no_retry(self):
        self.daemon.submit_mode = "stale"
        try:
            self.daemon.calls.clear()
            reply = self.rpc({"jsonrpc": "1.0", "id": 43,
                              "method": "getauxblock",
                              "params": [TEMPLATE_HASH, "aabbcc"]})
            self.assertEqual(reply["error"]["code"], -8)
            self.assertEqual(reply["error"]["message"],
                             "block hash unknown")
            # Exactly one daemon call: this fixture pins
            # submit_retry_attempts=1 (legacy configuration).
            self.assertEqual(len(self.daemon.calls), 1)
            # ...the -8 was logged as a stale-template event, AND the
            # final failure raised the Investigation-A alarm (which is
            # why logger.last is no longer the -8 event itself).
            self.assertIn("stale_template_submit_-8",
                          self.logger.event_names())
            self.assertIn("ALARM_SUBMISSION_FAILED",
                          self.logger.event_names())
        finally:
            self.daemon.submit_mode = "ok"

    def test_non_aux_passthrough(self):
        self.daemon.calls.clear()
        reply = self.rpc({"jsonrpc": "1.0", "id": 99,
                          "method": "getblocktemplate",
                          "params": [{"rules": ["segwit"]}]})
        self.assertEqual(reply["result"]["height"], 104632)
        self.assertEqual(self.daemon.calls,
                         [("getblocktemplate", [{"rules": ["segwit"]}])])

    def test_daemon_error_passthrough(self):
        reply = self.rpc({"jsonrpc": "1.0", "id": 5,
                          "method": "nosuchmethod", "params": []})
        self.assertEqual(reply["error"]["code"], -32601)
        self.assertEqual(reply["id"], 5)

    def test_batch_translated_per_element(self):
        self.daemon.calls.clear()
        reply = self.rpc([
            {"jsonrpc": "1.0", "id": 1, "method": "getauxblock",
             "params": []},
            {"jsonrpc": "1.0", "id": 2, "method": "getblockcount",
             "params": []},
        ])
        self.assertEqual(len(reply), 2)
        self.assertEqual(reply[0]["result"]["target"], SAMPLE_TARGET)
        self.assertEqual(reply[1]["result"], 104632)
        self.assertEqual(self.daemon.calls,
                         [("createauxblock", [PAYOUT]),
                          ("getblockcount", [])])


class HardeningTests(EndToEndTests):
    """Regression tests for the QA hardening round (QA-REPORT.md).

    Inherits the mock-daemon shim fixture (and re-runs the base
    end-to-end tests against it).
    """

    # D-E2E-1 / D3 -- upstream HTTP status is preserved on every path.
    def test_status_good_template_is_200(self):
        status, reply = self.rpc_status(
            {"jsonrpc": "1.0", "id": 300, "method": "getauxblock",
             "params": []})
        self.assertEqual(status, 200)
        self.assertEqual(reply["result"]["target"], SAMPLE_TARGET)

    def test_status_translated_error_is_500(self):
        self.daemon.submit_mode = "stale"
        try:
            status, reply = self.rpc_status(
                {"jsonrpc": "1.0", "id": 301, "method": "getauxblock",
                 "params": [TEMPLATE_HASH, "aabbcc"]})
        finally:
            self.daemon.submit_mode = "ok"
        self.assertEqual(status, 500)
        self.assertEqual(reply["error"]["code"], -8)
        self.assertEqual(reply["id"], 301)

    def test_status_batch_error_is_500_success_is_200(self):
        status, reply = self.rpc_status([
            {"jsonrpc": "1.0", "id": 302, "method": "getblockcount",
             "params": []}])
        self.assertEqual(status, 200)
        self.daemon.submit_mode = "stale"
        try:
            status, reply = self.rpc_status([
                {"jsonrpc": "1.0", "id": 303, "method": "getauxblock",
                 "params": [TEMPLATE_HASH, "aabbcc"]},
                {"jsonrpc": "1.0", "id": 304, "method": "getblockcount",
                 "params": []}])
        finally:
            self.daemon.submit_mode = "ok"
        self.assertEqual(status, 500)  # any element errored -> 500
        self.assertEqual(reply[0]["error"]["code"], -8)
        self.assertEqual(reply[1]["result"], 104632)

    # D1 -- odd-form getauxblock: local -32602, ZERO daemon calls,
    # and the daemon's -19 can never surface.
    def test_odd_getauxblock_forms_rejected_locally(self):
        odd_forms = [
            {"a": 1},                    # dict / named params
            "oops",                      # non-array params
            None,                        # null params
            ["onlyone"],                 # 1 param
            ["a", "b", "c"],             # 3 params
            [123, 456],                  # non-string submit params
            ["ab" * 32, 123],            # one non-string submit param
        ]
        for params in odd_forms:
            self.daemon.calls.clear()
            status, reply = self.rpc_status(
                {"jsonrpc": "1.0", "id": 310, "method": "getauxblock",
                 "params": params})
            self.assertEqual(status, 500, params)
            self.assertEqual(reply["error"]["code"], -32602, params)
            self.assertNotEqual(reply["error"]["code"], -19, params)
            self.assertEqual(reply["id"], 310, params)
            self.assertEqual(self.daemon.calls, [], params)

    def test_odd_getauxblock_in_batch_never_upstream(self):
        self.daemon.calls.clear()
        status, reply = self.rpc_status([
            {"jsonrpc": "1.0", "id": 311, "method": "getauxblock",
             "params": ["onlyone"]},
            {"jsonrpc": "1.0", "id": 312, "method": "getblockcount",
             "params": []}])
        self.assertEqual(reply[0]["error"]["code"], -32602)
        # Exactly one upstream call: the getblockcount element only.
        self.assertEqual(self.daemon.calls, [("getblockcount", [])])

    # D2b -- deny-list: blocked locally, daemon never contacted.
    def test_denied_methods_blocked_locally(self):
        for method in ("stop", "sendtoaddress", "sendmany", "sendfrom",
                       "dumpprivkey", "dumpwallet", "backupwallet",
                       "importprivkey", "encryptwallet",
                       "walletpassphrase", "setaccount", "move",
                       "walletlock", "walletcreatefundedpsbt"):
            self.daemon.calls.clear()
            status, reply = self.rpc_status(
                {"jsonrpc": "1.0", "id": 320, "method": method,
                 "params": []})
            self.assertEqual(status, 500, method)
            self.assertEqual(reply["error"]["code"], -32601, method)
            self.assertEqual(self.daemon.calls, [], method)

    # D2a -- RPC only on the configured POST path.
    def test_rpc_on_wrong_path_is_404_json_and_not_forwarded(self):
        self.daemon.calls.clear()
        for path in ("/evil-random-path", "/wallet/foo", "/health"):
            status, reply = self.rpc_status(
                {"jsonrpc": "1.0", "id": 330, "method": "getblockcount",
                 "params": []}, path=path)
            self.assertEqual(status, 404, path)
            self.assertIn("error", reply, path)
        self.assertEqual(self.daemon.calls, [])

    # D5 -- short / empty _target fabricates nothing + ERROR log.
    def test_short_and_empty_target_not_injected(self):
        for bad_target in ("aabb", ""):
            self.daemon.template_target_override = bad_target
            try:
                status, reply = self.rpc_status(
                    {"jsonrpc": "1.0", "id": 340, "method": "getauxblock",
                     "params": []})
            finally:
                self.daemon.template_target_override = None
            self.assertEqual(status, 200, bad_target)
            self.assertNotIn("target", reply["result"], bad_target)
            self.assertEqual(reply["result"]["_target"], bad_target)
            self.assertEqual(self.logger.last[1],
                             "TEMPLATE_TARGET_MALFORMED", bad_target)

    # D6 -- malformed Content-Length: clean JSON error, shim keeps
    # serving afterwards.
    def test_malformed_content_length_then_good_request(self):
        for bad_value in (b"not-a-number", b"-5"):
            response = self.raw_post(
                b"POST / HTTP/1.1\r\nHost: 127.0.0.1\r\n"
                b"Content-Type: application/json\r\n"
                b"Content-Length: " + bad_value + b"\r\n\r\n")
            self.assertIn(b"400", response.split(b"\r\n", 1)[0])
            self.assertIn(b"-32600", response)
            # ...and a good request right after still works.
            status, reply = self.rpc_status(
                {"jsonrpc": "1.0", "id": 350, "method": "getblockcount",
                 "params": []})
            self.assertEqual(status, 200)
            self.assertEqual(reply["result"], 104632)

    # D7 -- /notify: exact path only, and NO synchronous daemon call.
    def test_notify_exact_path_and_no_daemon_call(self):
        status, _ = self.get_status("/notifyXYZ")
        self.assertEqual(status, 404)
        status, _ = self.get_status("/healthXYZ")
        self.assertEqual(status, 404)
        self.daemon.calls.clear()
        pokes_before = self.core.tip_tracker.poke_count
        status, body = self.get_status("/notify?hash=" + "ab" * 32)
        self.assertEqual(status, 200)
        self.assertEqual(self.core.tip_tracker.poke_count,
                         pokes_before + 1)
        self.assertEqual(self.core.tip_tracker.last_poke_hash, "ab" * 32)
        # The poke made no daemon call at all.
        self.assertEqual(self.daemon.calls, [])

    # D9 -- /health: truthful reachability, no payout / daemon URL.
    def test_health_truthful_and_no_disclosure(self):
        self.core.tip_tracker.daemon_reachable = True
        status, body = self.get_status("/health")
        self.assertEqual(status, 200)
        self.assertEqual(body["status"], "ok")
        self.assertTrue(body["daemon_reachable"])
        self.assertNotIn("payout_address", body)
        self.assertNotIn("daemon", body)
        self.core.tip_tracker.daemon_reachable = False
        status, body = self.get_status("/health")
        self.assertEqual(status, 200)
        self.assertEqual(body["status"], "degraded")
        self.assertFalse(body["daemon_reachable"])

    # D12 -- direct submitauxblock -8 gets the stale-submit log event.
    def test_direct_submitauxblock_stale_is_logged(self):
        self.daemon.submit_mode = "stale"
        try:
            self.daemon.calls.clear()
            status, reply = self.rpc_status(
                {"jsonrpc": "1.0", "id": 360, "method": "submitauxblock",
                 "params": [TEMPLATE_HASH, "aabbcc"]})
        finally:
            self.daemon.submit_mode = "ok"
        self.assertEqual(status, 500)
        self.assertEqual(reply["error"]["code"], -8)
        self.assertEqual(len(self.daemon.calls), 1)
        stale_events = [f for _l, e, f in self.logger.events
                        if e == "stale_template_submit_-8"]
        self.assertTrue(stale_events)
        self.assertEqual(stale_events[-1]["submitted_hash"], TEMPLATE_HASH)

    # D8 -- oversized body is refused (on the declared length, before
    # the body is read or anything is forwarded).
    def test_oversized_body_rejected(self):
        self.daemon.calls.clear()
        response = self.raw_post(
            b"POST / HTTP/1.1\r\nHost: 127.0.0.1\r\n"
            b"Content-Type: application/json\r\n"
            b"Content-Length: %d\r\n\r\n" % (self.core.max_request_bytes + 1)
            + b"x" * 16)
        self.assertIn(b"413", response.split(b"\r\n", 1)[0])
        self.assertIn(b"-32600", response)
        self.assertEqual(self.daemon.calls, [])

    # D4/D11 -- shim-side handling echoes ids; a missing id is null.
    def test_missing_id_returns_null_not_zero(self):
        status, reply = self.rpc_status(
            {"jsonrpc": "1.0", "method": "getauxblock", "params": []})
        self.assertEqual(status, 200)
        self.assertIsNone(reply["id"])


class StartupGateTests(unittest.TestCase):
    """D2c + D10 startup gates, tested at the refusal function."""

    def _config(self, **overrides):
        config = dict(adapter.DEFAULTS)
        config.update({"payout_address": PAYOUT})
        config.update(overrides)
        return config

    def test_missing_payout_refused_exit_2(self):
        refusal = adapter.startup_refusal(self._config(payout_address=""))
        self.assertEqual(refusal[0], 2)
        self.assertEqual(refusal[1], "config_missing_payout_address")

    def test_invalid_payout_refused_exit_2_says_invalid(self):
        refusal = adapter.startup_refusal(
            self._config(payout_address="not-a-real-address"))
        self.assertEqual(refusal[0], 2)
        self.assertEqual(refusal[1], "config_invalid_payout_address")
        self.assertIn("INVALID", refusal[2])

    def test_valid_payout_shapes_accepted(self):
        self.assertIsNone(adapter.startup_refusal(self._config()))
        # Regtest form (used by the live harness) and base58 shape.
        self.assertIsNone(adapter.startup_refusal(self._config(
            payout_address="bcrt1qtyp9gu2etavhhxqkd00allr937u8tl"
                           "xwry82jg")))
        self.assertTrue(adapter.is_valid_payout_address(
            "1BoatSLRHtKNngkdXEeobR76b53LETtpyT"))

    def test_public_bind_without_token_refused(self):
        refusal = adapter.startup_refusal(
            self._config(listen_host="0.0.0.0"))
        self.assertEqual(refusal[0], 2)
        self.assertEqual(refusal[1], "config_unsafe_listen_host")

    def test_public_bind_with_token_or_acknowledgement_ok(self):
        self.assertIsNone(adapter.startup_refusal(self._config(
            listen_host="0.0.0.0", adapter_token="tok123")))
        self.assertIsNone(adapter.startup_refusal(self._config(
            listen_host="0.0.0.0", i_understand_public_bind="true")))

    def test_loopback_bind_needs_no_token(self):
        self.assertIsNone(adapter.startup_refusal(self._config(
            listen_host="127.0.0.1")))
        self.assertIsNone(adapter.startup_refusal(self._config(
            listen_host="localhost")))


class TokenAuthTests(unittest.TestCase):
    """D2c/D7: adapter_token is required on RPC and on /notify."""

    @classmethod
    def setUpClass(cls):
        cls.daemon = MockDaemon()
        config = dict(adapter.DEFAULTS)
        config.update({
            "daemon_host": "127.0.0.1", "daemon_port": str(cls.daemon.port),
            "daemon_user": "user", "daemon_password": "pass",
            "payout_address": PAYOUT, "tip_poll_seconds": "3600",
            "adapter_token": "test-token-123",
            "submit_retry_delay_seconds": "0",
            "alarm_delay_seconds": "0",  # v2.3 C7: alarm-mechanics tests use the immediate path; the ~90s window has its own tests
            "spool_dir": tempfile.mkdtemp(prefix="adapter-test-spool-"),
        })
        cls.core = adapter.AdapterCore(config, QuietLogger())
        cls.server = ThreadingHTTPServer(
            ("127.0.0.1", 0), adapter.make_handler(cls.core))
        cls.url = "http://127.0.0.1:%d/" % cls.server.server_address[1]
        threading.Thread(target=cls.server.serve_forever,
                         daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.daemon.stop()

    def _call(self, path, headers=None, payload=None):
        if payload is None:
            req = urllib.request.Request(self.url.rstrip("/") + path,
                                         method="GET")
        else:
            req = urllib.request.Request(
                self.url.rstrip("/") + path,
                data=json.dumps(payload).encode(), method="POST")
            req.add_header("Content-Type", "application/json")
        for key, value in (headers or {}).items():
            req.add_header(key, value)
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return resp.status, resp.read().decode()
        except urllib.error.HTTPError as exc:
            return exc.code, exc.read().decode()

    def test_rpc_without_token_is_403_and_not_forwarded(self):
        self.daemon.calls.clear()
        status, _ = self._call("/", payload={
            "jsonrpc": "1.0", "id": 1, "method": "getblockcount",
            "params": []})
        self.assertEqual(status, 403)
        self.assertEqual(self.daemon.calls, [])

    def test_rpc_with_token_header_and_basic_work(self):
        status, body = self._call(
            "/", headers={"X-Adapter-Token": "test-token-123"},
            payload={"jsonrpc": "1.0", "id": 2, "method": "getblockcount",
                     "params": []})
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)["result"], 104632)
        import base64 as _b64
        basic = "Basic " + _b64.b64encode(b"yiimp:test-token-123").decode()
        status, body = self._call(
            "/", headers={"Authorization": basic},
            payload={"jsonrpc": "1.0", "id": 3, "method": "getblockcount",
                     "params": []})
        self.assertEqual(status, 200)

    def test_notify_and_health_require_token(self):
        status, body = self._call("/notify")
        self.assertEqual(status, 403)
        self.assertNotIn(PAYOUT, body)
        status, body = self._call(
            "/notify", headers={"X-Adapter-Token": "test-token-123"})
        self.assertEqual(status, 200)
        status, body = self._call("/health")
        self.assertEqual(status, 403)
        self.assertNotIn(PAYOUT, body)
        self.assertNotIn("127.0.0.1", body.split('"tip"')[0])



class InvestigationATests(unittest.TestCase):
    """Investigation-A upgrades: retry-with-refresh, disk spool, alarm,
    startup replay.  Own fixture: attempts=3, delay=0, isolated spool."""

    AUXPOW = "aabbccddeeff00112233"

    def setUp(self):
        self.daemon = MockDaemon()
        self.spool_dir = tempfile.mkdtemp(prefix="adapter-ia-spool-")
        self.alarm_file = os.path.join(self.spool_dir, "ALARM_TEST")
        self.logger = QuietLogger()
        self.core = self._make_core()
        self.server = ThreadingHTTPServer(
            ("127.0.0.1", 0), adapter.make_handler(self.core))
        self.url = "http://127.0.0.1:%d/" % self.server.server_address[1]
        threading.Thread(target=self.server.serve_forever,
                         daemon=True).start()

    def tearDown(self):
        self.server.shutdown()
        self.daemon.stop()

    def _make_core(self):
        config = dict(adapter.DEFAULTS)
        config.update({
            "daemon_host": "127.0.0.1", "daemon_port": str(self.daemon.port),
            "daemon_user": "user", "daemon_password": "pass",
            "payout_address": PAYOUT, "tip_poll_seconds": "3600",
            "submit_retry_attempts": "3",
            "submit_retry_delay_seconds": "0",
            "alarm_delay_seconds": "0",  # v2.3 C7: alarm-mechanics tests use the immediate path; the ~90s window has its own tests
            "spool_dir": self.spool_dir,
            "alarm_file": self.alarm_file,
        })
        return adapter.AdapterCore(config, self.logger)

    def rpc(self, payload):
        body = json.dumps(payload).encode()
        req = urllib.request.Request(self.url, data=body, method="POST")
        req.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return resp.status, json.loads(resp.read().decode())
        except urllib.error.HTTPError as exc:
            return exc.code, json.loads(exc.read().decode())

    def submit(self):
        return self.rpc({"jsonrpc": "1.0", "id": 77,
                         "method": "getauxblock",
                         "params": [TEMPLATE_HASH, self.AUXPOW]})

    def submit_calls(self):
        return [c for c in self.daemon.calls if c[0] == "submitauxblock"]

    def refresh_calls(self):
        return [c for c in self.daemon.calls if c[0] == "createauxblock"]

    def spool_files(self):
        return [n for n in os.listdir(self.spool_dir)
                if n.endswith(".json")]

    # -- retry-with-refresh: transient -8 recovers ----------------------
    def test_minus8_then_recover(self):
        self.daemon.submit_failures_remaining = 1  # first submit: -8
        status, reply = self.submit()
        self.assertEqual(status, 200)
        self.assertEqual(reply["result"], True)      # genuinely accepted
        self.assertEqual(reply["id"], 77)
        # 2 submits (1 failed + 1 retry), 1 refresh between them.
        self.assertEqual(len(self.submit_calls()), 2)
        self.assertEqual(len(self.refresh_calls()), 1)
        # Accepted => spool entry removed, no alarm marker.
        self.assertEqual(self.spool_files(), [])
        self.assertFalse(os.path.exists(self.alarm_file))
        names = self.logger.event_names()
        self.assertIn("stale_template_submit_-8", names)
        self.assertIn("submit_retry_refresh", names)
        self.assertIn("submit_accepted_after_retry", names)
        self.assertNotIn("ALARM_SUBMISSION_FAILED", names)

    def test_retry_never_substitutes_fresh_template(self):
        # The refresh returns a template whose hash is TEMPLATE_HASH
        # here only because the mock is static; assert the stronger
        # invariant directly: every submit carries the ORIGINAL pair.
        self.daemon.submit_failures_remaining = 2
        status, reply = self.submit()
        self.assertEqual(reply["result"], True)
        for _method, params in self.submit_calls():
            self.assertEqual(params, [TEMPLATE_HASH, self.AUXPOW])

    # -- persistent -8: spool retained + alarm + honest error -----------
    def test_persistent_minus8_spool_retained_and_alarm(self):
        self.daemon.submit_mode = "stale"
        status, reply = self.submit()
        # The daemon's own error comes back -- never a faked success.
        self.assertEqual(status, 500)
        self.assertEqual(reply["error"]["code"], -8)
        self.assertEqual(reply["error"]["message"], "block hash unknown")
        # Bounded: exactly 3 submits, refresh between attempts (2).
        self.assertEqual(len(self.submit_calls()), 3)
        self.assertEqual(len(self.refresh_calls()), 2)
        # Spool entry retained, with the exact found solution inside.
        files = self.spool_files()
        self.assertEqual(len(files), 1)
        with open(os.path.join(self.spool_dir, files[0])) as fh:
            entry = json.load(fh)
        self.assertEqual(entry["hash"], TEMPLATE_HASH)
        self.assertEqual(entry["auxpow"], self.AUXPOW)
        self.assertEqual(entry["attempts"], 3)
        self.assertIn("-8", entry["last_error"])
        # Alarm: log event AND on-disk marker naming the hash.
        self.assertIn("ALARM_SUBMISSION_FAILED", self.logger.event_names())
        self.assertTrue(os.path.exists(self.alarm_file))
        with open(self.alarm_file) as fh:
            marker = json.load(fh)
        self.assertEqual(marker["event"], "ALARM_SUBMISSION_FAILED")
        self.assertEqual(marker["hash"], TEMPLATE_HASH)
        self.assertEqual(marker["attempts"], 3)

    # -- restart replay ---------------------------------------------------
    def test_restart_replay_recovers_spooled_solution(self):
        self.daemon.submit_mode = "stale"
        self.submit()
        self.assertEqual(len(self.spool_files()), 1)
        self.assertTrue(os.path.exists(self.alarm_file))
        # "Restart": daemon healthy again, a BRAND-NEW core whose only
        # knowledge of the find is the spool directory on disk.
        self.daemon.submit_mode = "ok"
        self.daemon.calls.clear()
        new_core = self._make_core()
        attempted, accepted = new_core.replay_spooled_submissions()
        self.assertEqual((attempted, accepted), (1, 1))
        self.assertEqual(self.submit_calls(),
                         [("submitauxblock", [TEMPLATE_HASH, self.AUXPOW])])
        self.assertEqual(self.spool_files(), [])       # confirmed => removed
        self.assertFalse(os.path.exists(self.alarm_file))  # alarm cleared

    def test_restart_replay_still_failing_keeps_spool_and_alarm(self):
        self.daemon.submit_mode = "stale"
        self.submit()
        self.daemon.calls.clear()
        new_core = self._make_core()
        attempted, accepted = new_core.replay_spooled_submissions()
        self.assertEqual((attempted, accepted), (1, 0))
        self.assertEqual(len(self.submit_calls()), 3)  # bounded again
        self.assertEqual(len(self.spool_files()), 1)   # still kept
        self.assertTrue(os.path.exists(self.alarm_file))

    # -- spool / alarm units ---------------------------------------------
    def test_spool_written_before_submit_and_removed_on_success(self):
        status, reply = self.submit()  # daemon ok, first attempt succeeds
        self.assertEqual(reply["result"], True)
        self.assertEqual(len(self.submit_calls()), 1)  # no needless retry
        self.assertEqual(self.spool_files(), [])
        self.assertIn("submission_spooled", self.logger.event_names())
        self.assertIn("submission_spool_confirmed_removed",
                      self.logger.event_names())

    def test_direct_submitauxblock_also_spooled_and_retried(self):
        self.daemon.submit_failures_remaining = 1
        status, reply = self.rpc({"jsonrpc": "1.0", "id": 78,
                                  "method": "submitauxblock",
                                  "params": [TEMPLATE_HASH, self.AUXPOW]})
        self.assertEqual(reply["result"], True)
        self.assertEqual(len(self.submit_calls()), 2)
        self.assertEqual(self.spool_files(), [])

    def test_retry_config_parsing_and_clamps(self):
        self.assertEqual(adapter.parse_retry_attempts("3"), 3)
        self.assertEqual(adapter.parse_retry_attempts("1"), 1)
        self.assertEqual(adapter.parse_retry_attempts("999"), 10)
        self.assertEqual(adapter.parse_retry_attempts("junk"), 3)
        self.assertEqual(adapter.parse_retry_delay("0"), 0.0)
        self.assertEqual(adapter.parse_retry_delay("junk"), 1.0)

    def test_spool_idempotent_and_pending_order(self):
        spool = self.core.spool
        spool.spool(TEMPLATE_HASH, self.AUXPOW)
        first_seen = spool.pending()[0]["first_seen"]
        spool.spool(TEMPLATE_HASH, self.AUXPOW)  # re-spool: no duplicate
        pending = spool.pending()
        self.assertEqual(len(pending), 1)
        self.assertEqual(pending[0]["first_seen"], first_seen)


class FixRoundTests(unittest.TestCase):
    """Fix round 2026-10-26: regression tests for attacker items
    B5, B6, B7, B11, B15, B16 and the Angle-3 alarm hardening.
    (B12 is a syscoin.conf.snippet change -- no adapter code path;
    it is verified textually in ../final/tests-results.txt.)"""

    AUXPOW = "aabbccddeeff00112233"
    HASH2 = "cd" * 32

    def _fresh(self, **overrides):
        daemon = MockDaemon()
        spool_dir = tempfile.mkdtemp(prefix="adapter-fix-spool-")
        alarm_file = os.path.join(spool_dir, "ALARM_TEST")
        logger = QuietLogger()
        config = dict(adapter.DEFAULTS)
        config.update({
            "daemon_host": "127.0.0.1", "daemon_port": str(daemon.port),
            "daemon_user": "user", "daemon_password": "pass",
            "payout_address": PAYOUT, "tip_poll_seconds": "3600",
            "submit_retry_attempts": "3",
            "submit_retry_delay_seconds": "0",
            "alarm_delay_seconds": "0",  # v2.3 C7: alarm-mechanics tests use the immediate path; the ~90s window has its own tests
            "spool_dir": spool_dir, "alarm_file": alarm_file,
        })
        config.update(overrides)
        core = adapter.AdapterCore(config, logger)
        self.addCleanup(daemon.stop)
        return daemon, core, spool_dir, alarm_file, logger

    def _core_on(self, daemon, spool_dir, alarm_file, logger):
        config = dict(adapter.DEFAULTS)
        config.update({
            "daemon_host": "127.0.0.1", "daemon_port": str(daemon.port),
            "daemon_user": "user", "daemon_password": "pass",
            "payout_address": PAYOUT, "tip_poll_seconds": "3600",
            "submit_retry_attempts": "3",
            "submit_retry_delay_seconds": "0",
            "alarm_delay_seconds": "0",  # v2.3 C7: alarm-mechanics tests use the immediate path; the ~90s window has its own tests
            "spool_dir": spool_dir, "alarm_file": alarm_file,
        })
        return adapter.AdapterCore(config, logger)

    @staticmethod
    def _submit_body(core, method="getauxblock"):
        status, raw = core.handle_body(json.dumps(
            {"jsonrpc": "1.0", "id": 77, "method": method,
             "params": [TEMPLATE_HASH, FixRoundTests.AUXPOW]}).encode())
        return status, json.loads(raw.decode())

    @staticmethod
    def _calls(daemon, method):
        return [c for c in daemon.calls if c[0] == method]

    @staticmethod
    def _spool_files(spool_dir):
        return [n for n in os.listdir(spool_dir) if n.endswith(".json")]

    # -- B5: acceptance requires result is True EXACTLY ------------------
    def test_result_false_null_and_other_payloads_are_failures(self):
        for bad in (False, None, 0, "accepted", {"stored": True}):
            with self.subTest(result=bad):
                daemon, core, spool_dir, alarm_file, logger = self._fresh()
                daemon.submit_result_override = bad
                status, reply = self._submit_body(core)
                # Caller gets a FAILURE, never a confirmed acceptance.
                self.assertEqual(status, 500)
                self.assertIsNotNone(reply["error"])
                self.assertNotEqual(reply.get("result"), True)
                # Bounded retries happened (refresh returned the same
                # template hash, so no B7 abort) -- EXCEPT a bare
                # result:False, which the INTERFACE-CONTRACT section 4
                # maps to "invalid" (reason null) after a visibility
                # check: never-retry, exactly 1 submission (v2.3 C3).
                self.assertEqual(
                    len(self._calls(daemon, "submitauxblock")),
                    1 if bad is False else 3)
                # ... the spool evidence SURVIVES ...
                self.assertEqual(len(self._spool_files(spool_dir)), 1)
                # ... and the alarm was raised.
                self.assertTrue(os.path.exists(alarm_file))
                self.assertIn("submit_result_not_true",
                              logger.event_names())
                self.assertIn("ALARM_SUBMISSION_FAILED",
                              logger.event_names())

    def test_result_false_direct_submitauxblock_also_failures(self):
        # The attacker scenario, direct-method shape.
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        daemon.submit_result_override = False
        status, reply = self._submit_body(core, method="submitauxblock")
        self.assertEqual(status, 500)
        self.assertIsNotNone(reply["error"])
        self.assertEqual(len(self._spool_files(spool_dir)), 1)
        self.assertTrue(os.path.exists(alarm_file))

    def test_result_true_is_accepted_and_spool_removed(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        status, reply = self._submit_body(core)
        self.assertEqual(status, 200)
        self.assertEqual(reply["result"], True)
        self.assertEqual(self._spool_files(spool_dir), [])
        self.assertFalse(os.path.exists(alarm_file))

    # -- B6: replay resolves blocks already on-chain ----------------------
    def test_replay_resolves_entry_already_on_chain(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        daemon.submit_mode = "stale"
        self._submit_body(core)  # fails: spool + alarm now on disk
        self.assertEqual(len(self._spool_files(spool_dir)), 1)
        self.assertTrue(os.path.exists(alarm_file))
        # The block turns out to BE on the daemon (its ack was lost).
        daemon.chain_blocks[TEMPLATE_HASH] = {
            "hash": TEMPLATE_HASH, "height": 104632, "confirmations": 5}
        daemon.calls.clear()
        logger2 = QuietLogger()
        core2 = self._core_on(daemon, spool_dir, alarm_file, logger2)
        attempted, resolved = core2.replay_spooled_submissions()
        self.assertEqual((attempted, resolved), (1, 1))
        # Resolved by the chain check ALONE: zero resubmissions.
        self.assertEqual(self._calls(daemon, "submitauxblock"), [])
        self.assertEqual(self._spool_files(spool_dir), [])
        self.assertFalse(os.path.exists(alarm_file))  # alarm cleared
        self.assertIn("replay_found_on_chain", logger2.event_names())

    def test_live_duplicate_error_resolved_against_chain(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        daemon.chain_blocks[TEMPLATE_HASH] = {
            "hash": TEMPLATE_HASH, "height": 104632, "confirmations": 1}
        daemon.submit_error_override = {
            "code": -27, "message": "duplicate block"}
        status, reply = self._submit_body(core)
        self.assertEqual(status, 200)
        self.assertEqual(reply["result"], True)  # verified on-chain
        self.assertEqual(self._spool_files(spool_dir), [])
        self.assertFalse(os.path.exists(alarm_file))
        self.assertIn("replay_found_on_chain", logger.event_names())
        # One submit + one getblock check; no blind retry storm.
        self.assertEqual(len(self._calls(daemon, "submitauxblock")), 1)
        self.assertEqual(len(self._calls(daemon, "getblock")), 1)

    def test_duplicate_error_but_not_on_chain_stays_spooled(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        daemon.submit_error_override = {
            "code": -27, "message": "duplicate block"}
        status, reply = self._submit_body(core)
        self.assertEqual(status, 500)
        self.assertEqual(len(self._spool_files(spool_dir)), 1)
        self.assertTrue(os.path.exists(alarm_file))

    # -- B7: retry abort when the refresh proves the template dead -------
    def _prime_template(self, core):
        status, raw = core.handle_body(json.dumps(
            {"jsonrpc": "1.0", "id": 1, "method": "getauxblock",
             "params": []}).encode())
        self.assertEqual(status, 200)

    def test_retry_aborts_after_one_submit_when_tip_moved(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        self._prime_template(core)  # TEMPLATE_HASH @ height 104632 seen
        daemon.template_hash_override = "ff" * 32  # fresh != submitted
        daemon.getblockcount_value = 104632        # tip AT entry height
        daemon.submit_mode = "stale"               # submits draw -8
        daemon.calls.clear()
        status, reply = self._submit_body(core)
        self.assertEqual(status, 500)
        self.assertEqual(reply["error"]["code"], -8)  # daemon error kept
        # Exactly 1 submit + 1 refresh -- NOT 3 + 2.
        self.assertEqual(len(self._calls(daemon, "submitauxblock")), 1)
        self.assertEqual(len(self._calls(daemon, "createauxblock")), 1)
        self.assertEqual(len(self._spool_files(spool_dir)), 1)
        self.assertTrue(os.path.exists(alarm_file))
        self.assertIn("submit_retry_aborted_template_dead",
                      logger.event_names())

    def test_retry_continues_when_tip_has_not_reached_entry_height(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        self._prime_template(core)
        daemon.template_hash_override = "ff" * 32  # fresh differs ...
        daemon.getblockcount_value = 104631        # ... but tip is BEHIND
        daemon.submit_mode = "stale"
        daemon.calls.clear()
        status, reply = self._submit_body(core)
        self.assertEqual(status, 500)
        # No abort: the full bounded retry ran (3 submits, 2 refreshes).
        self.assertEqual(len(self._calls(daemon, "submitauxblock")), 3)
        self.assertEqual(len(self._calls(daemon, "createauxblock")), 2)
        self.assertNotIn("submit_retry_aborted_template_dead",
                         logger.event_names())

    # -- B11: expanded RPC deny-list ---------------------------------------
    def test_denied_methods_expanded(self):
        denied = [
            # task minimum
            "setnetworkactive", "send", "sendall", "sendtoaddress",
            "createwallet", "loadwallet", "unloadwallet",
            "invalidateblock", "reconsiderblock", "addnode", "setban",
            "pruneblockchain",
            # same-class additions
            "disconnectnode", "clearbanned", "savemempool", "sendmany",
            "sendfrom", "bumpfee", "restorewallet", "migratewallet",
            "preciousblock", "submitheader", "generateblock",
            "generatetoaddress", "signrawtransactionwithwallet",
            "signmessagewithprivkey", "rescanblockchain",
            "keypoolrefill", "stop", "importaddress", "importmulti",
            "walletlock", "walletcreatefundedpsbt",
        ]
        for method in denied:
            self.assertTrue(adapter.is_denied_method(method, False),
                            method)
        legit = [
            "getauxblock", "createauxblock", "submitauxblock",
            "getblock", "getblockhash", "getblockcount",
            "getblockheader", "getblocktemplate", "getchaintips",
            "getmempoolinfo", "getmininginfo", "getnetworkinfo",
            "getpeerinfo", "getrawmempool", "estimatesmartfee",
            "validateaddress", "getbestblockhash", "gettxout",
        ]
        for method in legit:
            self.assertFalse(adapter.is_denied_method(method, False),
                             method)

    def test_denied_methods_blocked_before_daemon(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        for method in ("setnetworkactive", "send", "createwallet",
                       "invalidateblock", "pruneblockchain", "addnode",
                       "loadwallet", "sendall"):
            daemon.calls.clear()
            status, reply, _raw = core.handle_one(
                {"jsonrpc": "1.0", "id": 5, "method": method,
                 "params": []})
            self.assertEqual(status, 500, method)
            self.assertEqual(reply["error"]["code"], -32601, method)
            self.assertEqual(daemon.calls, [], method)

    # -- B15: periodic spool replay -----------------------------------------
    def test_parse_replay_interval(self):
        self.assertEqual(adapter.parse_replay_interval("300"), 300.0)
        self.assertEqual(adapter.parse_replay_interval("junk"), 300.0)
        self.assertEqual(adapter.parse_replay_interval("0"), 0.0)
        self.assertEqual(adapter.parse_replay_interval("99999999"),
                         86400.0)
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        self.assertEqual(core.spool_replay_interval_seconds, 300.0)

    def test_periodic_replay_resolves_spooled_entry(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh(
            spool_replay_interval_seconds="0.2")
        core.spool.spool(TEMPLATE_HASH, self.AUXPOW)  # daemon healthy
        self.assertEqual(len(self._spool_files(spool_dir)), 1)
        thread = core.start_periodic_replay()
        self.assertIsNotNone(thread)
        try:
            deadline = time.time() + 5
            while time.time() < deadline \
                    and self._spool_files(spool_dir):
                time.sleep(0.05)
        finally:
            core.stop_periodic_replay()
        self.assertEqual(self._spool_files(spool_dir), [])
        self.assertIn("spool_periodic_replay_started",
                      logger.event_names())

    # -- B16: /health reflects template capability ---------------------------
    def test_health_reflects_template_capability(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        server = ThreadingHTTPServer(
            ("127.0.0.1", 0), adapter.make_handler(core))
        threading.Thread(target=server.serve_forever,
                         daemon=True).start()
        self.addCleanup(server.shutdown)
        url = "http://127.0.0.1:%d/health" % server.server_address[1]

        def health():
            with urllib.request.urlopen(url, timeout=10) as resp:
                return json.loads(resp.read().decode())

        # Reachable daemon, but no template ever observed: degraded.
        core.tip_tracker.daemon_reachable = True
        body = health()
        self.assertEqual(body["status"], "degraded")
        self.assertFalse(body["template_capable"])
        # Self-check against a healthy daemon (chainid 29): ok.
        core.self_check()
        body = health()
        self.assertEqual(body["status"], "ok")
        self.assertTrue(body["template_capable"])
        self.assertEqual(body["last_template_chainid"], 29)
        # Wrong chain: ERROR-level degraded, never an ok.
        daemon.template_chainid_override = 57
        core.self_check()
        body = health()
        self.assertEqual(body["status"], "degraded")
        self.assertTrue(body["chainid_mismatch"])
        self.assertIn(("ERROR", "self_check_chainid_mismatch"),
                      [(lvl, ev) for lvl, ev, _f in logger.events])
        # Template path broken (node syncs, cannot build): degraded.
        daemon.template_chainid_override = None
        daemon.createauxblock_mode = "error"
        core.self_check()
        body = health()
        self.assertEqual(body["status"], "degraded")
        self.assertFalse(body["template_capable"])

    # -- Angle 3: alarm marker lists ALL pending hashes ----------------------
    def test_alarm_marker_lists_all_pending_hashes(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        core.raise_submission_alarm(TEMPLATE_HASH, self.AUXPOW, 3, "-8: x")
        core.raise_submission_alarm(self.HASH2, self.AUXPOW, 3, "-8: y")
        with open(alarm_file) as fh:
            marker = json.load(fh)
        self.assertEqual(marker["pending_count"], 2)
        self.assertEqual({p["hash"] for p in marker["pending"]},
                         {TEMPLATE_HASH, self.HASH2})
        self.assertEqual(marker["hash"], self.HASH2)  # latest, compat
        # Re-raising the same hash upserts -- never duplicates/drops.
        core.raise_submission_alarm(TEMPLATE_HASH, self.AUXPOW, 3, "-8: z")
        with open(alarm_file) as fh:
            marker = json.load(fh)
        self.assertEqual(marker["pending_count"], 2)
        # Clearing one hash keeps the other pending.
        core.clear_alarm_if_for(TEMPLATE_HASH)
        with open(alarm_file) as fh:
            marker = json.load(fh)
        self.assertEqual([p["hash"] for p in marker["pending"]],
                         [self.HASH2])
        # Clearing the last one removes the marker.
        core.clear_alarm_if_for(self.HASH2)
        self.assertFalse(os.path.exists(alarm_file))

    def test_alarm_marker_corrupt_is_logged_and_rebuilt(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        with open(alarm_file, "w") as fh:
            fh.write("this is not json {")
        core.raise_submission_alarm(TEMPLATE_HASH, self.AUXPOW, 1, "x")
        self.assertIn("alarm_marker_unreadable", logger.event_names())
        with open(alarm_file) as fh:
            marker = json.load(fh)  # valid again
        self.assertEqual([p["hash"] for p in marker["pending"]],
                         [TEMPLATE_HASH])


class FollowUpR2R3Tests(unittest.TestCase):
    """Follow-up fix round 2026-10-26: regression tests for
    chain-50 findings R2 (fork blocks must never be certified as
    landed) and R3 (spool validation, attempts cap, dead-letter).
    Same fixture style as FixRoundTests."""

    AUXPOW = "aabbccddeeff00112233"

    def _fresh(self, **overrides):
        daemon = MockDaemon()
        spool_dir = tempfile.mkdtemp(prefix="adapter-r2r3-spool-")
        alarm_file = os.path.join(spool_dir, "ALARM_TEST")
        logger = QuietLogger()
        config = dict(adapter.DEFAULTS)
        config.update({
            "daemon_host": "127.0.0.1", "daemon_port": str(daemon.port),
            "daemon_user": "user", "daemon_password": "pass",
            "payout_address": PAYOUT, "tip_poll_seconds": "3600",
            "submit_retry_attempts": "3",
            "submit_retry_delay_seconds": "0",
            "alarm_delay_seconds": "0",  # v2.3 C7: alarm-mechanics tests use the immediate path; the ~90s window has its own tests
            "spool_dir": spool_dir, "alarm_file": alarm_file,
        })
        config.update(overrides)
        core = adapter.AdapterCore(config, logger)
        self.addCleanup(daemon.stop)
        return daemon, core, spool_dir, alarm_file, logger

    def _core_on(self, daemon, spool_dir, alarm_file, logger):
        config = dict(adapter.DEFAULTS)
        config.update({
            "daemon_host": "127.0.0.1", "daemon_port": str(daemon.port),
            "daemon_user": "user", "daemon_password": "pass",
            "payout_address": PAYOUT, "tip_poll_seconds": "3600",
            "submit_retry_attempts": "3",
            "submit_retry_delay_seconds": "0",
            "alarm_delay_seconds": "0",  # v2.3 C7: alarm-mechanics tests use the immediate path; the ~90s window has its own tests
            "spool_dir": spool_dir, "alarm_file": alarm_file,
        })
        return adapter.AdapterCore(config, logger)

    @staticmethod
    def _submit_body(core, block_hash=TEMPLATE_HASH, auxpow=None,
                     method="getauxblock"):
        status, raw = core.handle_body(json.dumps(
            {"jsonrpc": "1.0", "id": 77, "method": method,
             "params": [block_hash,
                        FollowUpR2R3Tests.AUXPOW
                        if auxpow is None else auxpow]}).encode())
        return status, json.loads(raw.decode())

    @staticmethod
    def _calls(daemon, method):
        return [c for c in daemon.calls if c[0] == method]

    @staticmethod
    def _spool_files(spool_dir, suffix=".json"):
        return [n for n in os.listdir(spool_dir) if n.endswith(suffix)]

    def _write_spool_file(self, spool_dir, name, entry):
        with open(os.path.join(spool_dir, name), "w") as fh:
            json.dump(entry, fh)

    # -- R2a: fork block (confirmations -1) must NOT resolve -------------
    def test_fork_block_replay_precheck_does_not_resolve(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        daemon.submit_mode = "stale"
        self._submit_body(core)  # fails: spool + alarm now on disk
        self.assertEqual(len(self._spool_files(spool_dir)), 1)
        self.assertTrue(os.path.exists(alarm_file))
        # The block exists on the daemon ONLY on a losing fork:
        # getblock serves it with confirmations -1, and even
        # getblockhash(height) DOES return this hash (isolating
        # confirmations -1 as the sole reason for rejection).
        daemon.chain_blocks[TEMPLATE_HASH] = {
            "hash": TEMPLATE_HASH, "height": 104632, "confirmations": -1}
        daemon.chain_hash_by_height[104632] = TEMPLATE_HASH
        daemon.calls.clear()
        logger2 = QuietLogger()
        core2 = self._core_on(daemon, spool_dir, alarm_file, logger2)
        attempted, resolved = core2.replay_spooled_submissions()
        self.assertEqual((attempted, resolved), (1, 0))
        # NOT resolved: spool entry remains, alarm remains, no
        # replay_found_on_chain was logged.
        self.assertEqual(len(self._spool_files(spool_dir)), 1)
        self.assertTrue(os.path.exists(alarm_file))
        self.assertNotIn("replay_found_on_chain", logger2.event_names())
        self.assertIn("chain_check_not_on_active_chain",
                      logger2.event_names())

    def test_fork_block_duplicate_error_no_synthesised_success(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        daemon.chain_blocks[TEMPLATE_HASH] = {
            "hash": TEMPLATE_HASH, "height": 104632, "confirmations": -1}
        daemon.chain_hash_by_height[104632] = TEMPLATE_HASH
        daemon.submit_error_override = {
            "code": -27, "message": "duplicate block"}
        status, reply = self._submit_body(core)
        # The daemon's own duplicate error comes back -- never the
        # synthesised (200, {"result": True}) the pre-R2 code made.
        self.assertEqual(status, 500)
        self.assertNotEqual(reply.get("result"), True)
        self.assertEqual(reply["error"]["code"], -27)
        # Spool entry remains and the alarm stands.
        self.assertEqual(len(self._spool_files(spool_dir)), 1)
        self.assertTrue(os.path.exists(alarm_file))
        self.assertNotIn("replay_found_on_chain", logger.event_names())

    # -- R2b: getblockhash(height) mismatch must NOT resolve -------------
    def test_hash_mismatch_replay_precheck_does_not_resolve(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        core.spool.spool(TEMPLATE_HASH, self.AUXPOW, height=104632)
        self.assertEqual(len(self._spool_files(spool_dir)), 1)
        # getblock claims the block landed (confirmations 5) ...
        daemon.chain_blocks[TEMPLATE_HASH] = {
            "hash": TEMPLATE_HASH, "height": 104632, "confirmations": 5}
        # ... but the ACTIVE chain holds a DIFFERENT hash there.
        daemon.chain_hash_by_height[104632] = "ff" * 32
        daemon.submit_mode = "stale"  # resubmission cannot land it
        attempted, resolved = core.replay_spooled_submissions()
        self.assertEqual((attempted, resolved), (1, 0))
        self.assertEqual(len(self._spool_files(spool_dir)), 1)
        self.assertNotIn("replay_found_on_chain", logger.event_names())
        self.assertIn("chain_check_hash_mismatch", logger.event_names())

    def test_hash_mismatch_duplicate_error_no_synthesised_success(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        daemon.chain_blocks[TEMPLATE_HASH] = {
            "hash": TEMPLATE_HASH, "height": 104632, "confirmations": 5}
        daemon.chain_hash_by_height[104632] = "ff" * 32
        daemon.submit_error_override = {
            "code": -27, "message": "duplicate block"}
        status, reply = self._submit_body(core)
        self.assertEqual(status, 500)
        self.assertNotEqual(reply.get("result"), True)
        self.assertEqual(len(self._spool_files(spool_dir)), 1)
        self.assertTrue(os.path.exists(alarm_file))
        self.assertNotIn("replay_found_on_chain", logger.event_names())

    def test_active_chain_block_still_resolves_r2_positive_control(self):
        # Positive control: getblockhash match AND confirmations
        # >= 0 (here exactly 0, the boundary) still resolves.
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        core.spool.spool(TEMPLATE_HASH, self.AUXPOW, height=104632)
        daemon.chain_blocks[TEMPLATE_HASH] = {
            "hash": TEMPLATE_HASH, "height": 104632, "confirmations": 0}
        daemon.chain_hash_by_height[104632] = TEMPLATE_HASH
        attempted, resolved = core.replay_spooled_submissions()
        self.assertEqual((attempted, resolved), (1, 1))
        self.assertEqual(self._spool_files(spool_dir), [])
        self.assertIn("replay_found_on_chain", logger.event_names())
        self.assertEqual(self._calls(daemon, "submitauxblock"), [])

    # -- R3: pre-spool validation -----------------------------------------
    def test_invalid_submission_rejected_and_never_spooled(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        for block_hash, auxpow in (
                ("not-64-hex", self.AUXPOW),       # bad hash format
                ("ab" * 31, self.AUXPOW),          # hash too short
                (TEMPLATE_HASH, "zz-not-hex"),     # non-hex auxpow
                (TEMPLATE_HASH, "abc"),            # odd-length auxpow
                (TEMPLATE_HASH, "")):              # empty auxpow
            with self.subTest(hash=block_hash, auxpow=auxpow):
                daemon.calls.clear()
                status, reply = self._submit_body(
                    core, block_hash=block_hash, auxpow=auxpow)
                self.assertEqual(status, 500)
                self.assertEqual(reply["error"]["code"], -32602)
                # Never spooled, daemon never contacted.
                self.assertEqual(self._spool_files(spool_dir), [])
                self.assertEqual(daemon.calls, [])
        self.assertIn("submission_validation_failed",
                      logger.event_names())
        self.assertFalse(os.path.exists(alarm_file))

    # -- R3c: poison spool entries are quarantined, never replayed -------
    def test_poison_spool_entries_quarantined_not_replayed(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        self._write_spool_file(spool_dir, "poison-hash.json", {
            "hash": "not-a-hash", "auxpow": self.AUXPOW,
            "first_seen": 1, "attempts": 0, "last_error": None,
            "last_attempt": None, "height": None})
        self._write_spool_file(spool_dir, "poison-auxpow.json", {
            "hash": TEMPLATE_HASH, "auxpow": "zz-not-hex",
            "first_seen": 2, "attempts": 0, "last_error": None,
            "last_attempt": None, "height": None})
        attempted, resolved = core.replay_spooled_submissions()
        self.assertEqual((attempted, resolved), (0, 0))
        # Nothing was submitted to the daemon at all.
        self.assertEqual(self._calls(daemon, "submitauxblock"), [])
        self.assertEqual(daemon.calls, [])
        # Both entries quarantined to <name>.bad, kept as evidence.
        self.assertEqual(self._spool_files(spool_dir), [])
        self.assertEqual(
            sorted(self._spool_files(spool_dir, ".json.bad")),
            ["poison-auxpow.json.bad", "poison-hash.json.bad"])
        self.assertIn("spool_entry_quarantined", logger.event_names())
        # A second replay does not submit them either.
        attempted, resolved = core.replay_spooled_submissions()
        self.assertEqual((attempted, resolved), (0, 0))
        self.assertEqual(self._calls(daemon, "submitauxblock"), [])
        self.assertEqual(
            sorted(self._spool_files(spool_dir, ".json.bad")),
            ["poison-auxpow.json.bad", "poison-hash.json.bad"])

    # -- R3d: attempts-cap dead-lettering ----------------------------------
    def test_attempts_over_cap_dead_lettered_and_never_replayed(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        self._write_spool_file(spool_dir, TEMPLATE_HASH + ".json", {
            "hash": TEMPLATE_HASH, "auxpow": self.AUXPOW,
            "first_seen": 1, "attempts": adapter.MAX_REPLAY_ATTEMPTS + 1,
            "last_error": "-8: block hash unknown",
            "last_attempt": None, "height": 104632})
        # RT-2 (2026-10-27): dead-lettering now requires the entry
        # to be PROVABLY BURIED -- tip >= height (mock tip is
        # 104632) AND a different hash on-chain at that height.
        # Register that different hash; the pre-RT-2 mock returned
        # an error for getblockhash(104632), under which the new
        # fail-closed rule correctly refuses to dead-letter.
        daemon.chain_hash_by_height[104632] = "00" * 32
        attempted, resolved = core.replay_spooled_submissions()
        self.assertEqual((attempted, resolved), (0, 0))
        # Never SUBMITTED: dead-lettered before any replay work
        # (the getblockcount/getblockhash buried-proof calls are
        # the RT-2 gate itself, not replay work).
        self.assertEqual(self._calls(daemon, "submitauxblock"), [])
        self.assertEqual(self._spool_files(spool_dir), [])
        self.assertEqual(self._spool_files(spool_dir, ".json.dead"),
                         [TEMPLATE_HASH + ".json.dead"])
        self.assertIn("spool_entry_dead_lettered", logger.event_names())
        self.assertIn("spool_entry_attempts_cap_exceeded",
                      logger.event_names())
        # And a second replay leaves it dead, still unsubmitted.
        attempted, resolved = core.replay_spooled_submissions()
        self.assertEqual((attempted, resolved), (0, 0))
        self.assertEqual(self._calls(daemon, "submitauxblock"), [])
        self.assertEqual(self._spool_files(spool_dir, ".json.dead"),
                         [TEMPLATE_HASH + ".json.dead"])

    def test_attempts_crossing_cap_during_replay_dead_lettered(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        self._write_spool_file(spool_dir, TEMPLATE_HASH + ".json", {
            "hash": TEMPLATE_HASH, "auxpow": self.AUXPOW,
            "first_seen": 1,
            "attempts": adapter.MAX_REPLAY_ATTEMPTS - 1,
            "last_error": None, "last_attempt": None, "height": 104632})
        # RT-2: provably-buried setup (see the over-cap test).
        daemon.chain_hash_by_height[104632] = "00" * 32
        daemon.submit_mode = "stale"  # every submit fails with -8
        attempted, resolved = core.replay_spooled_submissions()
        self.assertEqual((attempted, resolved), (1, 0))
        # 3 bounded attempts pushed attempts 9 -> 12, over the cap:
        # the entry was dead-lettered in the same pass.
        self.assertEqual(len(self._calls(daemon, "submitauxblock")), 3)
        self.assertEqual(self._spool_files(spool_dir), [])
        self.assertEqual(self._spool_files(spool_dir, ".json.dead"),
                         [TEMPLATE_HASH + ".json.dead"])
        with open(os.path.join(
                spool_dir, TEMPLATE_HASH + ".json.dead")) as fh:
            dead = json.load(fh)
        self.assertEqual(dead["attempts"],
                         adapter.MAX_REPLAY_ATTEMPTS + 2)
        # Never replayed again.
        daemon.calls.clear()
        attempted, resolved = core.replay_spooled_submissions()
        self.assertEqual((attempted, resolved), (0, 0))
        self.assertEqual(self._calls(daemon, "submitauxblock"), [])

    # -- RT-2 (red team 2026-10-27): cap alone must NOT dead-letter --------
    def test_over_cap_tip_stuck_not_buried_stays_and_lands(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        self._write_spool_file(spool_dir, TEMPLATE_HASH + ".json", {
            "hash": TEMPLATE_HASH, "auxpow": self.AUXPOW,
            "first_seen": 1, "attempts": adapter.MAX_REPLAY_ATTEMPTS + 5,
            "last_error": "-8: block hash unknown",
            "last_attempt": None, "height": 104632})
        # Stall shape: tip STUCK one below the entry's height --
        # the block is exactly what the chain is waiting for.
        daemon.getblockcount_value = 104631
        daemon.submit_mode = "stale"  # daemon path still down
        attempted, resolved = core.replay_spooled_submissions()
        self.assertEqual((attempted, resolved), (1, 0))
        # NOT dead-lettered: still spooled, was retried, RT-2 event logged.
        self.assertEqual(self._spool_files(spool_dir),
                         [TEMPLATE_HASH + ".json"])
        self.assertEqual(self._spool_files(spool_dir, ".json.dead"), [])
        self.assertIn("spool_entry_over_cap_not_buried",
                      logger.event_names())
        self.assertEqual(len(self._calls(daemon, "submitauxblock")), 3)
        # Daemon path recovers: the same entry now lands.
        daemon.submit_mode = "ok"
        attempted, resolved = core.replay_spooled_submissions()
        self.assertEqual((attempted, resolved), (1, 1))
        self.assertEqual(self._spool_files(spool_dir), [])

    def test_over_cap_tip_took_height_same_hash_resolves_not_dead(self):
        daemon, core, spool_dir, alarm_file, logger = self._fresh()
        self._write_spool_file(spool_dir, TEMPLATE_HASH + ".json", {
            "hash": TEMPLATE_HASH, "auxpow": self.AUXPOW,
            "first_seen": 1, "attempts": adapter.MAX_REPLAY_ATTEMPTS + 5,
            "last_error": None, "last_attempt": None, "height": 104632})
        # The block DID land (active chain, confirmations >= 0):
        # resolution, not dead-lettering.
        daemon.chain_blocks[TEMPLATE_HASH] = {
            "hash": TEMPLATE_HASH, "height": 104632, "confirmations": 3}
        attempted, resolved = core.replay_spooled_submissions()
        self.assertEqual((attempted, resolved), (1, 1))
        self.assertEqual(self._spool_files(spool_dir, ".json.dead"), [])


class _V23FakeDaemon:
    """Minimal in-process daemon fake for the v2.3 R3/contract tests
    (call/call_raw interface, scripted submit replies, explicit
    on-chain state -- a submit reply of True registers the block
    on-chain ONLY when register_on_accept is set, so the C2
    false-true shape can be modelled too)."""

    def __init__(self, submit_script=(), tip=100, on_chain=None,
                 register_on_accept=True):
        self._config = {}
        self.submit_script = list(submit_script)
        self.tip = tip
        self.on_chain = on_chain or {}
        self.register_on_accept = register_on_accept
        self.calls = []
        self.fresh_hash = TEMPLATE_HASH
        self.fresh_height = 104632

    def _template(self, rid=None):
        return {"result": {"hash": self.fresh_hash,
                           "height": self.fresh_height, "chainid": 29,
                           "_target": SAMPLE_UNDERSCORE_TARGET},
                "error": None, "id": rid}

    def call(self, method, params, request_id=None):
        self.calls.append((method, list(params)
                           if isinstance(params, list) else params))
        if method == "createauxblock":
            return 200, self._template(request_id)
        if method == "getblockcount":
            return 200, {"result": self.tip, "error": None,
                         "id": request_id}
        if method == "getblock":
            info = self.on_chain.get(params[0])
            if info is None:
                return 500, {"result": None,
                             "error": {"code": -5,
                                       "message": "Block not found"},
                             "id": request_id}
            conf, height, _h = info
            return 200, {"result": {"confirmations": conf,
                                    "height": height,
                                    "hash": params[0]},
                         "error": None, "id": request_id}
        if method == "getblockhash":
            for _h, (conf, height, chainhash) in self.on_chain.items():
                if height == params[0]:
                    return 200, {"result": chainhash, "error": None,
                                 "id": request_id}
            return 500, {"result": None,
                         "error": {"code": -8,
                                   "message": "Block height out of range"},
                         "id": request_id}
        raise AssertionError("unexpected call %s" % method)

    def call_raw(self, body_bytes):
        req = json.loads(body_bytes.decode())
        method, params = req.get("method"), req.get("params", [])
        self.calls.append((method, list(params)
                           if isinstance(params, list) else params))
        if method == "submitauxblock":
            item = self.submit_script.pop(0) if self.submit_script \
                else {"result": True, "error": None, "id": req.get("id")}
            if isinstance(item, Exception):
                raise item
            item = dict(item)
            item["id"] = req.get("id")
            if not item.get("error") and item.get("result") is True \
                    and self.register_on_accept:
                self.on_chain[params[0]] = (1, self.fresh_height,
                                            params[0])
            return (500 if item.get("error") else 200), \
                json.dumps(item).encode()
        if method == "createauxblock":
            return 200, json.dumps(self._template(req.get("id"))).encode()
        raise AssertionError("unexpected call_raw %s" % method)

    def count(self, method):
        return sum(1 for m, _ in self.calls if m == method)


class V23R3ContractTests(unittest.TestCase):
    """Freeze v2.3: R3 secondary_daemon_url + INTERFACE-CONTRACT
    C2/C3/C7 on the adapter (seat-10 re-test list, wsC/07 section 5).
    The interim suite had zero secondary coverage; this class is it."""

    AUXPOW = "aabbccddeeff00112233"

    def _core(self, primary, secondary=None, **over):
        config = dict(adapter.DEFAULTS)
        config.update({
            "payout_address": PAYOUT,
            "spool_dir": tempfile.mkdtemp(prefix="adapter-v23-spool-"),
            "tip_poll_seconds": "3600",
            "submit_retry_delay_seconds": "0",
            "submit_retry_attempts": "2",
        })
        config.update(over)
        logger = QuietLogger()
        core = adapter.AdapterCore(config, logger)
        core.daemon = primary
        core.tip_tracker._daemon = primary
        core.secondary_daemon = secondary
        core.tip_tracker.tip = 100
        return core, logger

    def _submit(self, core):
        return core.handle_one(
            {"jsonrpc": "1.0", "id": 1, "method": "getauxblock",
             "params": [TEMPLATE_HASH, self.AUXPOW]})

    def _spool_files(self, core):
        return [n for n in os.listdir(core.spool.directory)
                if n.endswith(".json")]

    @staticmethod
    def _err(code, msg):
        return {"result": None,
                "error": {"code": code, "message": msg}, "id": None}

    @staticmethod
    def _ok(result=True):
        return {"result": result, "error": None, "id": None}

    def test_secondary_accepts_after_primary_transport_failure(self):
        pri = _V23FakeDaemon(
            submit_script=[RuntimeError("primary down")] * 4)
        sec = _V23FakeDaemon(submit_script=[self._ok(True)])
        core, logger = self._core(pri, sec)
        _st, reply, _raw = self._submit(core)
        self.assertEqual(reply.get("result"), True)
        self.assertEqual(self._spool_files(core), [])
        self.assertEqual(sec.count("submitauxblock"), 1)
        outcomes = [fields for (_lvl, event, fields) in logger.events
                    if event == "submission_outcome"]
        self.assertTrue(any(f.get("via") == "secondary"
                            and f.get("outcome") == "accepted"
                            for f in outcomes))

    def test_primary_deterministic_invalid_never_sprayed(self):
        pri = _V23FakeDaemon(
            submit_script=[self._err(-26, "bad-auxpow-tag")] * 4)
        sec = _V23FakeDaemon(submit_script=[self._ok(True)])
        core, _logger = self._core(pri, sec)
        _st, reply, _raw = self._submit(core)
        self.assertNotEqual(reply.get("result"), True)
        # Contract C3: exactly ONE primary submission, zero retries,
        # and the secondary is never attempted.
        self.assertEqual(pri.count("submitauxblock"), 1)
        self.assertEqual(sec.count("submitauxblock"), 0)
        self.assertTrue(os.path.exists(core.alarm_file))

    def test_primary_bare_true_not_visible_is_unconfirmed(self):
        pri = _V23FakeDaemon(submit_script=[self._ok(True)],
                             register_on_accept=False)
        sec = _V23FakeDaemon(submit_script=[self._ok(True)])
        core, _logger = self._core(pri, sec)
        _st, reply, _raw = self._submit(core)
        # Contract C2: no credit, spool KEPT, and the secondary
        # submit leg is not sprayed on a success-shaped reply.
        self.assertNotEqual(reply.get("result"), True)
        self.assertEqual(len(self._spool_files(core)), 1)
        self.assertEqual(sec.count("submitauxblock"), 0)

    def test_alarm_delay_window_for_transient_failure(self):
        pri = _V23FakeDaemon(
            submit_script=[RuntimeError("primary-down")] * 4)
        sec = _V23FakeDaemon(
            submit_script=[RuntimeError("secondary-down")] * 4)
        core, logger = self._core(
            pri, sec, alarm_delay_seconds="0.3",
            submit_retry_attempts="1")
        _st, reply, _raw = self._submit(core)
        self.assertNotEqual(reply.get("result"), True)
        # C7: WARN at once, NO alarm marker before the window.
        self.assertIn("submission_unresolved_warn",
                      logger.event_names())
        self.assertFalse(os.path.exists(core.alarm_file))
        time.sleep(0.7)
        self.assertTrue(os.path.exists(core.alarm_file))
        with open(core.alarm_file) as fh:
            marker = fh.read()
        self.assertIn(TEMPLATE_HASH, marker)
        self.assertIn("secondary-down", marker)

    def test_no_secondary_configured_is_v22_behaviour(self):
        pri = _V23FakeDaemon(submit_script=[self._ok(True)])
        core, _logger = self._core(pri, None)
        _st, reply, _raw = self._submit(core)
        self.assertEqual(reply.get("result"), True)
        self.assertEqual(self._spool_files(core), [])


if __name__ == "__main__":
    unittest.main()
