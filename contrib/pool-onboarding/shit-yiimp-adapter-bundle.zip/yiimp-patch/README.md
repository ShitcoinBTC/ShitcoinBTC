# yiimp stratum patch — Shitcoin (SHIT) AuxPoW template fetch

Native-route fix for yiimp operators who can rebuild their stratum.
It makes stock yiimp (tpruvot/yiimp lineage) work with the Shitcoin
daemon's `getauxblock` dialect. No daemon change is required, and no
other coin's behaviour changes.

## Applies to

- Upstream tree: `tpruvot/yiimp`, branch `next`,
  commit `52f68f8641632a783ba24f0d6591205db3a3bd81` (current head at
  time of writing). The patches were generated with `git diff` against
  a fresh clone of that commit and re-verified with
  `git apply --check` on a second pristine clone (see Verification).
- Any fork whose `stratum/coind_template.cpp` still contains the stock
  `coind_getauxblock` (target read at lines 25–26) should take the
  patches with at most minor context drift; both patches touch only
  that one function in that one file.
- Daemon side: Shitcoin `syscoind` v5.0.9 (`getauxblock` /
  `createauxblock` result shape as live-verified 2026-10-24:
  `hash`, `chainid` 29, `previousblockhash`, `coinbasevalue`,
  `coinbasescript`, `bits`, `height`, `_target` — and no `target`,
  no `version`).

## Files

| File | What it is |
|---|---|
| `0001-stratum-auxblock-underscore-target.patch` | The fix for gap 1 (aux target). Apply this one always. |
| `0002-stratum-createauxblock-variant.patch` | Optional variant for gap 2 (wallet-free template fetch via `createauxblock`). Applies **on top of 0001**, same file. Apply only if you cannot or do not want to run the daemon with exactly one wallet (see Gap 2). |

## The three gaps, and what fixes each

### Gap 1 — the daemon sends `_target`, yiimp reads `target` (0001)

Stock `coind_getauxblock` (`stratum/coind_template.cpp:25-26`) does
`json_get_string(json_result, "target")`. The Shitcoin daemon (Syscoin
lineage) returns the target only as `_target`. So in stock yiimp
`coind->aux.target` stays empty, and at submit time
`client_submit.cpp:171-174` runs `binlify()` /
`get_hash_difficulty()` over an empty string: the parent-hash-vs-aux-target
test compares against zero/garbage, `getauxblock(hash, auxpow)` is
never (or only erratically) submitted, and **nothing is logged on
either side**. Parent mining looks completely normal; SHIT simply
never produces a block.

0001 adds a fallback: if `target` is absent, read `_target` and store
it **exactly as returned — with no byte reversal**. That last point is
the opposite of the first instinct, so it is spelled out here and in
the patch comments, with the proof:

- The daemon labels `_target` "target in reversed byte order,
  deprecated" because `_target` is `HexStr(uint256)` of the value built
  by `ArithToUint256(SetCompact(nBits))`
  (daemon `src/rpc/auxpow_miner.cpp`, `AuxpowMiner::createAuxBlock`):
  the 32 target bytes in uint256 internal (little-endian) order.
  Byte-reversing the hex gives the canonical display-order target —
  that much is true, and it was verified against the bits-derived
  target on live data (analysis 01).
- But display order is **not** what yiimp consumes. `aux.target` has
  exactly one consumer: `client_submit.cpp` `binlify()`s the string
  and `get_hash_difficulty()` (`stratum/util.cpp`) reads **bytes
  22..29** of the result as the significant window — the same window
  it reads from `submitvalues->hash_bin`, the raw internal-order hash
  output (whose significant bytes likewise sit at the end of the
  buffer; cf. `client_submit.cpp:499`, `hash_bin[30] | hash_bin[31]`).
  Internal-order input is required.
- Worked live example (2026-10-24): `bits` `1935be6a`,
  `_target` `000000000000000000000000000000000000000000006abe3500000000000000`.
  `get_hash_difficulty(binlify(_target))` = `0x35be6a` — the bits
  mantissa, identical to `decode_compact("1935be6a")`, which is what
  the submit comparison expects. If `_target` is byte-reversed first,
  the significant bytes land at offsets 7..9, the extractor returns
  **0**, and `hash_int <= coin_target_aux` can never pass for a real
  hash: a reversing patch would recreate the exact silent failure it
  is meant to fix.
- The commented-out UNO special case in the same function
  (`string_be1(coind->aux.target)`) flips for the opposite reason —
  that daemon returns its target in display order. Do not generalize
  it to this branch.

0001 also adds one `debuglog` line per fresh aux template
(`SHIT auxblock chainid 29 target <...> hash <...>`) so the fix is
provable from the stratum log alone. Daemons that do return `target`
take the original code path untouched (regression-checked, see
Verification).

### Gap 2 — `getauxblock` is a wallet RPC; yiimp cannot address a wallet (prerequisite, or 0002)

Parameterless `getauxblock` on this daemon is implemented as a wallet
RPC. With zero wallets, or with two or more wallets loaded, it fails
before returning any work:

```
error code: -19
"Wallet file not specified (must request wallet RPC through
 /wallet/<filename> uri-path). Try adding \"-rpcwallet=<filename>\" ..."
```

(live-verified on a 12-wallet node, 2026-10-24). yiimp has no way to
express that selector: its RPC URL is built as
`sprintf(url, "http%s://%s:%d", ...)` with no path component
(`stratum/rpc_curl.cpp:391`), and the `coins` table carries only
rpchost/rpcport/rpcuser/rpcpasswd — there is no wallet-file field
anywhere in the schema.

**Prerequisite (no extra patch needed):** run the pool's `syscoind`
with **exactly one wallet loaded**, or start it with
`-rpcwallet=<wallet file>` in the daemon's own launch line / 
`syscoin.conf` (`rpcwallet=<wallet file>`). Then the parameterless
call is unambiguous and 0001 alone is sufficient. A dedicated,
otherwise-empty wallet created only for the pool daemon is fine — the
template's coinbase pays that wallet's address.

**Variant (0002):** a clean injection point does exist, in the same
function. `coind_getauxblock` is the stratum's only template-fetch
site, and the daemon offers `createauxblock "<payout address>"` as a
plain mining RPC (`src/rpc/mining.cpp`) — no wallet involved, the
identical result shape, and blocks created through it land in the
same `AuxpowMiner` cache, so the stock submission call
`getauxblock(hash, auxpow)` (`coind_submitgetauxblock`,
`stratum/coind_submit.cpp`) keeps working unchanged. 0002 makes the
fetch call `createauxblock` with `coind->wallet` when **all** of these
hold: the coin symbol is `SHIT`, `coind->wallet` is non-empty, and the
string is plain alphanumeric (it is interpolated into the RPC params,
so anything else is never interpolated). Any failure or null result
falls back to the stock `getauxblock []` call in the same function —
the variant can never do worse than unpatched yiimp.

Address source caveat, stated plainly: `coind->wallet` is loaded from
`coins.master_wallet` (`stratum/db.cpp`, `SELECT ... master_wallet
...`, row 7), but `coind_init()` (`stratum/coind.cpp`) can replace it
at stratum start via its `getaccountaddress` fallback when the
address is not one of the daemon wallet's own addresses. So before
relying on 0002:

1. Set `master_wallet` for the SHIT row to the SHIT address that
   should receive the coinbase payout.
2. After stratum starts, confirm the effective address is the one you
   set (watch the stratum startup log; `coind_init` logs
   `using wallet <address>` when it substitutes one).
3. Cross-check the first template by hand (deterministic per
   address): `syscoin-cli createauxblock <that address>` must return
   the same `hash` the stratum log line shows for that height.

If you cannot confirm the effective address, do not use 0002 — use
the one-wallet prerequisite above instead.

### Gap 3 — aux work goes stale within one tip; wire `blocknotify` (configuration, no code)

The daemon caches the aux block behind each `hash` and **drops the
whole cache when the tip moves** (daemon
`src/rpc/auxpow_miner.cpp`, `getCurrentBlock`: on tip change
`blocks.clear(); templates.clear(); curBlocks.clear()`). SHIT tips
arrive roughly every 30 seconds. A submission for a previous tip's
hash gets error **-8, "block hash unknown"**, which yiimp surfaces
only as `SHIT <height> REJECTED` (`stratum/client_submit.cpp:215`).

Without notification, yiimp re-fetches aux work only on its ~21 s DB
poll loop (`stratum/stratum.cpp` main loop: `db_update_coinds()` then
`sleep(20)`) plus parent-template rebuilds — a race a small pool
loses most tips. With `blocknotify` wired, every SHIT tip triggers
`client_update_block` (`stratum/client.cpp:291,623-624`), which
rebuilds the aux coin's job first (re-running `coind_getauxblock`,
hence a fresh `hash`/`target`) and then rebuilds every mineable
parent job and signals miners — aux work is refreshed on the tip
change itself, not on the next poll.

Daemon side — add to the SHIT daemon's `syscoin.conf` (one line, no
spaces around `=`):

```
blocknotify=/var/stratum/blocknotify 127.0.0.1:<STRATUM_TCP_PORT> <SHIT_COIN_ID> %s
```

- `/var/stratum/blocknotify` — path to yiimp's `blocknotify` helper
  binary (built from `blocknotify/` in the yiimp tree; adjust to your
  install path).
- `<STRATUM_TCP_PORT>` — the TCP port of the stratum process that
  serves the parent coins SHIT rides on: `[TCP] port` in that
  stratum's algo `.conf` (the message goes to `host:port` from
  `[TCP] server`/`port`; use the same host the stratum binds, usually
  `127.0.0.1` when the daemon and stratum share a box).
- `<SHIT_COIN_ID>` — the `id` of the SHIT row in **your** yiimp
  `coins` table (`SELECT id, symbol, auxpow FROM coins WHERE
  symbol='SHIT';` — it must be the row with `auxpow=1`). This id is
  per-installation; there is no universal value.
- `%s` — literal; the daemon substitutes the new block hash.

yiimp side:

1. Build the helper with the stratum: `make -C blocknotify` (or use
   the `blocknotify` binary from your existing yiimp install) and make
   sure the file at the path above is executable by the user the
   daemon runs as.
2. Password alignment: the stock `blocknotify` binary sends the
   literal password `tu8tu5` (`blocknotify/blocknotify.cpp:74`), and
   the stratum checks it against `[TCP] password` in its `.conf`
   (`client_update_block`, `stratum/client.cpp`). Either set
   `password = tu8tu5` in that `.conf`, or rebuild `blocknotify` with
   your stratum's password in that string. A mismatch fails silently
   except for `update block, bad password` in the client log.
3. Restart the SHIT daemon after editing `syscoin.conf`
   (`-blocknotify` is also accepted as a launch flag instead of the
   conf line; the conf line is preferred so it survives restarts).
4. Keep each parent daemon's own standard `blocknotify` for its own
   coin id as usual — the SHIT line is additional, in `syscoin.conf`
   only, not a replacement.

Note this wiring fixes freshness, not hashrate: at solo hashrate a
qualifying parent share still has to land inside the current tip
window, but with `blocknotify` the window is the full ~30 s tip
interval instead of whatever is left of it at the next poll.

## Build steps

```sh
# in a checkout of tpruvot/yiimp (branch next), stratum sources clean:
cd stratum
patch -p1 < 0001-stratum-auxblock-underscore-target.patch
# optional, only for the Gap-2 variant, after 0001:
patch -p1 < 0002-stratum-createauxblock-variant.patch
# (git apply works identically for both files)
make            # produces ./stratum; also make -C ../blocknotify if needed
```

Then deploy the rebuilt `stratum` binary the way you normally deploy
yiimp (e.g. copy into `/var/stratum/`, restart the stratum process
for the parent algo). Usual yiimp build prerequisites apply
(MySQL client and libcurl development files); they are unchanged by
this patch.

## Verification

Patch provenance, done by the patch author against the fetched
upstream tree (`next` @ `52f68f8`):

- `git apply --check` passes for 0001 on a pristine clone, and for
  0002 applied on top of 0001; the resulting file is byte-identical
  to the authored stage-2 file.
- The patched `coind_getauxblock` function text was compiled verbatim
  in a test harness together with yiimp's real `binlify`,
  `get_hash_difficulty` and `decode_compact`, and run against the two
  live daemon vectors recorded 2026-10-24 (bits `1935be6a` and
  `193801a9` with their real `_target`/`hash` values). All checks
  passed: chainid 29 stored; `aux.target` == `_target` verbatim;
  extractor result == bits mantissa == `decode_compact(bits)`
  (`0x35be6a` / `0x3801a9`); a simulated qualifying parent hash passes
  the submit test and a non-qualifying one is rejected; with the
  target byte-flipped instead, the extractor returns 0 and the same
  qualifying hash fails — the negative control for the byte-order
  decision. A classic daemon response carrying `target` (and a stray
  `_target`) is stored verbatim from `target`, unchanged.
- The 0002 function text was harness-tested the same way: valid SHIT
  wallet → single `createauxblock ["<address>"]` call; null result →
  fallback to `getauxblock []`; empty or non-alphanumeric wallet →
  stock call only; non-SHIT aux coin → stock call only.
- A full `make` of the stratum was **not** run by the patch author:
  this sandbox lacks the MySQL/libcurl development headers yiimp
  requires. The build step above is therefore part of the operator
  checklist below — treat a clean build on your box as a required
  gate, not a formality.

Operator checklist after deploying:

1. Daemon pre-flight (wallet path): with the daemon running as it
   will run in production,
   `syscoin-cli getauxblock` returns a template object (not error
   -19) — or, with 0002, `syscoin-cli createauxblock <payout address>`
   returns one. Either way the result shows `"chainid": 29`.
   (If `getauxblock` needs it locally:
   `syscoin-cli -rpcwallet=<wallet file> getauxblock`.)
2. Stratum log: on the next template cycle the new line appears:
   `SHIT auxblock chainid 29 target 000000000000000000000000000000000000000000006abe35... hash <...>`
   with a non-empty 64-hex target. Cross-check the target against the
   daemon: reversing the logged target hex byte-by-byte must equal
   the canonical target for the `bits` in the same `getauxblock`
   result (e.g. bits `1935be6a` → canonical
   `0000000000000035be6a00000000000000000000000000000000000000000000`).
3. Freshness: watch the log across a SHIT tip change — a new
   `auxblock` line with the new height's hash appears within a second
   or two of the tip (blocknotify), not up to ~21 s later (poll).
4. End state: a qualifying parent share now produces
   `*** ACCEPTED SHIT <height> (+1)` in the stratum log instead of
   silence or `SHIT <height> REJECTED`, and the block is visible on
   the chain at that height paying the expected address.

## Scope notes

- Optional patch for operators who rebuild their stratum. It does
  not change the daemon, the AuxPoW format, the chain-id 29 slot
  math, or the parent coinbase layout — those already agree between
  yiimp and the daemon.
- NEVM data needs no pool-side handling on this path: the
  daemon-built cached block behind `hash` already carries it,
  provided the daemon itself is healthy (sysgeth running as the
  daemon-managed child). A daemon that throws `nevm-data-not-found`
  on `getblocktemplate`/`getauxblock` is a daemon install problem,
  separate from this patch.
- Background analysis: `07.md` (yiimp-vs-daemon interface audit) and
  `01.md` (live template RPC evidence), same work folder.
